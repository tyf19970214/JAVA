package com.frame.mall.core.mail;

public class Constant {
	
	public static final String tomcat_AttHome_Key = "/Users/images/javaMail/";
	public static final String filepath = "F:/Users/tyf19/Workspaces/project/MyBox/src/main/webapp/WEB-INF/Users/images/javaMail/";
	public static int CHECK_STATUS_NO = 0;
	public static String server_attHome_Key = "http://127.0.0.1:8080/";

}
