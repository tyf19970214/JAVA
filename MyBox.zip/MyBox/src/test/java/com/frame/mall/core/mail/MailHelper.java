package com.frame.mall.core.mail;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.BodyPart;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Part;
import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.internet.MimeUtility;

import com.sun.mail.imap.IMAPFolder;
import com.sun.mail.imap.IMAPStore;

/**
 * 
 * 迭代出来的所有文件夹名称:其他文件夹
迭代出来的所有文件夹名称:INBOX
迭代出来的所有文件夹名称:Sent Messages
迭代出来的所有文件夹名称:Drafts
迭代出来的所有文件夹名称:Deleted Messages
迭代出来的所有文件夹名称:Junk
 *
 */
public class MailHelper {

	public static MailConfig getConfig() {
//		spring.mail.host=smtp.caih.com
//				spring.mail.port=25
//				spring.mail.username=erpsys@caih.com
//				spring.mail.password=Dx123456
		
		MailConfig config = new MailConfig();
		config.euser = "583859395@qq.com";
		config.epassword = "jnzvthkzljdtbfcc";//163邮箱需要取消限制,并使用授权码
		config.mailimaphost = "imap.qq.com";
		//如果使用pop3协议这里imap改成pop3，如果使用ssl连接这里应使用imaps
		config.mailstoreprotocol = "imap";
		config.type = "imap";
		return config;
	}

	public void readMail(MailConfig config) {
		try {
			Properties prop = System.getProperties();
			prop.put("mail.store.protocol", config.mailstoreprotocol);
			prop.put("mail."+config.type+".host", config.mailimaphost);
			Session session = Session.getInstance(prop);
			IMAPStore store = (IMAPStore) session.getStore(config.mailstoreprotocol); // 使用imap会话机制，连接服务器
			store.connect(config.euser, config.epassword);
			IMAPFolder folder = (IMAPFolder) store.getFolder("INBOX"); // 收件箱
			folder.open(Folder.READ_WRITE);
			// 获取未读邮件
			Message[] messages = folder.getMessages();

System.out.println(folder.getNewMessageCount()+",.....................新邮件");
System.out.println(folder.getUnreadMessageCount()+",.....................未读邮件");
System.out.println(folder.getDeletedMessageCount()+",.....................已删除邮件");
System.out.println(folder.getMode()+",.....................邮件模式");
System.out.println(folder.getMessageCount()+",.....................邮件总数");

			parseMessage(messages); // 解析邮件			
			// 释放资源
			if (folder != null) {
				folder.close(true);
			}			
		
			if (store != null) {
				store.close();
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	/**
	 * 解析邮件
	 * 
	 * @param messages
	 *            要解析的邮件列表
	 */
	private void parseMessage(Message... messages) throws MessagingException, IOException {
		if (messages == null || messages.length < 1)
			throw new MessagingException("未找到要解析的邮件!");

		// 解析所有邮件
		for (int i = 0, count = messages.length; i < count; i++) {
			MimeMessage msg = (MimeMessage) messages[i];
			msg.setFlag(Flags.Flag.SEEN, true);
			EmailInfo emaininfo = new EmailInfo();
			emaininfo.setEmailcode(msg.getMessageID()); // ID
			System.out.println(msg.getMessageID()+"-------------------id");
			InternetAddress address = getFrom(msg);
			emaininfo.setSender(address.getPersonal() + "<" + address.getAddress() + ">");// 张三<zhangsan@163.com>
			System.out.println(emaininfo.getSender()+"-------------------sender");
			emaininfo.setTitle(decodeText(msg.getSubject()));// 转码后的标题
		//	StringBuffer cont = new StringBuffer();
			// getMailTextContent(msg,cont);
			/**
			 * 获取正文体
			 */
			System.out.println(MailUtils.getBody(msg, "userName")+"------------正文");
			emaininfo.setMsgBody(MailUtils.getBody(msg, "userName"));
			emaininfo.setReceiver(getReceiveAddress(msg, null));// 收件人
			emaininfo.setAccepttime(msg.getSentDate());// 收件日期
			emaininfo.setCheckstatus(Constant.CHECK_STATUS_NO);	
			System.out.println(emaininfo.getCheckstatus()+"---------------是否已读");
	
			// emailInfoMapper.insert(emaininfo);
			System.out.println(emaininfo.toString());
	if (isContainAttachment(msg)) {// 保存附件
				 saveAttachment(msg,Constant.filepath,address.getAddress(),address.getPersonal());
			}
		}
	}

	/**
	 * 获得邮件发件人
	 * 
	 * @param msg
	 *            邮件内容
	 * @return 地址
	 * @throws MessagingException
	 * @throws UnsupportedEncodingException
	 */
	private InternetAddress getFrom(MimeMessage msg) throws MessagingException, UnsupportedEncodingException {
		Address[] froms = msg.getFrom();
		if (froms.length < 1)
			throw new MessagingException("没有发件人!");

		return (InternetAddress) froms[0];
	}

	/**
	 * 根据收件人类型，获取邮件收件人、抄送和密送地址。如果收件人类型为空，则获得所有的收件人
	 * <p>
	 * Message.RecipientType.TO 收件人
	 * </p>
	 * <p>
	 * Message.RecipientType.CC 抄送
	 * </p>
	 * <p>
	 * Message.RecipientType.BCC 密送
	 * </p>
	 * 
	 * @param msg
	 *            邮件内容
	 * @param type
	 *            收件人类型
	 * @return 收件人1 <邮件地址1>, 收件人2 <邮件地址2>, ...
	 * @throws MessagingException
	 */
	private String getReceiveAddress(MimeMessage msg, Message.RecipientType type) throws MessagingException {
		StringBuffer receiveAddress = new StringBuffer();
		Address[] addresss = null;
		if (type == null) {
			addresss = msg.getAllRecipients();
		} else {
			addresss = msg.getRecipients(type);
		}

		if (addresss == null || addresss.length < 1)
			throw new MessagingException("没有收件人!");
		for (Address address : addresss) {
			InternetAddress internetAddress = (InternetAddress) address;
			receiveAddress.append(internetAddress.toUnicodeString()).append(",");
		}

		receiveAddress.deleteCharAt(receiveAddress.length() - 1); // 删除最后一个逗号

		return receiveAddress.toString();
	}
	
	/**
	 * 判断邮件中是否包含附件
	 * 
	 * @param msg
	 *            邮件内容
	 * @return 邮件中存在附件返回true，不存在返回false
	 * @throws MessagingException
	 * @throws IOException
	 */
	@SuppressWarnings("unused")
	private boolean isContainAttachment(Part part) throws MessagingException, IOException {
		boolean flag = false;
		if (part.isMimeType("multipart/*")) {
			MimeMultipart multipart = (MimeMultipart) part.getContent();
			int partCount = multipart.getCount();
			for (int i = 0; i < partCount; i++) {
				BodyPart bodyPart = multipart.getBodyPart(i);
				String disp = bodyPart.getDisposition();
				if (disp != null && (disp.equalsIgnoreCase(Part.ATTACHMENT) || disp.equalsIgnoreCase(Part.INLINE))) {
					flag = true;
				} else if (bodyPart.isMimeType("multipart/*")) {
					flag = isContainAttachment(bodyPart);
				} else {
					String contentType = bodyPart.getContentType();
					if (contentType.indexOf("application") != -1) {
						flag = true;
					}

					if (contentType.indexOf("name") != -1) {
						flag = true;
					}
				}

				if (flag)
					break;
			}
		} else if (part.isMimeType("message/rfc822")) {
			flag = isContainAttachment((Part) part.getContent());
		}
		return flag;
	}

	/**
	 * 保存附件
	 * 
	 * @param part
	 *            邮件中多个组合体中的其中一个组合体
	 * @param destDir
	 *            附件保存目录
	 * @throws UnsupportedEncodingException
	 * @throws MessagingException
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	private void saveAttachment(Part part, String destDir, String email, String sendName)
			throws UnsupportedEncodingException, MessagingException, FileNotFoundException, IOException {
		if (part.isMimeType("multipart/*")) {
			Multipart multipart = (Multipart) part.getContent(); // 复杂体邮件
			// 复杂体邮件包含多个邮件体
			int partCount = multipart.getCount();
			for (int i = 0; i < partCount; i++) {
				// 获得复杂体邮件中其中一个邮件体
				BodyPart bodyPart = multipart.getBodyPart(i);
				// 某一个邮件体也有可能是由多个邮件体组成的复杂体
				String disp = bodyPart.getDisposition();
				if (disp != null && (disp.equalsIgnoreCase(Part.ATTACHMENT) || disp.equalsIgnoreCase(Part.INLINE))) {
					InputStream is = bodyPart.getInputStream();
					this.saveFile(is, destDir, decodeText(bodyPart.getFileName()), email, sendName);
				} else if (bodyPart.isMimeType("multipart/*")) {
					saveAttachment(bodyPart, destDir, email, sendName);
				} else {
					String contentType = bodyPart.getContentType();
					if (contentType.indexOf("name") != -1 || contentType.indexOf("application") != -1) {
						this.saveFile(bodyPart.getInputStream(), destDir, decodeText(bodyPart.getFileName()), email,
								sendName);
					}
				}
			}
		} else if (part.isMimeType("message/rfc822")) {
			saveAttachment((Part) part.getContent(), destDir, email, sendName);
		}
	}

	/**
	 * 读取输入流中的数据保存至指定目录
	 * 
	 * @param is
	 *            输入流
	 * @param fileName
	 *            文件名
	 * @param destDir
	 *            文件存储目录
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	private void saveFile(InputStream is, String destDir, String fileName, String email, String sendName)
			throws FileNotFoundException, IOException {
		// 附件格式过滤
		// if(!TypeCastUtil.equals(RmdeskConfig.extname,
		// TypeCastUtil.getFileDot(fileName))){
		// return;
		// }

		DocInfo doc = new DocInfo();
		doc.setDocName(fileName);
		String uuidFilename = fileName;
		doc.setUrl(uuidFilename);
		doc.setBusinessLine("测试");
		// doc.setReceivedMode(Constant.OWNER_TYPE_EMAIL);
		doc.setReceivedTime(new Date());
		doc.setOwnerEmail(email);
		doc.setOwnerName(sendName);
		BufferedInputStream bis = new BufferedInputStream(is);
	
		BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(destDir+uuidFilename));
		int len = -1;
		while ((len = bis.read()) != -1) {
			bos.write(len);
			bos.flush();
		}
		// TODO:入库
		try {
			// infoMapper.insert(doc);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("----附件存入数据库失败了。。。。。");
		}
		
		bos.close();
		bis.close();
	}

	/**
	 * 文本解码
	 * 
	 * @param encodeText
	 *            解码MimeUtility.encodeText(String text)方法编码后的文本
	 * @return 解码后的文本
	 * @throws UnsupportedEncodingException
	 */
	private String decodeText(String encodeText) throws UnsupportedEncodingException {
		if (encodeText == null || "".equals(encodeText)) {
			return "";
		} else {
			return MimeUtility.decodeText(encodeText);
		}
	}

	public static void getMailTextContent(Part part, StringBuffer content) throws MessagingException, IOException {
		// 如果是文本类型的附件，通过getContent方法可以取到文本内容，但这不是我们需要的结果，所以在这里要做判断
		boolean isContainTextAttach = part.getContentType().indexOf("name") > 0;
		if (part.isMimeType("text/*") && !isContainTextAttach) {
			content.append(part.getContent().toString());
		} else if (part.isMimeType("message/rfc822")) {
			getMailTextContent((Part) part.getContent(), content);
		} else if (part.isMimeType("multipart/*")) {
			Multipart multipart = (Multipart) part.getContent();
			int partCount = multipart.getCount();
			
			for (int i = 0; i < partCount; i++) {
				BodyPart bodyPart = multipart.getBodyPart(i);
				getMailTextContent(bodyPart, content);
		
			}
		
		}
	}

	public static void main(String[] args) {

		MailHelper mailHelper = new MailHelper();
		mailHelper.readMail(getConfig());
	
		
		
	}

}
