package com.frame.mall.core.mail;

public class MailConfig {

	public String mailstoreprotocol;
	public Object mailimaphost;
	public String euser;
	public String epassword;
	public String type;

}
