function register(){

		var userName = $.trim($("#reguname").val());
		var passWord = $.trim($("#regpass").val());
		$.ajax({
			type : "post",
			url : "/admin/register.html",
			async : false,
			data : {
				userName : userName,
				passWord : passWord
			},
			dataType:"json",
			success : function(data){
				if(data.status == 200){
					layer.msg("注册成功", {icon: 6}, function(){
						location.href =  "/login";
					});
				}else if(data.status==400){
					layer.msg("用户名重复", {icon: 5});
				}else if(data.status==500){
					layer.msg("注册失败", {icon: 5});
				}else if(data.status==600){
					layer.msg("用户名或密码不能为空", {icon: 5});
				}else{
					layer.msg("错误", {icon: 5});
				}
			}
		});

}