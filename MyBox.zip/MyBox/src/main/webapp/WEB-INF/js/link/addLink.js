
var $;
var $form;
var form;
layui.config({
	base : "js/"
}).use(['form','layer','jquery','laydate'],function(){
	var layer = parent.layer === undefined ? layui.layer : parent.layer,
		laypage = layui.laypage,laydate = layui.laydate;
		$ = layui.jquery;
		form = layui.form;
	
		
	
		
		
	
	

 	form.on("submit(addLink)",function(data){
 	
 		//弹出loading
 		var index = layer.msg('数据提交中，请稍候',{icon: 16,time:2000,shade:0.8}); 	
 		$.ajax({
    		type: "post",
            url: "/link/AddLink",
            async:false,       
			data:$("#LinkForm").serialize(),
            dataType:"json",
			success:function(data){
				if(data.code==0){				
					layer.msg(data.msg);
		        	parent.location.reload();
				}else{
					layer.msg(data.msg,{icon:5});
				}
			}
        });
 		
 		return false;
 	})
	
});
