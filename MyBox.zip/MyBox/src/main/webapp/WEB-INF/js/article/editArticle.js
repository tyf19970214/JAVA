var arcontent ;
	$(function(){
		//实例化编辑器
		 arcontent = BLOG.createEditor("#article[name=arcontent]",{
			      resizeType : 1,
			      minWidth : 650,
			      height:315,
			      allowPreviewEmoticons : false,
			      allowImageUpload : true,
			      items : [
			       'fontname', 'fontsize', '|', 'forecolor', 'hilitecolor', 'bold', 'italic', 'underline',
			       'removeformat', '|', 'justifyleft', 'justifycenter', 'justifyright', 'insertorderedlist',
			       'insertunorderedlist', '|', 'emoticons',  'link','image'],
			       afterCreate: function () {
			               this.sync();
			            },
			            afterBlur:function(){this.sync();}
			     });
	});

var $;
var form;
layui.config({
	base : "js/"
}).use(['form','layer','jquery','laydate'],function(){
	var layer = parent.layer === undefined ? layui.layer : parent.layer,
		laydate = layui.laydate;
		$ = layui.jquery;
		form = layui.form;
		
	
		
		
		
		
		
		

		
 	form.on("submit(updArticle)",function(data){
 		
 		//弹出loading
 		var index = layer.msg('数据提交中，请稍候',{icon: 16,time:2000,shade:0.8}); 	
 		arcontent.sync();
 		$.ajax({
    		type: "post",
            url: "/article/updArticle",
            async:false,
            data:$("#article").serialize(),
			dataType:"json",
			success:function(data){
				if(data.code==0){					
		        	layer.msg(data.msg);
		        	location.reload();
				}else{
					layer.msg(data.msg);
				}
			}
        }); 	
 		
 		return false;
 	})
	
});
layui.use('upload', function () {
    var $ = layui.jquery
        , upload = layui.upload;
    //指定允许上传的文件类型
    upload.render({
        elem: '#test3'
        , url: '/upload/pic'
        , accept: 'file' //普通文件
        , done: function (res) {
         alert(res.data.src);
           $("[name=img]").val(res.data.src);
           document.getElementById('showimg').src = res.data.src; 
        }
    });
});