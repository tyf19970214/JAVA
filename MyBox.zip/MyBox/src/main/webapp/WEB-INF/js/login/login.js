layui.use(['form','layer','jquery'],function(){
    var form = layui.form,
        layer = parent.layer === undefined ? layui.layer : top.layer
        $ = layui.jquery;
        
    	$(window).resize(function(){
    		if($(".video-player").width() > $(window).width()){
    			$(".video-player").css({"height":$(window).height(),"width":"auto","left":-($(".video-player").width()-$(window).width())/2});
    		}else{
    			$(".video-player").css({"width":$(window).width(),"height":"auto","left":-($(".video-player").width()-$(window).width())/2});
    		}
    	}).resize();
	
    
    
    form.verify({
        name: function(value){
            if(value.length < 1){
                return '请填写用户名';
            }
        }
        ,password:function(value){
            if(value.length < 1){
                return '请填写密码';
            }
        }
        ,regpassword:function(value){
            if(value.length < 8 || value.length > 20){
                return '密码需要8-20位之间';
            }
        }
    });
    
    form.on("submit(submit)",function(data){
        action($(this));
    })
    
    $('.sendcode').click(function(){
        if ($('#userinfo').val() == '') return layer.tips('请填写', '#userinfo', {tips: [1, '#0FA6D8']});
        action($(this));
    })
    
    function action(_this){
        if ($('#TencentCaptcha').attr('data-appid'))
        $('#TencentCaptcha').click();
        else
        eval(_this.attr('id')+"()");
    }
            
    form.on("submit(creatid)",function(data){
        var btn = $(this);
        layer.msg('创建中...', {icon: 16,shade: 0.1,time:false});
        $.post(cmdurl+'act=creatid',
        {
            "id":$("input[id='newuserName']").val(),
            "email":$("input[id='email']").val(),
            "invitercode":$("input[id='invitercode']").val(),
            "csrfToken" : $('input[name=csrftoken]').val()
        },
        function (res){
            if (res.code == 1){
                layer.msg(res.msg, {icon: 16,shade: 0.1,time:false});
                setTimeout(function(){
                    window.location.href = loginsuccessurl;
                },1000);
            }else if (res.code == 2){
                layer.alert(res.msg,{icon:4}, function(){
                    window.location.href = loginurl;
                });
            }else if (res.code > 1){
                var data = JSON.stringify(res);
                if (res.data.fun != undefined)
                eval(res.data.fun+"("+data+");");
                else
                layer.alert(res.msg, {icon: res.code});
            }else{
                layer.alert(res.msg, {icon: 0});
            }
        },'json')
        return false;
    })

    form.on("submit(bindid)",function(data){
        var btn = $(this);
        layer.msg('绑定中...', {icon: 16,shade: 0.1,time:false});
        $.post(cmdurl+'act=bindid',
        {
            "userName":$("input[id='userName']").val(),
            "password":$("input[id='password']").val(),
            "csrfToken" : $('input[name=csrftoken]').val()
        },
        function (res){
            if (res.code == 1){
                layer.msg('绑定成功，正在登陆...', {icon: 16,shade: 0.1,time:false});
                setTimeout(function(){
                    window.location.href = loginsuccessurl;
                },1000);
            }else if (res.code > 1){
                var data = JSON.stringify(res);
                if (res.data.fun != undefined)
                eval(res.data.fun+"("+data+");");
                else
                layer.alert(res.msg, {icon: res.code});
            }else{
                layer.alert(res.msg, {icon: 2});
            }
        },'json')
        return false;
    })
    
    $('.jump').click(function(){
        layer.confirm('将自动创建并绑定为“**_******”的账号，且以后无法自助修改！确定继续？', {
            btn: ['确定','取消']
        }, function(){
            layer.msg('注册中...', {icon: 16,shade: 0.1,time:false});
            $.get(cmdurl + 'act=jump&inviter='+$("input[id='invitercode']").val(),function(res){
                if (res.code == 1){
                    layer.msg('注册成功，正在登陆……', {icon: 16,shade: 0.1,time:false});
                    setTimeout(function(){
                        window.location.href = loginsuccessurl;
                    },1000);
                }else if (res.code > 1){
                    var data = JSON.stringify(res);
                    if (res.data.fun != undefined)
                    eval(res.data.fun+"("+data+");");
                    else
                    layer.alert(res.msg, {icon: res.code});
                }else{
                    layer.alert(res.msg,{icon:2});
                    return false;
                }
            },'json')
        });
    })
    
    $(".pw").focus(function(){
        document.getElementsByClassName("pw")[0].type = "text";
    }) 
    
    $(".pw").blur(function(){
        document.getElementsByClassName("pw")[0].type = "password";
    }) 
    
    $(".veritymsg").focus(function(){
        if (regneademaicode == 1)
        layer.tips('注册后帐号需要邮箱激活才能登录', '.veritymsg', {
            tips: [1, '#0FA6D8']
        });
    })
    
    $(".pw").bind('input propertychange', function() { 
        if ($(this).val().length < 8) {
            $(this).parent().find('label').html('长度不够');
        }else{
            $(this).parent().find('label').html('密码');
        }
    }); 
    
    form.on("submit(forget)",function(data){
        layer.msg('正在修改密码...', {icon: 16,shade: 0.1,time:false});
        $.post(cmdurl+'act=resetpassword',{
            "userinfo":$("input[id='userinfo']").val(),
            "emailcode":$("input[id='emailcode']").val(),
            "newpw":$("input[id='newpw']").val(),
            "csrfToken" : $('input[name=csrftoken]').val()
            },function (res){
                if (res.code == 1){
                    layer.alert(res.msg,{icon:res.code},function(){
                        setTimeout(function(){
                            window.location.href = loginsuccessurl;
                        },1000);
                    });
                }else if (res.code > 1){
                    var data = JSON.stringify(res);
                    if (res.data.fun != undefined)
                    eval(res.data.fun+"("+data+");");
                    else
                    layer.alert(res.msg, {icon: res.code});
                }else{
                    layer.alert(res.msg,{icon:res.code});
                }
            },'json')
        return false;
    })
    
    $(".loginBody .input-item").click(function(e){
        e.stopPropagation();
        $(this).addClass("layui-input-focus").find(".layui-input").focus();
    })
    
    $(".loginBody .layui-form-item .layui-input").focus(function(){
        $(this).parent().addClass("layui-input-focus");
    })
    $(".loginBody .layui-form-item .layui-input").blur(function(){
        $(this).parent().removeClass("layui-input-focus");
        if($(this).val() != ''){
            $(this).parent().addClass("layui-input-active");
        }else{
            $(this).parent().removeClass("layui-input-active");
        }
    })
    
    if ($('#invitercode').val() != '') $('#invitercode').parent().addClass("layui-input-active");
    
    $(".autosel").focus();
    
})
$(document).keypress(function(e) {
	if (e.which == 13){
        $('[lay-submit]').click();
	}
});

function login(captcha){
    var userName = $("input[id='userName']").val();
    var password = MD5($("input[id='password']").val());
    layer.msg('登陆中', {icon: 16,shade: 0.1,time:false});
    $.post(cmdurl+'act=login',
    {
        "userName":userName,
        "password":password,
        "code":$("input[id='code']").val(),
        "remember":$("input[name='remember']").attr('checked'),
        "csrfToken" : $('input[name=csrftoken]').val(),
        "captcha" : captcha
    },
    function (res){
        $("input[id='code']").val('');
        $('.logincode').attr('src',bloghost+'zb_system/script/c_validcode.php?id=login&tm='+Math.random());
        if (res.code == 1){
            layer.msg('登陆成功', {icon: 1,shade: 0.1,time:false});
            setTimeout(function(){
                window.location.href = loginsuccessurl;
            },1000);            
        }else if (res.code == 2){
            layer.confirm(res.msg, {
                btn: ['重新发送','重设邮箱','确定'],
                icon:4
            },function(){
                layer.msg('正在发送...', {icon: 16,shade: 0.1,time:false});
                $.getJSON(cmdurl+'act=SendEmailVerify',function(data){
                    if (data.code == 1){
                        layer.alert('邮件发送成功 请及时点击邮件中的验证链接 ',{icon:1});
                    }else if (data.code == 2){
                        layer.alert('已经验证过了，无需再次验证！',{icon:0});
                    }else{
                        layer.alert('发送失败! 请检查你设置的邮箱，或者联系管理员',{icon:2});
                    }
                })
            },function(){
                layer.prompt({title: '输入新邮箱'}, function(str, index){
                    layer.msg('正在发送...', {icon: 16,shade: 0.1,time:false});
                    $.post(cmdurl+'act=SendEmailVerify&newemail='+str,function(data){
                        layer.closeAll('dialog');
                        if (data.code == 1){
                            layer.closeAll();
                            layer.alert('邮件发送成功 请及时点击邮件中的验证链接 ',{icon:1});
                        }else{
                            layer.alert(data.msg,{icon:2});
                        }
                    },'json')
                });
            });
        }else if (res.code > 1){
            var data = JSON.stringify(res);
            if (res.data.fun != undefined)
            eval(res.data.fun+"("+data+");");
            else
            layer.alert(res.msg, {icon: res.code});
        }else{
            layer.alert(res.msg, {icon: 2});
        }
    },'json')
    return false;
}

function reg(captcha){
    layer.msg('正在注册...', {icon: 16,shade: 0.1,time:false});
    var btn = $(this);
    var idlen = $("input[id='reguserName']").val().length;
    var pwlen = $("input[id='regpw']").val().length;
    if (idlen < 3 || idlen > 20){
        layer.alert('用户名最低3位最高20位', {icon: 0});
        return false;
    }
    if (pwlen < 8){
        layer.alert('密码长度不够', {icon: 0});
        return false;
    }
    $.post(cmdurl+'act=reg',
        {
            "reguserName":$("input[id='reguserName']").val(),
            "regpw":$("input[id='regpw']").val(),
            "regemail":$("input[id='regemail']").val(),
            "nickname":$("input[id='nickname']").val(),
            "code":$("input[id='regcode']").val(),
            "invitercode":$("input[id='invitercode']").val(),
            "emailcode":$("input[id='emailcode']").val(),
            "csrfToken" : $('input[name=csrftoken]').val(),
            "codetype" : 'reg',
            "captcha" : captcha
        },function (res){
            $("input[id='regcode']").val('');
            $('.regcode').attr('src',bloghost+'zb_system/script/c_validcode.php?id=reg&tm='+Math.random());
            if (res.code == 1){
                layer.msg(res.msg, {icon: 16,shade: 0.1,time:false});
                setTimeout(function(){
                    window.location.href = loginsuccessurl;
                },1000);
            }else if (res.code == 2){
                layer.alert(res.msg,{icon:4}, function(){
                    window.location.href = loginurl;
                });
            }else if (res.code > 1){
                var data = JSON.stringify(res);
                if (res.data.fun != undefined)
                eval(res.data.fun+"("+data+");");
                else
                layer.alert(res.msg, {icon: res.code});
            }else{
                layer.alert(res.msg, {icon: 2});
            }
        },'json')
    return false;
}

function forget(captcha){
    layer.msg('正在查找账户...', {icon: 16,shade: 0.1,time:false});
    var btn = $('#forget');
    var userinfo = $("input[id='userinfo']");
    if (userinfo.val()==''){
        userinfo.focus();
        layer.msg('请输入用户名或者邮箱', {icon: 0});
        return false;
    }
    $.post(cmdurl+'act=forget',{
        "userinfo":userinfo.val(),
        "code":$("input[id='forgetcode']").val(),
        "csrfToken" : $('input[name=csrftoken]').val(),
        "captcha" : captcha
        },function (res){
            if (res.code == 1){
                layer.msg('验证码已发送',{icon:1});
                btn.addClass('layui-btn-disabled').attr('disabled','disabled');
                var n = 60;
                var interval = setInterval(function(){
                    btn.html('重新发送 '+n);
                    if(n-- == 0){
                        clearInterval(interval);
                        btn.removeClass('layui-btn-disabled').removeAttr('disabled').html('发送验证码');
                        return false;
                    }
                },1000)
                $('.submit').removeAttr('disabled').removeClass('layui-btn-disabled');
            }else if (res.code > 1){
                var data = JSON.stringify(res);
                if (res.data.fun != undefined)
                eval(res.data.fun+"("+data+");");
                else
                layer.alert(res.msg, {icon: res.code});
            }else{
                layer.msg(res.msg,{icon:res.code},function(){});
                $("input[id='forgetcode']").val('');
                $('.gpwcode').attr('src',bloghost+'zb_system/script/c_validcode.php?id=forget&tm='+Math.random());
            }
        },'json')
    return false;
}