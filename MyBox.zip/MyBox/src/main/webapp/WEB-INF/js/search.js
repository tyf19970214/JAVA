/*layui.use('form',function(){
          var form=layui.form;
        //form start
	   form.on('submit(search)', function (res) {

         
        });
	
	
	
	//form end
});*/
function search(){
	
	  var querytitle=$.trim($("#querytitle").val());
	  alert(querytitle+"..............要查询的文章标题");
	  var querysimpledes=$.trim($("#querysimpledes").val());
	  alert(querysimpledes+"...........要查询的文章简介");
	    var queryusers=$.trim($("#queryusers").val());
	  alert(queryusers+"...........要查询的文章作者");
	  $.ajax({
	  url:"/admin/article/search",
	  type:"post",
	  dataType:"json",
	  data:{
		  querytitle:querytitle,
	  querysimpledes:querysimpledes,
	  queryusers:queryusers
	  
	  
	  },
	  success:function(data){
	  if(data.status==200){
	location.reload(); 
	  }

	  }
	  
	  
	  
	  });
	
	
}