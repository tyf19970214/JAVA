var $;
var $form;
var form;
layui.config({
	base : "js/"
}).use(['form','layer','jquery','laydate'],function(){
	var layer = parent.layer === undefined ? layui.layer : parent.layer,
		laypage = layui.laypage,laydate = layui.laydate;
		$ = layui.jquery;
		form = layui.form;
		laydate.render({
			elem: '#birthday' //指定元素
			,max: 'new Date()'
		});
		
		//自定义验证规则
		form.verify({ 
			pass: [/(.+){6,16}$/, '密码必须6到16位']
			,repass: function(value){
				var repassvalue = $('#password').val();
				if(value != repassvalue){
					return '两次输入的密码不一致!';
				}
			}
		});
		//检验用户名是否存在
		$("#username").blur(function(){
			$.ajax({
	            type: "post",
	            url: "/user/checkUserByUserName?username="+$("#username").val(),
	            success:function(data){
	            	if(data.code!=0){
	            		layer.msg(data.msg);
	            		$("#username").val("");
	            		$("#username").focus();
	            	}
	            }
	        });
		});
		//检验昵称是否一致
		$("#nickname").blur(function(){
			$.ajax({
	            type: "post",
	            url: "/user/checkUserByNickname?nickname="+$("#nickname").val(),
	            success:function(data){
	            	if(data.code!=0){
	            		layer.msg(data.msg);
	            		$("#nickname").val("");
	            		$("#nickname").focus();
	            	}
	            }
	        });
		});
		//检验邮箱是否有用
		$("#email").blur(function(){
			$.ajax({
				type: "post",
				url: "/user/checkUserByEmail?email="+$("#email").val(),
				success:function(data){
					if(data.code!=0){
						layer.msg(data.msg);
						$("#email").val("");
						$("#email").focus();
					}
				}
			});
		});

 	form.on("submit(addUser)",function(data){
 		//弹出loading
 		var index = layer.msg('数据提交中，请稍候',{icon: 16,time:false,shade:0.8});
 		var msg,flag=false;
 		$.ajax({
    		type: "post",
            url: "/user/insertUser",
            async:false,
            data:data.field,
			dataType:"json",
			success:function(d){
				if(d.code==0){
		        	msg="用户添加成功，请通知用户查收邮件以激活账号！";
		        	flag=true;
		        	$("#auf")[0].reset();
				}else{
		        	msg=d.msg;
				}
			}
        });
 		setTimeout(function(){
 			layer.close(index);
 			if(flag){
 				layer.msg(msg,{icon: 1});
 			}else{
 				layer.msg(msg,{icon: 5});
 			}
 			//layer.closeAll("iframe");
 			//刷新父页面
	 		//parent.location.reload();
        },2000);
 		return false;
 	})
	
});
layui.use('upload', function () {
    var $ = layui.jquery
        , upload = layui.upload;
    //指定允许上传的文件类型
    upload.render({
        elem: '#test3'
        , url: '/upload/pic'
        , accept: 'file' //普通文件
        , done: function (res) {
         alert(res.data.src);
           $("[name=picpath]").val(res.data.src);
           document.getElementById('showimg').src = res.data.src; 
        }
    });
});