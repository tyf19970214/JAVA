var $;
var form;
layui.config({
	base : "js/"
}).use(['form','layer','jquery','laydate'],function(){
	var layer = parent.layer === undefined ? layui.layer : parent.layer,
		laydate = layui.laydate;
		$ = layui.jquery;
		form = layui.form;
		
		laydate.render({
			elem: '#birthday' //指定元素
			,max: 'new Date()'
		});
		
		$("#username").blur(function(){
			$.ajax({
	            type: "get",
	            url: "/user/checkUserByUserName?uid="+$("#uid").val()+"&username="+$("#username").val(),
	            success:function(data){
	            	if(data.code!=0){
	            		layer.msg(data.msg);
	            		$("#username").val("");
	            		$("#username").focus();
	            	}
	            }
	        });
		});
		
		$("#nickname").blur(function(){
			$.ajax({
	            type: "get",
	            url: "/user/checkUserByNickname?uid="+$("#uid").val()+"&nickname="+$("#nickname").val(),
	            success:function(data){
	            	if(data.code!=0){
	            		layer.msg(data.msg);
	            		$("#nickname").val("");
	            		$("#nickname").focus();
	            	}
	            }
	        });
		});
		
		$("#email").blur(function(){
			$.ajax({
				type: "post",
				url: "/user/checkUserByEmail?uid="+$("#uid").val()+"&email="+$("#email").val(),
				success:function(data){
					if(data.code!=0){
						layer.msg(data.msg);
						$("#email").val("");
						$("#email").focus();
					}
				}
			});
		});

		
 	form.on("submit(updUser)",function(data){
 		//弹出loading
 		var index = layer.msg('数据提交中，请稍候',{icon: 16,time:false,shade:0.8});
 		var msg;
 		$.ajax({
    		type: "post",
            url: "/user/updUser",
            data:data.field,
			dataType:"json",
			success:function(d){
				if(d.code==0){
		        	msg="修改成功！";
				}else{
		        	msg=d.msg;
				}
			}
        });
 		setTimeout(function(){
 			layer.close(index);
 			layer.msg(msg);
 			layer.closeAll("iframe");
 			//刷新父页面
	 		parent.location.reload();
        },2000);
 		return false;
 	})
	
});
layui.use('upload', function () {
    var $ = layui.jquery
        , upload = layui.upload;
    //指定允许上传的文件类型
    upload.render({
        elem: '#test3'
        , url: '/upload/pic'
        , accept: 'file' //普通文件
        , done: function (res) {    
          $("[name=picpath]").val(res.data.src);     
    document.getElementById('showimg').src = res.data.src; 
        }
    });
});