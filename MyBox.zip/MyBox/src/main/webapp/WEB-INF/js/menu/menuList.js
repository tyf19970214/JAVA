   layui.use(['element', 'layer', 'form', 'upload', 'treeGrid','jquery'], function () {
        var treeGrid = layui.treeGrid, form = layui.form,//很重要
        $ = layui.jquery,table = layui.table;
        var treeTable =treeGrid.render({
        	id:'treeTable'
            ,elem: '#treeTable'
            ,url:'/menu/menuData'
            ,cellMinWidth: 100
            ,treeId:'menuId'//树形id字段名称
            ,treeUpId:'parentId'//树形父id字段名称
            ,treeShowName:'title'//以树形式显示的字段
            ,cols: [[
                {field: 'menuId',title: ' ',templet:"#radioTpl",unresize:true}
                ,{field:'title', title: '菜单名'}
                ,{field:'icon', title: '图标',templet: '#iconTpl'}
                ,{field:'href',title: '链接'}
                ,{field:'perms',title: '权限标识'}
            ]]
            ,page:false
        });
        
        $("#addMenu").click(function(){
        	var a = $("input[name='menuId']:checked").val();
        	if(a==undefined||a!=1){
        		if(a==undefined){
        			a=0;
        		}
        		//添加顶级菜单
        		layer.open({
		    	  type: 2,
		    	  title:"添加菜单",
		    	  area: ['470px', '360px'],
		    	  content:"/menu/toSaveMenu/"+a //这里content是一个普通的String
		      })
        	}else{
        		layer.msg("此菜单不允许操作！",{icon: 5});
        		return;
        	}
        	
        })
        
        $("#editMenu").click(function(){
        	var a = $("input[name='menuId']:checked").val();
        	if(a==undefined){
        		layer.msg("请选择要操作的菜单！",{icon: 5});
        		return;
        	}
        	if(a==1){
        		layer.msg("不允许操作的菜单！",{icon: 5});
        		return;
        	}
        		//添加顶级菜单
        		layer.open({
		    	  type: 2,
		    	  title:"编辑菜单",
		    	  area: ['470px', '360px'],
		    	  content:"/menu/toEditMenu/"+a //这里content是一个普通的String
		      })
        	
        })
        
        $("#delMenu").click(function(){
        	var a = $("input[name='menuId']:checked").val();
        	if(a==undefined){
        		layer.msg("请选择要操作的菜单！",{icon: 5});
        		return;
        	}
        	if(a==1){
        		layer.msg("不允许删除！",{icon: 5});
        		return;
        	}
        	layer.confirm('真的删除行么', function(index){
		    	  $.ajax({
		    		  url:'/menu/delMenuById/'+a,
		    		  type : "post",
		    		  success : function(d){
		    			  if(d.code==0){
		    				  layer.msg("删除成功！",{icon: 1});
		    				  setTimeout(function(){
		    				  		parent.location.reload();
		    			        },500);
		    			  }else{
		    				  layer.msg(d.msg,{icon: 5});
		    			  }
		    		  }
		    	  })
		        layer.close(index);
		      });
        	
        })
        
        
    });