package com.box.utils;

import java.util.Map;

public class PictureUtils {
	
	private Integer code;
	private String msg;
	private Map<String,String> data;
	public Integer getCode() {
		return code;
	}
	public void setCode(Integer code) {
		this.code = code;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public Map<String, String> getData() {
		return data;
	}
	public void setData(Map<String, String> data) {
		this.data = data;
	}
	@Override
	public String toString() {
		return "PictureUtils [code=" + code + ", msg=" + msg + ", data=" + data
				+ "]";
	}
	public PictureUtils(Integer code, String msg, Map<String, String> data) {
		super();
		this.code = code;
		this.msg = msg;
		this.data = data;
	}
	public PictureUtils() {
		super();
		// TODO Auto-generated constructor stub
	}


}
