package com.box.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Properties;

public class SystemInfo {
	  //当前实例
    public static SystemInfo currentSystem=null;
    public InetAddress localHost=null;
    
    private SystemInfo()
    {
        try {
            localHost = InetAddress.getLocalHost();
        } catch (UnknownHostException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    
    /**
     * 单例模式获取对象
     * @return
     */
    public static SystemInfo getInstance()
    {
        if(currentSystem==null)
            currentSystem= new SystemInfo();
        return currentSystem;
    }
    /**
     * 本地IP
     * @return IP地址
     */
    public String getIP()
    {
        String ip=localHost.getHostAddress();
        return ip;
    }
    /**
     * 获取用户机器名称
     * @return
     */
    public String getHostName()
    {
        return localHost.getHostName();
    }
    
    /**
     * 获取C盘卷 序列号
     * @return
     */
    public String getDiskNumber()
    {
          String line = "";
          String HdSerial = "";//记录硬盘序列号

          try {

           Process proces = Runtime.getRuntime().exec("cmd /c dir c:");//获取命令行参数
           BufferedReader buffreader = new BufferedReader(
             new InputStreamReader(proces.getInputStream()));

           while ((line = buffreader.readLine()) != null) {

            if (line.indexOf("卷的序列号是 ") != -1) {  //读取参数并获取硬盘序列号

             HdSerial = line.substring(line.indexOf("卷的序列号是 ")
               + "卷的序列号是 ".length(), line.length());
             break;
            }
           }

          } catch (IOException e) {
           // TODO Auto-generated catch block
           e.printStackTrace();
          }

          return HdSerial;
    }
    
    /**
     * 获取Mac地址
     * @return Mac地址，例如：F0-4D-A2-39-24-A6
     */
    public String getMac()
    {
        NetworkInterface byInetAddress;
        try {
            byInetAddress = NetworkInterface.getByInetAddress(localHost);
            byte[] hardwareAddress = byInetAddress.getHardwareAddress();
            return getMacFromBytes(hardwareAddress);
        } catch (SocketException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;        
    }
    
    /**
     * 获取当前系统名称
     * @return 当前系统名，例如： windows xp
     */
    public String getSystemName()
    {
        Properties sysProperty = System.getProperties();
        //系统名称
        String systemName=sysProperty.getProperty("os.name");
        return systemName;
    }
    
    private  String getMacFromBytes(byte[] bytes)
    {
        StringBuffer mac=new StringBuffer();
        byte currentByte;
        boolean first=false;
        for (byte b : bytes) {
            if(first)
            {
                mac.append("-");    
            }
            currentByte=(byte)((b&240)>>4);
            mac.append(Integer.toHexString(currentByte));
            currentByte=(byte)(b&15);
            mac.append(Integer.toHexString(currentByte));
            first=true;
        }
        return mac.toString().toUpperCase();
    }
    //获取端口号
    public static String getOpenPorts() {
        String line = "";
        String HdSerial = "";//记录硬盘序列号
        StringBuffer buf = new StringBuffer(""); 
        try {
         Process proces = Runtime.getRuntime().exec("cmd /c netstat -a");//获取命令行参数
         BufferedReader buffreader = new BufferedReader(
           new InputStreamReader(proces.getInputStream()));
       
         while ((line = buffreader.readLine()) != null) {
          buf.append(line+"\n");
          System.out.println(line);
          }
        } catch (IOException e) {
         // TODO Auto-generated catch block
         e.printStackTrace();
        }
        return buf.toString();
       }

    //VBS文件获取硬盘系列号
    public static String getSerialNumber(String drive) {
        String result = "";
          try {
            File file = File.createTempFile("realhowto",".vbs");
            file.deleteOnExit();
            FileWriter fw = new java.io.FileWriter(file);
            String vbs = "Set objFSO = CreateObject(\"Scripting.FileSystemObject\")\n"
                        +"Set colDrives = objFSO.Drives\n"
                        +"Set objDrive = colDrives.item(\"" + drive + "\")\n"
                        +"Wscript.Echo objDrive.SerialNumber";  // see note
            fw.write(vbs);
            fw.close();
            Process p = Runtime.getRuntime().exec("cscript //NoLogo " + file.getPath());
            BufferedReader input =
              new BufferedReader
                (new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = input.readLine()) != null) {
               result += line;
            }
            input.close();
          }
          catch(Exception e){
              e.printStackTrace();
          }
          return result.trim();
        }

    public static void main(String[] args) {
		SystemInfo s=new SystemInfo();
		String hostName = s.getHostName();
		System.out.println(hostName);
		System.out.println(s.getSystemName());
		System.out.println(s.getMac());
		System.out.println(s.getIP());
	}

}
