package com.box.utils;

import java.util.List;



public class LayuiResult {
	private Integer code;
	private String msg;
	private Long count;
	private Object data;
	
	public LayuiResult () {
		super();
	}

	public LayuiResult (Integer code) {
		super();
		this.code = code;
	}

	public LayuiResult (Integer code, String msg) {
		super();
		this.code = code;
		this.msg = msg;
	}
	
	public Integer getCode() {
		return code;
	}

	public void setCode(Integer code) {
		this.code = code;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}


	public Long getCount() {
		return count;
	}

	public void setCount(Long count) {
		this.count = count;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public static LayuiResult  ok(){
		return new LayuiResult (0);
	}
	
	public static LayuiResult  ok(Object list){
		LayuiResult  result = new LayuiResult ();
		result.setCode(0);
		result.setData(list);;
		return result;
	}
	public static LayuiResult  ok(String msg){
		LayuiResult  result = new LayuiResult ();
		result.setCode(0);
		result.setMsg(msg);
		return result;
	}
	
	public static LayuiResult  error(){
		return new LayuiResult (500,"没有此权限，请联系超管！");
	}
	public static LayuiResult  error(String str){
		return new LayuiResult (500,str);
	}
}
