package com.box.mapper;

import com.box.entity.DbBtype;
import com.box.entity.DbBtypeExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface DbBtypeMapper {
    int countByExample(DbBtypeExample example);

    int deleteByExample(DbBtypeExample example);

    int deleteByPrimaryKey(Integer tid);

    int insert(DbBtype record);

    int insertSelective(DbBtype record);

    List<DbBtype> selectByExample(DbBtypeExample example);

    DbBtype selectByPrimaryKey(Integer tid);

    int updateByExampleSelective(@Param("record") DbBtype record, @Param("example") DbBtypeExample example);

    int updateByExample(@Param("record") DbBtype record, @Param("example") DbBtypeExample example);

    int updateByPrimaryKeySelective(DbBtype record);

    int updateByPrimaryKey(DbBtype record);
}