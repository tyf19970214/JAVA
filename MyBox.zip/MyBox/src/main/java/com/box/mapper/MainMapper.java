package com.box.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Select;

import com.box.entity.DbUsers;

public interface MainMapper {
	
	//查询当日用户增加量
		@Select("select * from db_users where to_days(lasttime) = to_days(now());")
		public List<DbUsers> selUsersToday();
		
		//查询昨日用户增加量
		@Select("SELECT * FROM db_users WHERE TO_DAYS( NOW( ) ) - TO_DAYS( lasttime)= 1  ")
		public List<DbUsers> selUsersYesterday();
		
		//查询本周用户增加量
		@Select("SELECT * FROM  db_users WHERE YEARWEEK(date_format(lasttime,'%Y-%m-%d')) = YEARWEEK(now());")
		public List<DbUsers> selUsersYearWeek();
		
		//查询当月用户增加量
		@Select("SELECT * FROM db_users WHERE DATE_FORMAT( lasttime, '%Y%m' ) = DATE_FORMAT( CURDATE( ) , '%Y%m' )")
		public List<DbUsers> selUsersMonth();

}
