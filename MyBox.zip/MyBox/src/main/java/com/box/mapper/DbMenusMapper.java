package com.box.mapper;

import com.box.entity.DbMenus;
import com.box.entity.DbMenusExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface DbMenusMapper {
    int countByExample(DbMenusExample example);

    int deleteByExample(DbMenusExample example);

    int deleteByPrimaryKey(Long menuId);

    int insert(DbMenus record);

    int insertSelective(DbMenus record);

    List<DbMenus> selectByExample(DbMenusExample example);

    DbMenus selectByPrimaryKey(Long menuId);

    int updateByExampleSelective(@Param("record") DbMenus record, @Param("example") DbMenusExample example);

    int updateByExample(@Param("record") DbMenus record, @Param("example") DbMenusExample example);

    int updateByPrimaryKeySelective(DbMenus record);

    int updateByPrimaryKey(DbMenus record);
}