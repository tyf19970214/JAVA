package com.box.mapper;

import com.box.entity.DbReseme;
import com.box.entity.DbResemeExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface DbResemeMapper {
    int countByExample(DbResemeExample example);

    int deleteByExample(DbResemeExample example);

    int deleteByPrimaryKey(Integer infoid);

    int insert(DbReseme record);

    int insertSelective(DbReseme record);

    List<DbReseme> selectByExample(DbResemeExample example);

    DbReseme selectByPrimaryKey(Integer infoid);

    int updateByExampleSelective(@Param("record") DbReseme record, @Param("example") DbResemeExample example);

    int updateByExample(@Param("record") DbReseme record, @Param("example") DbResemeExample example);

    int updateByPrimaryKeySelective(DbReseme record);

    int updateByPrimaryKey(DbReseme record);
}