package com.box.mapper;

import com.box.entity.DbBlog;
import com.box.entity.DbBlogExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface DbBlogMapper {
    int countByExample(DbBlogExample example);

    int deleteByExample(DbBlogExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(DbBlog record);

    int insertSelective(DbBlog record);

    List<DbBlog> selectByExample(DbBlogExample example);

    DbBlog selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") DbBlog record, @Param("example") DbBlogExample example);

    int updateByExample(@Param("record") DbBlog record, @Param("example") DbBlogExample example);

    int updateByPrimaryKeySelective(DbBlog record);

    int updateByPrimaryKey(DbBlog record);
}