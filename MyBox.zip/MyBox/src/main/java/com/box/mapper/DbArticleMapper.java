package com.box.mapper;

import com.box.entity.DbArticle;
import com.box.entity.DbArticleExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface DbArticleMapper {
    int countByExample(DbArticleExample example);

    int deleteByExample(DbArticleExample example);

    int deleteByPrimaryKey(Integer arid);

    int insert(DbArticle record);

    int insertSelective(DbArticle record);

    List<DbArticle> selectByExample(DbArticleExample example);

    DbArticle selectByPrimaryKey(Integer arid);

    int updateByExampleSelective(@Param("record") DbArticle record, @Param("example") DbArticleExample example);

    int updateByExample(@Param("record") DbArticle record, @Param("example") DbArticleExample example);

    int updateByPrimaryKeySelective(DbArticle record);

    int updateByPrimaryKey(DbArticle record);
}