package com.box.mapper;

import com.box.entity.DbArticletype;
import com.box.entity.DbArticletypeExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface DbArticletypeMapper {
    int countByExample(DbArticletypeExample example);

    int deleteByExample(DbArticletypeExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(DbArticletype record);

    int insertSelective(DbArticletype record);

    List<DbArticletype> selectByExample(DbArticletypeExample example);

    DbArticletype selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") DbArticletype record, @Param("example") DbArticletypeExample example);

    int updateByExample(@Param("record") DbArticletype record, @Param("example") DbArticletypeExample example);

    int updateByPrimaryKeySelective(DbArticletype record);

    int updateByPrimaryKey(DbArticletype record);
}