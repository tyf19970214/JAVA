package com.box.mapper;

import com.box.entity.DbEmail;
import com.box.entity.DbEmailExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface DbEmailMapper {
    int countByExample(DbEmailExample example);

    int deleteByExample(DbEmailExample example);

    int deleteByPrimaryKey(String eid);

    int insert(DbEmail record);

    int insertSelective(DbEmail record);

    List<DbEmail> selectByExample(DbEmailExample example);

    DbEmail selectByPrimaryKey(String eid);

    int updateByExampleSelective(@Param("record") DbEmail record, @Param("example") DbEmailExample example);

    int updateByExample(@Param("record") DbEmail record, @Param("example") DbEmailExample example);

    int updateByPrimaryKeySelective(DbEmail record);

    int updateByPrimaryKey(DbEmail record);
}