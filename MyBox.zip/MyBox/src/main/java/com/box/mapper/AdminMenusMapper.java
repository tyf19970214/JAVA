package com.box.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.box.entity.DbMenus;

public interface AdminMenusMapper {
	@Select("SELECT m.menu_id as menuId,m.title,m.icon,m.href,m.spread,m.parent_id as parentId,m.perms FROM db_roles_menus r LEFT JOIN db_menus m ON r.menu_id = m.menu_id WHERE r.role_id = #{roleId}")
	List<DbMenus> getMenus(@Param("roleId") Long roleId);

}
