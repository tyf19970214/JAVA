package com.box.mapper;

import com.box.entity.DbAlbum;
import com.box.entity.DbAlbumExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface DbAlbumMapper {
    int countByExample(DbAlbumExample example);

    int deleteByExample(DbAlbumExample example);

    int deleteByPrimaryKey(Integer alid);

    int insert(DbAlbum record);

    int insertSelective(DbAlbum record);

    List<DbAlbum> selectByExample(DbAlbumExample example);

    DbAlbum selectByPrimaryKey(Integer alid);

    int updateByExampleSelective(@Param("record") DbAlbum record, @Param("example") DbAlbumExample example);

    int updateByExample(@Param("record") DbAlbum record, @Param("example") DbAlbumExample example);

    int updateByPrimaryKeySelective(DbAlbum record);

    int updateByPrimaryKey(DbAlbum record);
}