package com.box.mapper;

import com.box.entity.DbTheme;
import com.box.entity.DbThemeExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface DbThemeMapper {
    int countByExample(DbThemeExample example);

    int deleteByExample(DbThemeExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(DbTheme record);

    int insertSelective(DbTheme record);

    List<DbTheme> selectByExampleWithBLOBs(DbThemeExample example);

    List<DbTheme> selectByExample(DbThemeExample example);

    DbTheme selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") DbTheme record, @Param("example") DbThemeExample example);

    int updateByExampleWithBLOBs(@Param("record") DbTheme record, @Param("example") DbThemeExample example);

    int updateByExample(@Param("record") DbTheme record, @Param("example") DbThemeExample example);

    int updateByPrimaryKeySelective(DbTheme record);

    int updateByPrimaryKeyWithBLOBs(DbTheme record);

    int updateByPrimaryKey(DbTheme record);
}