package com.box.mapper;

import com.box.entity.DbMusics;
import com.box.entity.DbMusicsExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface DbMusicsMapper {
    int countByExample(DbMusicsExample example);

    int deleteByExample(DbMusicsExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(DbMusics record);

    int insertSelective(DbMusics record);

    List<DbMusics> selectByExample(DbMusicsExample example);

    DbMusics selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") DbMusics record, @Param("example") DbMusicsExample example);

    int updateByExample(@Param("record") DbMusics record, @Param("example") DbMusicsExample example);

    int updateByPrimaryKeySelective(DbMusics record);

    int updateByPrimaryKey(DbMusics record);
}