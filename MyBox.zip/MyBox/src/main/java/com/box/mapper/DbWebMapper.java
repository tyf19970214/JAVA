package com.box.mapper;

import com.box.entity.DbWeb;
import com.box.entity.DbWebExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface DbWebMapper {
    int countByExample(DbWebExample example);

    int deleteByExample(DbWebExample example);

    int deleteByPrimaryKey(Integer wid);

    int insert(DbWeb record);

    int insertSelective(DbWeb record);

    List<DbWeb> selectByExample(DbWebExample example);

    DbWeb selectByPrimaryKey(Integer wid);

    int updateByExampleSelective(@Param("record") DbWeb record, @Param("example") DbWebExample example);

    int updateByExample(@Param("record") DbWeb record, @Param("example") DbWebExample example);

    int updateByPrimaryKeySelective(DbWeb record);

    int updateByPrimaryKey(DbWeb record);
}