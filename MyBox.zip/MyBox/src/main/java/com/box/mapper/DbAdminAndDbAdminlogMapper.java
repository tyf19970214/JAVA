package com.box.mapper;

import java.util.List;

import com.box.entity.ResultAdminLog;

public interface DbAdminAndDbAdminlogMapper {
	   List<ResultAdminLog> selectByManyTable(Integer aid);
}
