package com.box.mapper;

import com.box.entity.DbFilestype;
import com.box.entity.DbFilestypeExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface DbFilestypeMapper {
    int countByExample(DbFilestypeExample example);

    int deleteByExample(DbFilestypeExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(DbFilestype record);

    int insertSelective(DbFilestype record);

    List<DbFilestype> selectByExample(DbFilestypeExample example);

    DbFilestype selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") DbFilestype record, @Param("example") DbFilestypeExample example);

    int updateByExample(@Param("record") DbFilestype record, @Param("example") DbFilestypeExample example);

    int updateByPrimaryKeySelective(DbFilestype record);

    int updateByPrimaryKey(DbFilestype record);
}