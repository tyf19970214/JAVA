package com.box.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.box.entity.DbUserAndDbArticleResultAndDbArticleType;
import com.box.entity.QueryType;

public interface DbUserAndDbArticleResultAndDbArticleTypeMapper {

	//查询列表
	List<DbUserAndDbArticleResultAndDbArticleType> selectByThreeTables(@Param("page") Integer page,@Param("limit") Integer limit);
	//返回总记录数
	Integer selectByThreePages();
	//通过文章id查三表数据，先查再修改。
	DbUserAndDbArticleResultAndDbArticleType selectByThreeTablesById(@Param("arid") Integer arid,@Param("uid") Integer uid,@Param("id") Integer typeid);

}
