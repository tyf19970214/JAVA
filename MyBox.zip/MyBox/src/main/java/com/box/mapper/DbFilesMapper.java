package com.box.mapper;

import com.box.entity.DbFiles;
import com.box.entity.DbFilesExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface DbFilesMapper {
    int countByExample(DbFilesExample example);

    int deleteByExample(DbFilesExample example);

    int deleteByPrimaryKey(Long id);

    int insert(DbFiles record);

    int insertSelective(DbFiles record);

    List<DbFiles> selectByExample(DbFilesExample example);

    DbFiles selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") DbFiles record, @Param("example") DbFilesExample example);

    int updateByExample(@Param("record") DbFiles record, @Param("example") DbFilesExample example);

    int updateByPrimaryKeySelective(DbFiles record);

    int updateByPrimaryKey(DbFiles record);
}