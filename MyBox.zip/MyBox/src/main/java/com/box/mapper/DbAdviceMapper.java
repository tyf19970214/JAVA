package com.box.mapper;

import com.box.entity.DbAdvice;
import com.box.entity.DbAdviceExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface DbAdviceMapper {
    int countByExample(DbAdviceExample example);

    int deleteByExample(DbAdviceExample example);

    int deleteByPrimaryKey(Integer advid);

    int insert(DbAdvice record);

    int insertSelective(DbAdvice record);

    List<DbAdvice> selectByExample(DbAdviceExample example);

    DbAdvice selectByPrimaryKey(Integer advid);

    int updateByExampleSelective(@Param("record") DbAdvice record, @Param("example") DbAdviceExample example);

    int updateByExample(@Param("record") DbAdvice record, @Param("example") DbAdviceExample example);

    int updateByPrimaryKeySelective(DbAdvice record);

    int updateByPrimaryKey(DbAdvice record);
}