package com.box.mapper;

import com.box.entity.DbReplymessage;
import com.box.entity.DbReplymessageExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface DbReplymessageMapper {
    int countByExample(DbReplymessageExample example);

    int deleteByExample(DbReplymessageExample example);

    int deleteByPrimaryKey(Integer rid);

    int insert(DbReplymessage record);

    int insertSelective(DbReplymessage record);

    List<DbReplymessage> selectByExample(DbReplymessageExample example);

    DbReplymessage selectByPrimaryKey(Integer rid);

    int updateByExampleSelective(@Param("record") DbReplymessage record, @Param("example") DbReplymessageExample example);

    int updateByExample(@Param("record") DbReplymessage record, @Param("example") DbReplymessageExample example);

    int updateByPrimaryKeySelective(DbReplymessage record);

    int updateByPrimaryKey(DbReplymessage record);
}