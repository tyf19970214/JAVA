package com.box.mapper;

import com.box.entity.DbLivmes;
import com.box.entity.DbLivmesExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface DbLivmesMapper {
    int countByExample(DbLivmesExample example);

    int deleteByExample(DbLivmesExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(DbLivmes record);

    int insertSelective(DbLivmes record);

    List<DbLivmes> selectByExample(DbLivmesExample example);

    DbLivmes selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") DbLivmes record, @Param("example") DbLivmesExample example);

    int updateByExample(@Param("record") DbLivmes record, @Param("example") DbLivmesExample example);

    int updateByPrimaryKeySelective(DbLivmes record);

    int updateByPrimaryKey(DbLivmes record);
}