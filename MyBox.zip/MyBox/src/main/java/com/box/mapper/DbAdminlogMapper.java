package com.box.mapper;

import com.box.entity.DbAdminlog;
import com.box.entity.DbAdminlogExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface DbAdminlogMapper {
    int countByExample(DbAdminlogExample example);

    int deleteByExample(DbAdminlogExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(DbAdminlog record);

    int insertSelective(DbAdminlog record);

    List<DbAdminlog> selectByExample(DbAdminlogExample example);

    DbAdminlog selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") DbAdminlog record, @Param("example") DbAdminlogExample example);

    int updateByExample(@Param("record") DbAdminlog record, @Param("example") DbAdminlogExample example);

    int updateByPrimaryKeySelective(DbAdminlog record);

    int updateByPrimaryKey(DbAdminlog record);
}