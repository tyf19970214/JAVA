package com.box.mapper;

import com.box.entity.DbRoles;
import com.box.entity.DbRolesExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface DbRolesMapper {
    int countByExample(DbRolesExample example);

    int deleteByExample(DbRolesExample example);

    int deleteByPrimaryKey(Long roleId);

    int insert(DbRoles record);

    int insertSelective(DbRoles record);

    List<DbRoles> selectByExample(DbRolesExample example);

    DbRoles selectByPrimaryKey(Long roleId);

    int updateByExampleSelective(@Param("record") DbRoles record, @Param("example") DbRolesExample example);

    int updateByExample(@Param("record") DbRoles record, @Param("example") DbRolesExample example);

    int updateByPrimaryKeySelective(DbRoles record);

    int updateByPrimaryKey(DbRoles record);
}