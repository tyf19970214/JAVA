package com.box.mapper;

import com.box.entity.DbUsers;
import com.box.entity.DbUsersExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface DbUsersMapper {
    int countByExample(DbUsersExample example);

    int deleteByExample(DbUsersExample example);

    int deleteByPrimaryKey(Long uid);

    int insert(DbUsers record);

    int insertSelective(DbUsers record);

    List<DbUsers> selectByExample(DbUsersExample example);

    DbUsers selectByPrimaryKey(Long uid);

    int updateByExampleSelective(@Param("record") DbUsers record, @Param("example") DbUsersExample example);

    int updateByExample(@Param("record") DbUsers record, @Param("example") DbUsersExample example);

    int updateByPrimaryKeySelective(DbUsers record);

    int updateByPrimaryKey(DbUsers record);
}