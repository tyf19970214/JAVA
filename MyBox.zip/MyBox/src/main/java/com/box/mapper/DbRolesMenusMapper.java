package com.box.mapper;

import com.box.entity.DbRolesMenusExample;
import com.box.entity.DbRolesMenusKey;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface DbRolesMenusMapper {
    int countByExample(DbRolesMenusExample example);

    int deleteByExample(DbRolesMenusExample example);

    int deleteByPrimaryKey(DbRolesMenusKey key);

    int insert(DbRolesMenusKey record);

    int insertSelective(DbRolesMenusKey record);

    List<DbRolesMenusKey> selectByExample(DbRolesMenusExample example);

    int updateByExampleSelective(@Param("record") DbRolesMenusKey record, @Param("example") DbRolesMenusExample example);

    int updateByExample(@Param("record") DbRolesMenusKey record, @Param("example") DbRolesMenusExample example);
}