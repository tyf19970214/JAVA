package com.box.entity;

public class DbBtype {
    private Integer tid;

    private String tname;

    private String tdes;

    private Integer tclickhit;

    public Integer getTid() {
        return tid;
    }

    public void setTid(Integer tid) {
        this.tid = tid;
    }

    public String getTname() {
        return tname;
    }

    public void setTname(String tname) {
        this.tname = tname == null ? null : tname.trim();
    }

    public String getTdes() {
        return tdes;
    }

    public void setTdes(String tdes) {
        this.tdes = tdes == null ? null : tdes.trim();
    }

    public Integer getTclickhit() {
        return tclickhit;
    }

    public void setTclickhit(Integer tclickhit) {
        this.tclickhit = tclickhit;
    }
}