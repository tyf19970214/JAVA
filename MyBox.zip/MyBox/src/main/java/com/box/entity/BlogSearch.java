package com.box.entity;

public class BlogSearch {
	
	private String title;
	private String typeid;
	private String uppid;
	private String keyword;
	private String content;
	private String summary;
	private String createTimeStart;
	private String createTimeEnd;
	private String operation;
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getTypeid() {
		return typeid;
	}
	public void setTypeid(String typeid) {
		this.typeid = typeid;
	}
	public String getUppid() {
		return uppid;
	}
	public void setUppid(String uppid) {
		this.uppid = uppid;
	}
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getSummary() {
		return summary;
	}
	public void setSummary(String summary) {
		this.summary = summary;
	}
	public String getCreateTimeStart() {
		return createTimeStart;
	}
	public void setCreateTimeStart(String createTimeStart) {
		this.createTimeStart = createTimeStart;
	}
	public String getCreateTimeEnd() {
		return createTimeEnd;
	}
	public void setCreateTimeEnd(String createTimeEnd) {
		this.createTimeEnd = createTimeEnd;
	}
	public String getOperation() {
		return operation;
	}
	public void setOperation(String operation) {
		this.operation = operation;
	}
	@Override
	public String toString() {
		return "BlogSearch [title=" + title + ", typeid=" + typeid + ", uppid="
				+ uppid + ", keyword=" + keyword + ", content=" + content
				+ ", summary=" + summary + ", createTimeStart="
				+ createTimeStart + ", createTimeEnd=" + createTimeEnd
				+ ", operation=" + operation + "]";
	}
	public BlogSearch(String title, String typeid, String uppid,
			String keyword, String content, String summary,
			String createTimeStart, String createTimeEnd, String operation) {
		super();
		this.title = title;
		this.typeid = typeid;
		this.uppid = uppid;
		this.keyword = keyword;
		this.content = content;
		this.summary = summary;
		this.createTimeStart = createTimeStart;
		this.createTimeEnd = createTimeEnd;
		this.operation = operation;
	}
	public BlogSearch() {
		super();
		// TODO Auto-generated constructor stub
	}

}
