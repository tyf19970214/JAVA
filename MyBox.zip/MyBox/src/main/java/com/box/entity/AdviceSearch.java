package com.box.entity;

import java.io.UnsupportedEncodingException;

public class AdviceSearch {
	private String advtitle;
	private String advcontent;
	private String aid;
	private String advdescribe;
	private String createTimeStart;
	private String createTimeEnd;
	private String operation;
	public AdviceSearch() {
		super();
		// TODO Auto-generated constructor stub
	}
	public AdviceSearch(String advtitle, String advcontent, String aid,
			String advdescribe, String createTimeStart, String createTimeEnd,
			String operation) {
		super();
		this.advtitle = advtitle;
		this.advcontent = advcontent;
		this.aid = aid;
		this.advdescribe = advdescribe;
		this.createTimeStart = createTimeStart;
		this.createTimeEnd = createTimeEnd;
		this.operation = operation;
	}
	@Override
	public String toString() {
		return "AdviceSearch [advtitle=" + advtitle + ", advcontent="
				+ advcontent + ", aid=" + aid + ", advdescribe=" + advdescribe
				+ ", createTimeStart=" + createTimeStart + ", createTimeEnd="
				+ createTimeEnd + ", operation=" + operation + "]";
	}
	public String getAdvtitle() {
		return advtitle;
	}
	public void setAdvtitle(String advtitle) {
		try {
			advtitle=new String(advtitle.getBytes("iso8859-1"),"UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.advtitle = advtitle;
	}
	public String getAdvcontent() {
		return advcontent;
	}
	public void setAdvcontent(String advcontent) {
		try {
			advcontent=new String(advcontent.getBytes("iso8859-1"),"utf-8");
		} catch (Exception e) {
			// TODO: handle exception
		}
		this.advcontent = advcontent;
	}
	public String getAid() {
		return aid;
	}
	public void setAid(String aid) {
		this.aid = aid;
	}
	public String getAdvdescribe() {
		return advdescribe;
	}
	public void setAdvdescribe(String advdescribe) {
		try {
			advdescribe=new String(advdescribe.getBytes("iso8859-1"),"utf-8");
		} catch (Exception e) {
			// TODO: handle exception
		}
		this.advdescribe = advdescribe;
	}
	public String getCreateTimeStart() {
		return createTimeStart;
	}
	public void setCreateTimeStart(String createTimeStart) {
		this.createTimeStart = createTimeStart;
	}
	public String getCreateTimeEnd() {
		return createTimeEnd;
	}
	public void setCreateTimeEnd(String createTimeEnd) {
		this.createTimeEnd = createTimeEnd;
	}
	public String getOperation() {
		return operation;
	}
	public void setOperation(String operation) {
		this.operation = operation;
	}
	

}
