package com.box.entity;

public class QueryType {
	private String artitle;
	private String simpledes;
	private String users;
	private Integer page;
	private Integer limit;
	public String getArtitle() {
		return artitle;
	}
	public void setArtitle(String artitle) {
		this.artitle = artitle;
	}
	public String getSimpledes() {
		return simpledes;
	}
	public void setSimpledes(String simpledes) {
		this.simpledes = simpledes;
	}
	public String getUsers() {
		return users;
	}
	public void setUsers(String users) {
		this.users = users;
	}
	public Integer getPage() {
		return page;
	}
	public void setPage(Integer page) {
		this.page = page;
	}
	public Integer getLimit() {
		return limit;
	}
	public void setLimit(Integer limit) {
		this.limit = limit;
	}
	@Override
	public String toString() {
		return "QueryType [artitle=" + artitle + ", simpledes=" + simpledes
				+ ", users=" + users + ", page=" + page + ", limit=" + limit
				+ "]";
	}
	public QueryType(String artitle, String simpledes, String users,
			Integer page, Integer limit) {
		super();
		this.artitle = artitle;
		this.simpledes = simpledes;
		this.users = users;
		this.page = page;
		this.limit = limit;
	}
	public QueryType() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
