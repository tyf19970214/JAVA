package com.box.entity;

import java.util.Date;

public class DbReplymessage {
    private Integer rid;

    private String rcontent;

    private Date rcreatetime;

    private Integer lvid;

    private Integer uid;

    private Integer status;

    private Boolean isview;

    private String reson;

    public Integer getRid() {
        return rid;
    }

    public void setRid(Integer rid) {
        this.rid = rid;
    }

    public String getRcontent() {
        return rcontent;
    }

    public void setRcontent(String rcontent) {
        this.rcontent = rcontent == null ? null : rcontent.trim();
    }

    public Date getRcreatetime() {
        return rcreatetime;
    }

    public void setRcreatetime(Date rcreatetime) {
        this.rcreatetime = rcreatetime;
    }

    public Integer getLvid() {
        return lvid;
    }

    public void setLvid(Integer lvid) {
        this.lvid = lvid;
    }

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Boolean getIsview() {
        return isview;
    }

    public void setIsview(Boolean isview) {
        this.isview = isview;
    }

    public String getReson() {
        return reson;
    }

    public void setReson(String reson) {
        this.reson = reson == null ? null : reson.trim();
    }
}