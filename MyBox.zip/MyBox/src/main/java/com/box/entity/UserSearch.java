package com.box.entity;

public class UserSearch {
	private String username;
	private String email;
	private String nickname;
	private String sex;
	private String status;
	private String createTimeStart;
	private String createTimeEnd;
	private String operation;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
	
		this.username = username;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		try {
			nickname=new String(nickname.getBytes("ISO-8859-1"),"UTF-8");
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		this.nickname = nickname;

	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		
		this.sex = sex;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCreateTimeStart() {
		return createTimeStart;
	}
	public void setCreateTimeStart(String createTimeStart) {
		this.createTimeStart = createTimeStart;
	}
	public String getCreateTimeEnd() {
		return createTimeEnd;
	}
	public void setCreateTimeEnd(String createTimeEnd) {
		this.createTimeEnd = createTimeEnd;
	}
	public String getOperation() {
		return operation;
	}
	public void setOperation(String operation) {
		this.operation = operation;
	}
	public UserSearch() {
		super();
		// TODO Auto-generated constructor stub
	}
	public UserSearch(String username, String email, String nickname,
			String sex, String status, String createTimeStart,
			String createTimeEnd, String operation) {
		super();
		this.username = username;
		this.email = email;
		this.nickname = nickname;
		this.sex = sex;
		this.status = status;
		this.createTimeStart = createTimeStart;
		this.createTimeEnd = createTimeEnd;
		this.operation = operation;
	}
	@Override
	public String toString() {
		return "UserSearch [username=" + username + ", email=" + email
				+ ", nickname=" + nickname + ", sex=" + sex + ", status="
				+ status + ", createTimeStart=" + createTimeStart
				+ ", createTimeEnd=" + createTimeEnd + ", operation="
				+ operation + "]";
	}
	
}
