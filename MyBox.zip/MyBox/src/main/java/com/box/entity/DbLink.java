package com.box.entity;

public class DbLink {
    private Integer id;

    private String lname;

    private String lpath;

    private String ldes;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname == null ? null : lname.trim();
    }

    public String getLpath() {
        return lpath;
    }

    public void setLpath(String lpath) {
        this.lpath = lpath == null ? null : lpath.trim();
    }

    public String getLdes() {
        return ldes;
    }

    public void setLdes(String ldes) {
        this.ldes = ldes == null ? null : ldes.trim();
    }
}