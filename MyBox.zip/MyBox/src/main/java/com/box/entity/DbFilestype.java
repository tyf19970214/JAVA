package com.box.entity;

public class DbFilestype {
    private Integer id;

    private String fname;

    private String fdescri;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname == null ? null : fname.trim();
    }

    public String getFdescri() {
        return fdescri;
    }

    public void setFdescri(String fdescri) {
        this.fdescri = fdescri == null ? null : fdescri.trim();
    }
}