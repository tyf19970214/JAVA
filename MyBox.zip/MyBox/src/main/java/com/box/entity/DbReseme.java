package com.box.entity;

import java.util.Date;

public class DbReseme {
    private Integer infoid;

    private String realname;

    private String idcard;

    private String phonenumber;

    private String sex;

    private String collage;

    private String marriaged;

    private Date startworktime;

    private Date endworktime;

    private String worktype;

    private String workname;

    private Date startschooltime;

    private Date endschooltime;

    private String experence;

    private String educational;

    public Integer getInfoid() {
        return infoid;
    }

    public void setInfoid(Integer infoid) {
        this.infoid = infoid;
    }

    public String getRealname() {
        return realname;
    }

    public void setRealname(String realname) {
        this.realname = realname == null ? null : realname.trim();
    }

    public String getIdcard() {
        return idcard;
    }

    public void setIdcard(String idcard) {
        this.idcard = idcard == null ? null : idcard.trim();
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber == null ? null : phonenumber.trim();
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex == null ? null : sex.trim();
    }

    public String getCollage() {
        return collage;
    }

    public void setCollage(String collage) {
        this.collage = collage == null ? null : collage.trim();
    }

    public String getMarriaged() {
        return marriaged;
    }

    public void setMarriaged(String marriaged) {
        this.marriaged = marriaged == null ? null : marriaged.trim();
    }

    public Date getStartworktime() {
        return startworktime;
    }

    public void setStartworktime(Date startworktime) {
        this.startworktime = startworktime;
    }

    public Date getEndworktime() {
        return endworktime;
    }

    public void setEndworktime(Date endworktime) {
        this.endworktime = endworktime;
    }

    public String getWorktype() {
        return worktype;
    }

    public void setWorktype(String worktype) {
        this.worktype = worktype == null ? null : worktype.trim();
    }

    public String getWorkname() {
        return workname;
    }

    public void setWorkname(String workname) {
        this.workname = workname == null ? null : workname.trim();
    }

    public Date getStartschooltime() {
        return startschooltime;
    }

    public void setStartschooltime(Date startschooltime) {
        this.startschooltime = startschooltime;
    }

    public Date getEndschooltime() {
        return endschooltime;
    }

    public void setEndschooltime(Date endschooltime) {
        this.endschooltime = endschooltime;
    }

    public String getExperence() {
        return experence;
    }

    public void setExperence(String experence) {
        this.experence = experence == null ? null : experence.trim();
    }

    public String getEducational() {
        return educational;
    }

    public void setEducational(String educational) {
        this.educational = educational == null ? null : educational.trim();
    }
}