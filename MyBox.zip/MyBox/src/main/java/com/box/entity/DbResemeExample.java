package com.box.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class DbResemeExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public DbResemeExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andInfoidIsNull() {
            addCriterion("infoid is null");
            return (Criteria) this;
        }

        public Criteria andInfoidIsNotNull() {
            addCriterion("infoid is not null");
            return (Criteria) this;
        }

        public Criteria andInfoidEqualTo(Integer value) {
            addCriterion("infoid =", value, "infoid");
            return (Criteria) this;
        }

        public Criteria andInfoidNotEqualTo(Integer value) {
            addCriterion("infoid <>", value, "infoid");
            return (Criteria) this;
        }

        public Criteria andInfoidGreaterThan(Integer value) {
            addCriterion("infoid >", value, "infoid");
            return (Criteria) this;
        }

        public Criteria andInfoidGreaterThanOrEqualTo(Integer value) {
            addCriterion("infoid >=", value, "infoid");
            return (Criteria) this;
        }

        public Criteria andInfoidLessThan(Integer value) {
            addCriterion("infoid <", value, "infoid");
            return (Criteria) this;
        }

        public Criteria andInfoidLessThanOrEqualTo(Integer value) {
            addCriterion("infoid <=", value, "infoid");
            return (Criteria) this;
        }

        public Criteria andInfoidIn(List<Integer> values) {
            addCriterion("infoid in", values, "infoid");
            return (Criteria) this;
        }

        public Criteria andInfoidNotIn(List<Integer> values) {
            addCriterion("infoid not in", values, "infoid");
            return (Criteria) this;
        }

        public Criteria andInfoidBetween(Integer value1, Integer value2) {
            addCriterion("infoid between", value1, value2, "infoid");
            return (Criteria) this;
        }

        public Criteria andInfoidNotBetween(Integer value1, Integer value2) {
            addCriterion("infoid not between", value1, value2, "infoid");
            return (Criteria) this;
        }

        public Criteria andRealnameIsNull() {
            addCriterion("realname is null");
            return (Criteria) this;
        }

        public Criteria andRealnameIsNotNull() {
            addCriterion("realname is not null");
            return (Criteria) this;
        }

        public Criteria andRealnameEqualTo(String value) {
            addCriterion("realname =", value, "realname");
            return (Criteria) this;
        }

        public Criteria andRealnameNotEqualTo(String value) {
            addCriterion("realname <>", value, "realname");
            return (Criteria) this;
        }

        public Criteria andRealnameGreaterThan(String value) {
            addCriterion("realname >", value, "realname");
            return (Criteria) this;
        }

        public Criteria andRealnameGreaterThanOrEqualTo(String value) {
            addCriterion("realname >=", value, "realname");
            return (Criteria) this;
        }

        public Criteria andRealnameLessThan(String value) {
            addCriterion("realname <", value, "realname");
            return (Criteria) this;
        }

        public Criteria andRealnameLessThanOrEqualTo(String value) {
            addCriterion("realname <=", value, "realname");
            return (Criteria) this;
        }

        public Criteria andRealnameLike(String value) {
            addCriterion("realname like", value, "realname");
            return (Criteria) this;
        }

        public Criteria andRealnameNotLike(String value) {
            addCriterion("realname not like", value, "realname");
            return (Criteria) this;
        }

        public Criteria andRealnameIn(List<String> values) {
            addCriterion("realname in", values, "realname");
            return (Criteria) this;
        }

        public Criteria andRealnameNotIn(List<String> values) {
            addCriterion("realname not in", values, "realname");
            return (Criteria) this;
        }

        public Criteria andRealnameBetween(String value1, String value2) {
            addCriterion("realname between", value1, value2, "realname");
            return (Criteria) this;
        }

        public Criteria andRealnameNotBetween(String value1, String value2) {
            addCriterion("realname not between", value1, value2, "realname");
            return (Criteria) this;
        }

        public Criteria andIdcardIsNull() {
            addCriterion("idcard is null");
            return (Criteria) this;
        }

        public Criteria andIdcardIsNotNull() {
            addCriterion("idcard is not null");
            return (Criteria) this;
        }

        public Criteria andIdcardEqualTo(String value) {
            addCriterion("idcard =", value, "idcard");
            return (Criteria) this;
        }

        public Criteria andIdcardNotEqualTo(String value) {
            addCriterion("idcard <>", value, "idcard");
            return (Criteria) this;
        }

        public Criteria andIdcardGreaterThan(String value) {
            addCriterion("idcard >", value, "idcard");
            return (Criteria) this;
        }

        public Criteria andIdcardGreaterThanOrEqualTo(String value) {
            addCriterion("idcard >=", value, "idcard");
            return (Criteria) this;
        }

        public Criteria andIdcardLessThan(String value) {
            addCriterion("idcard <", value, "idcard");
            return (Criteria) this;
        }

        public Criteria andIdcardLessThanOrEqualTo(String value) {
            addCriterion("idcard <=", value, "idcard");
            return (Criteria) this;
        }

        public Criteria andIdcardLike(String value) {
            addCriterion("idcard like", value, "idcard");
            return (Criteria) this;
        }

        public Criteria andIdcardNotLike(String value) {
            addCriterion("idcard not like", value, "idcard");
            return (Criteria) this;
        }

        public Criteria andIdcardIn(List<String> values) {
            addCriterion("idcard in", values, "idcard");
            return (Criteria) this;
        }

        public Criteria andIdcardNotIn(List<String> values) {
            addCriterion("idcard not in", values, "idcard");
            return (Criteria) this;
        }

        public Criteria andIdcardBetween(String value1, String value2) {
            addCriterion("idcard between", value1, value2, "idcard");
            return (Criteria) this;
        }

        public Criteria andIdcardNotBetween(String value1, String value2) {
            addCriterion("idcard not between", value1, value2, "idcard");
            return (Criteria) this;
        }

        public Criteria andPhonenumberIsNull() {
            addCriterion("phonenumber is null");
            return (Criteria) this;
        }

        public Criteria andPhonenumberIsNotNull() {
            addCriterion("phonenumber is not null");
            return (Criteria) this;
        }

        public Criteria andPhonenumberEqualTo(String value) {
            addCriterion("phonenumber =", value, "phonenumber");
            return (Criteria) this;
        }

        public Criteria andPhonenumberNotEqualTo(String value) {
            addCriterion("phonenumber <>", value, "phonenumber");
            return (Criteria) this;
        }

        public Criteria andPhonenumberGreaterThan(String value) {
            addCriterion("phonenumber >", value, "phonenumber");
            return (Criteria) this;
        }

        public Criteria andPhonenumberGreaterThanOrEqualTo(String value) {
            addCriterion("phonenumber >=", value, "phonenumber");
            return (Criteria) this;
        }

        public Criteria andPhonenumberLessThan(String value) {
            addCriterion("phonenumber <", value, "phonenumber");
            return (Criteria) this;
        }

        public Criteria andPhonenumberLessThanOrEqualTo(String value) {
            addCriterion("phonenumber <=", value, "phonenumber");
            return (Criteria) this;
        }

        public Criteria andPhonenumberLike(String value) {
            addCriterion("phonenumber like", value, "phonenumber");
            return (Criteria) this;
        }

        public Criteria andPhonenumberNotLike(String value) {
            addCriterion("phonenumber not like", value, "phonenumber");
            return (Criteria) this;
        }

        public Criteria andPhonenumberIn(List<String> values) {
            addCriterion("phonenumber in", values, "phonenumber");
            return (Criteria) this;
        }

        public Criteria andPhonenumberNotIn(List<String> values) {
            addCriterion("phonenumber not in", values, "phonenumber");
            return (Criteria) this;
        }

        public Criteria andPhonenumberBetween(String value1, String value2) {
            addCriterion("phonenumber between", value1, value2, "phonenumber");
            return (Criteria) this;
        }

        public Criteria andPhonenumberNotBetween(String value1, String value2) {
            addCriterion("phonenumber not between", value1, value2, "phonenumber");
            return (Criteria) this;
        }

        public Criteria andSexIsNull() {
            addCriterion("sex is null");
            return (Criteria) this;
        }

        public Criteria andSexIsNotNull() {
            addCriterion("sex is not null");
            return (Criteria) this;
        }

        public Criteria andSexEqualTo(String value) {
            addCriterion("sex =", value, "sex");
            return (Criteria) this;
        }

        public Criteria andSexNotEqualTo(String value) {
            addCriterion("sex <>", value, "sex");
            return (Criteria) this;
        }

        public Criteria andSexGreaterThan(String value) {
            addCriterion("sex >", value, "sex");
            return (Criteria) this;
        }

        public Criteria andSexGreaterThanOrEqualTo(String value) {
            addCriterion("sex >=", value, "sex");
            return (Criteria) this;
        }

        public Criteria andSexLessThan(String value) {
            addCriterion("sex <", value, "sex");
            return (Criteria) this;
        }

        public Criteria andSexLessThanOrEqualTo(String value) {
            addCriterion("sex <=", value, "sex");
            return (Criteria) this;
        }

        public Criteria andSexLike(String value) {
            addCriterion("sex like", value, "sex");
            return (Criteria) this;
        }

        public Criteria andSexNotLike(String value) {
            addCriterion("sex not like", value, "sex");
            return (Criteria) this;
        }

        public Criteria andSexIn(List<String> values) {
            addCriterion("sex in", values, "sex");
            return (Criteria) this;
        }

        public Criteria andSexNotIn(List<String> values) {
            addCriterion("sex not in", values, "sex");
            return (Criteria) this;
        }

        public Criteria andSexBetween(String value1, String value2) {
            addCriterion("sex between", value1, value2, "sex");
            return (Criteria) this;
        }

        public Criteria andSexNotBetween(String value1, String value2) {
            addCriterion("sex not between", value1, value2, "sex");
            return (Criteria) this;
        }

        public Criteria andCollageIsNull() {
            addCriterion("collage is null");
            return (Criteria) this;
        }

        public Criteria andCollageIsNotNull() {
            addCriterion("collage is not null");
            return (Criteria) this;
        }

        public Criteria andCollageEqualTo(String value) {
            addCriterion("collage =", value, "collage");
            return (Criteria) this;
        }

        public Criteria andCollageNotEqualTo(String value) {
            addCriterion("collage <>", value, "collage");
            return (Criteria) this;
        }

        public Criteria andCollageGreaterThan(String value) {
            addCriterion("collage >", value, "collage");
            return (Criteria) this;
        }

        public Criteria andCollageGreaterThanOrEqualTo(String value) {
            addCriterion("collage >=", value, "collage");
            return (Criteria) this;
        }

        public Criteria andCollageLessThan(String value) {
            addCriterion("collage <", value, "collage");
            return (Criteria) this;
        }

        public Criteria andCollageLessThanOrEqualTo(String value) {
            addCriterion("collage <=", value, "collage");
            return (Criteria) this;
        }

        public Criteria andCollageLike(String value) {
            addCriterion("collage like", value, "collage");
            return (Criteria) this;
        }

        public Criteria andCollageNotLike(String value) {
            addCriterion("collage not like", value, "collage");
            return (Criteria) this;
        }

        public Criteria andCollageIn(List<String> values) {
            addCriterion("collage in", values, "collage");
            return (Criteria) this;
        }

        public Criteria andCollageNotIn(List<String> values) {
            addCriterion("collage not in", values, "collage");
            return (Criteria) this;
        }

        public Criteria andCollageBetween(String value1, String value2) {
            addCriterion("collage between", value1, value2, "collage");
            return (Criteria) this;
        }

        public Criteria andCollageNotBetween(String value1, String value2) {
            addCriterion("collage not between", value1, value2, "collage");
            return (Criteria) this;
        }

        public Criteria andMarriagedIsNull() {
            addCriterion("marriaged is null");
            return (Criteria) this;
        }

        public Criteria andMarriagedIsNotNull() {
            addCriterion("marriaged is not null");
            return (Criteria) this;
        }

        public Criteria andMarriagedEqualTo(String value) {
            addCriterion("marriaged =", value, "marriaged");
            return (Criteria) this;
        }

        public Criteria andMarriagedNotEqualTo(String value) {
            addCriterion("marriaged <>", value, "marriaged");
            return (Criteria) this;
        }

        public Criteria andMarriagedGreaterThan(String value) {
            addCriterion("marriaged >", value, "marriaged");
            return (Criteria) this;
        }

        public Criteria andMarriagedGreaterThanOrEqualTo(String value) {
            addCriterion("marriaged >=", value, "marriaged");
            return (Criteria) this;
        }

        public Criteria andMarriagedLessThan(String value) {
            addCriterion("marriaged <", value, "marriaged");
            return (Criteria) this;
        }

        public Criteria andMarriagedLessThanOrEqualTo(String value) {
            addCriterion("marriaged <=", value, "marriaged");
            return (Criteria) this;
        }

        public Criteria andMarriagedLike(String value) {
            addCriterion("marriaged like", value, "marriaged");
            return (Criteria) this;
        }

        public Criteria andMarriagedNotLike(String value) {
            addCriterion("marriaged not like", value, "marriaged");
            return (Criteria) this;
        }

        public Criteria andMarriagedIn(List<String> values) {
            addCriterion("marriaged in", values, "marriaged");
            return (Criteria) this;
        }

        public Criteria andMarriagedNotIn(List<String> values) {
            addCriterion("marriaged not in", values, "marriaged");
            return (Criteria) this;
        }

        public Criteria andMarriagedBetween(String value1, String value2) {
            addCriterion("marriaged between", value1, value2, "marriaged");
            return (Criteria) this;
        }

        public Criteria andMarriagedNotBetween(String value1, String value2) {
            addCriterion("marriaged not between", value1, value2, "marriaged");
            return (Criteria) this;
        }

        public Criteria andStartworktimeIsNull() {
            addCriterion("startworktime is null");
            return (Criteria) this;
        }

        public Criteria andStartworktimeIsNotNull() {
            addCriterion("startworktime is not null");
            return (Criteria) this;
        }

        public Criteria andStartworktimeEqualTo(Date value) {
            addCriterion("startworktime =", value, "startworktime");
            return (Criteria) this;
        }

        public Criteria andStartworktimeNotEqualTo(Date value) {
            addCriterion("startworktime <>", value, "startworktime");
            return (Criteria) this;
        }

        public Criteria andStartworktimeGreaterThan(Date value) {
            addCriterion("startworktime >", value, "startworktime");
            return (Criteria) this;
        }

        public Criteria andStartworktimeGreaterThanOrEqualTo(Date value) {
            addCriterion("startworktime >=", value, "startworktime");
            return (Criteria) this;
        }

        public Criteria andStartworktimeLessThan(Date value) {
            addCriterion("startworktime <", value, "startworktime");
            return (Criteria) this;
        }

        public Criteria andStartworktimeLessThanOrEqualTo(Date value) {
            addCriterion("startworktime <=", value, "startworktime");
            return (Criteria) this;
        }

        public Criteria andStartworktimeIn(List<Date> values) {
            addCriterion("startworktime in", values, "startworktime");
            return (Criteria) this;
        }

        public Criteria andStartworktimeNotIn(List<Date> values) {
            addCriterion("startworktime not in", values, "startworktime");
            return (Criteria) this;
        }

        public Criteria andStartworktimeBetween(Date value1, Date value2) {
            addCriterion("startworktime between", value1, value2, "startworktime");
            return (Criteria) this;
        }

        public Criteria andStartworktimeNotBetween(Date value1, Date value2) {
            addCriterion("startworktime not between", value1, value2, "startworktime");
            return (Criteria) this;
        }

        public Criteria andEndworktimeIsNull() {
            addCriterion("endworktime is null");
            return (Criteria) this;
        }

        public Criteria andEndworktimeIsNotNull() {
            addCriterion("endworktime is not null");
            return (Criteria) this;
        }

        public Criteria andEndworktimeEqualTo(Date value) {
            addCriterion("endworktime =", value, "endworktime");
            return (Criteria) this;
        }

        public Criteria andEndworktimeNotEqualTo(Date value) {
            addCriterion("endworktime <>", value, "endworktime");
            return (Criteria) this;
        }

        public Criteria andEndworktimeGreaterThan(Date value) {
            addCriterion("endworktime >", value, "endworktime");
            return (Criteria) this;
        }

        public Criteria andEndworktimeGreaterThanOrEqualTo(Date value) {
            addCriterion("endworktime >=", value, "endworktime");
            return (Criteria) this;
        }

        public Criteria andEndworktimeLessThan(Date value) {
            addCriterion("endworktime <", value, "endworktime");
            return (Criteria) this;
        }

        public Criteria andEndworktimeLessThanOrEqualTo(Date value) {
            addCriterion("endworktime <=", value, "endworktime");
            return (Criteria) this;
        }

        public Criteria andEndworktimeIn(List<Date> values) {
            addCriterion("endworktime in", values, "endworktime");
            return (Criteria) this;
        }

        public Criteria andEndworktimeNotIn(List<Date> values) {
            addCriterion("endworktime not in", values, "endworktime");
            return (Criteria) this;
        }

        public Criteria andEndworktimeBetween(Date value1, Date value2) {
            addCriterion("endworktime between", value1, value2, "endworktime");
            return (Criteria) this;
        }

        public Criteria andEndworktimeNotBetween(Date value1, Date value2) {
            addCriterion("endworktime not between", value1, value2, "endworktime");
            return (Criteria) this;
        }

        public Criteria andWorktypeIsNull() {
            addCriterion("worktype is null");
            return (Criteria) this;
        }

        public Criteria andWorktypeIsNotNull() {
            addCriterion("worktype is not null");
            return (Criteria) this;
        }

        public Criteria andWorktypeEqualTo(String value) {
            addCriterion("worktype =", value, "worktype");
            return (Criteria) this;
        }

        public Criteria andWorktypeNotEqualTo(String value) {
            addCriterion("worktype <>", value, "worktype");
            return (Criteria) this;
        }

        public Criteria andWorktypeGreaterThan(String value) {
            addCriterion("worktype >", value, "worktype");
            return (Criteria) this;
        }

        public Criteria andWorktypeGreaterThanOrEqualTo(String value) {
            addCriterion("worktype >=", value, "worktype");
            return (Criteria) this;
        }

        public Criteria andWorktypeLessThan(String value) {
            addCriterion("worktype <", value, "worktype");
            return (Criteria) this;
        }

        public Criteria andWorktypeLessThanOrEqualTo(String value) {
            addCriterion("worktype <=", value, "worktype");
            return (Criteria) this;
        }

        public Criteria andWorktypeLike(String value) {
            addCriterion("worktype like", value, "worktype");
            return (Criteria) this;
        }

        public Criteria andWorktypeNotLike(String value) {
            addCriterion("worktype not like", value, "worktype");
            return (Criteria) this;
        }

        public Criteria andWorktypeIn(List<String> values) {
            addCriterion("worktype in", values, "worktype");
            return (Criteria) this;
        }

        public Criteria andWorktypeNotIn(List<String> values) {
            addCriterion("worktype not in", values, "worktype");
            return (Criteria) this;
        }

        public Criteria andWorktypeBetween(String value1, String value2) {
            addCriterion("worktype between", value1, value2, "worktype");
            return (Criteria) this;
        }

        public Criteria andWorktypeNotBetween(String value1, String value2) {
            addCriterion("worktype not between", value1, value2, "worktype");
            return (Criteria) this;
        }

        public Criteria andWorknameIsNull() {
            addCriterion("workname is null");
            return (Criteria) this;
        }

        public Criteria andWorknameIsNotNull() {
            addCriterion("workname is not null");
            return (Criteria) this;
        }

        public Criteria andWorknameEqualTo(String value) {
            addCriterion("workname =", value, "workname");
            return (Criteria) this;
        }

        public Criteria andWorknameNotEqualTo(String value) {
            addCriterion("workname <>", value, "workname");
            return (Criteria) this;
        }

        public Criteria andWorknameGreaterThan(String value) {
            addCriterion("workname >", value, "workname");
            return (Criteria) this;
        }

        public Criteria andWorknameGreaterThanOrEqualTo(String value) {
            addCriterion("workname >=", value, "workname");
            return (Criteria) this;
        }

        public Criteria andWorknameLessThan(String value) {
            addCriterion("workname <", value, "workname");
            return (Criteria) this;
        }

        public Criteria andWorknameLessThanOrEqualTo(String value) {
            addCriterion("workname <=", value, "workname");
            return (Criteria) this;
        }

        public Criteria andWorknameLike(String value) {
            addCriterion("workname like", value, "workname");
            return (Criteria) this;
        }

        public Criteria andWorknameNotLike(String value) {
            addCriterion("workname not like", value, "workname");
            return (Criteria) this;
        }

        public Criteria andWorknameIn(List<String> values) {
            addCriterion("workname in", values, "workname");
            return (Criteria) this;
        }

        public Criteria andWorknameNotIn(List<String> values) {
            addCriterion("workname not in", values, "workname");
            return (Criteria) this;
        }

        public Criteria andWorknameBetween(String value1, String value2) {
            addCriterion("workname between", value1, value2, "workname");
            return (Criteria) this;
        }

        public Criteria andWorknameNotBetween(String value1, String value2) {
            addCriterion("workname not between", value1, value2, "workname");
            return (Criteria) this;
        }

        public Criteria andStartschooltimeIsNull() {
            addCriterion("startschooltime is null");
            return (Criteria) this;
        }

        public Criteria andStartschooltimeIsNotNull() {
            addCriterion("startschooltime is not null");
            return (Criteria) this;
        }

        public Criteria andStartschooltimeEqualTo(Date value) {
            addCriterion("startschooltime =", value, "startschooltime");
            return (Criteria) this;
        }

        public Criteria andStartschooltimeNotEqualTo(Date value) {
            addCriterion("startschooltime <>", value, "startschooltime");
            return (Criteria) this;
        }

        public Criteria andStartschooltimeGreaterThan(Date value) {
            addCriterion("startschooltime >", value, "startschooltime");
            return (Criteria) this;
        }

        public Criteria andStartschooltimeGreaterThanOrEqualTo(Date value) {
            addCriterion("startschooltime >=", value, "startschooltime");
            return (Criteria) this;
        }

        public Criteria andStartschooltimeLessThan(Date value) {
            addCriterion("startschooltime <", value, "startschooltime");
            return (Criteria) this;
        }

        public Criteria andStartschooltimeLessThanOrEqualTo(Date value) {
            addCriterion("startschooltime <=", value, "startschooltime");
            return (Criteria) this;
        }

        public Criteria andStartschooltimeIn(List<Date> values) {
            addCriterion("startschooltime in", values, "startschooltime");
            return (Criteria) this;
        }

        public Criteria andStartschooltimeNotIn(List<Date> values) {
            addCriterion("startschooltime not in", values, "startschooltime");
            return (Criteria) this;
        }

        public Criteria andStartschooltimeBetween(Date value1, Date value2) {
            addCriterion("startschooltime between", value1, value2, "startschooltime");
            return (Criteria) this;
        }

        public Criteria andStartschooltimeNotBetween(Date value1, Date value2) {
            addCriterion("startschooltime not between", value1, value2, "startschooltime");
            return (Criteria) this;
        }

        public Criteria andEndschooltimeIsNull() {
            addCriterion("endschooltime is null");
            return (Criteria) this;
        }

        public Criteria andEndschooltimeIsNotNull() {
            addCriterion("endschooltime is not null");
            return (Criteria) this;
        }

        public Criteria andEndschooltimeEqualTo(Date value) {
            addCriterion("endschooltime =", value, "endschooltime");
            return (Criteria) this;
        }

        public Criteria andEndschooltimeNotEqualTo(Date value) {
            addCriterion("endschooltime <>", value, "endschooltime");
            return (Criteria) this;
        }

        public Criteria andEndschooltimeGreaterThan(Date value) {
            addCriterion("endschooltime >", value, "endschooltime");
            return (Criteria) this;
        }

        public Criteria andEndschooltimeGreaterThanOrEqualTo(Date value) {
            addCriterion("endschooltime >=", value, "endschooltime");
            return (Criteria) this;
        }

        public Criteria andEndschooltimeLessThan(Date value) {
            addCriterion("endschooltime <", value, "endschooltime");
            return (Criteria) this;
        }

        public Criteria andEndschooltimeLessThanOrEqualTo(Date value) {
            addCriterion("endschooltime <=", value, "endschooltime");
            return (Criteria) this;
        }

        public Criteria andEndschooltimeIn(List<Date> values) {
            addCriterion("endschooltime in", values, "endschooltime");
            return (Criteria) this;
        }

        public Criteria andEndschooltimeNotIn(List<Date> values) {
            addCriterion("endschooltime not in", values, "endschooltime");
            return (Criteria) this;
        }

        public Criteria andEndschooltimeBetween(Date value1, Date value2) {
            addCriterion("endschooltime between", value1, value2, "endschooltime");
            return (Criteria) this;
        }

        public Criteria andEndschooltimeNotBetween(Date value1, Date value2) {
            addCriterion("endschooltime not between", value1, value2, "endschooltime");
            return (Criteria) this;
        }

        public Criteria andExperenceIsNull() {
            addCriterion("experence is null");
            return (Criteria) this;
        }

        public Criteria andExperenceIsNotNull() {
            addCriterion("experence is not null");
            return (Criteria) this;
        }

        public Criteria andExperenceEqualTo(String value) {
            addCriterion("experence =", value, "experence");
            return (Criteria) this;
        }

        public Criteria andExperenceNotEqualTo(String value) {
            addCriterion("experence <>", value, "experence");
            return (Criteria) this;
        }

        public Criteria andExperenceGreaterThan(String value) {
            addCriterion("experence >", value, "experence");
            return (Criteria) this;
        }

        public Criteria andExperenceGreaterThanOrEqualTo(String value) {
            addCriterion("experence >=", value, "experence");
            return (Criteria) this;
        }

        public Criteria andExperenceLessThan(String value) {
            addCriterion("experence <", value, "experence");
            return (Criteria) this;
        }

        public Criteria andExperenceLessThanOrEqualTo(String value) {
            addCriterion("experence <=", value, "experence");
            return (Criteria) this;
        }

        public Criteria andExperenceLike(String value) {
            addCriterion("experence like", value, "experence");
            return (Criteria) this;
        }

        public Criteria andExperenceNotLike(String value) {
            addCriterion("experence not like", value, "experence");
            return (Criteria) this;
        }

        public Criteria andExperenceIn(List<String> values) {
            addCriterion("experence in", values, "experence");
            return (Criteria) this;
        }

        public Criteria andExperenceNotIn(List<String> values) {
            addCriterion("experence not in", values, "experence");
            return (Criteria) this;
        }

        public Criteria andExperenceBetween(String value1, String value2) {
            addCriterion("experence between", value1, value2, "experence");
            return (Criteria) this;
        }

        public Criteria andExperenceNotBetween(String value1, String value2) {
            addCriterion("experence not between", value1, value2, "experence");
            return (Criteria) this;
        }

        public Criteria andEducationalIsNull() {
            addCriterion("educational is null");
            return (Criteria) this;
        }

        public Criteria andEducationalIsNotNull() {
            addCriterion("educational is not null");
            return (Criteria) this;
        }

        public Criteria andEducationalEqualTo(String value) {
            addCriterion("educational =", value, "educational");
            return (Criteria) this;
        }

        public Criteria andEducationalNotEqualTo(String value) {
            addCriterion("educational <>", value, "educational");
            return (Criteria) this;
        }

        public Criteria andEducationalGreaterThan(String value) {
            addCriterion("educational >", value, "educational");
            return (Criteria) this;
        }

        public Criteria andEducationalGreaterThanOrEqualTo(String value) {
            addCriterion("educational >=", value, "educational");
            return (Criteria) this;
        }

        public Criteria andEducationalLessThan(String value) {
            addCriterion("educational <", value, "educational");
            return (Criteria) this;
        }

        public Criteria andEducationalLessThanOrEqualTo(String value) {
            addCriterion("educational <=", value, "educational");
            return (Criteria) this;
        }

        public Criteria andEducationalLike(String value) {
            addCriterion("educational like", value, "educational");
            return (Criteria) this;
        }

        public Criteria andEducationalNotLike(String value) {
            addCriterion("educational not like", value, "educational");
            return (Criteria) this;
        }

        public Criteria andEducationalIn(List<String> values) {
            addCriterion("educational in", values, "educational");
            return (Criteria) this;
        }

        public Criteria andEducationalNotIn(List<String> values) {
            addCriterion("educational not in", values, "educational");
            return (Criteria) this;
        }

        public Criteria andEducationalBetween(String value1, String value2) {
            addCriterion("educational between", value1, value2, "educational");
            return (Criteria) this;
        }

        public Criteria andEducationalNotBetween(String value1, String value2) {
            addCriterion("educational not between", value1, value2, "educational");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}