package com.box.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class DbReplymessageExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public DbReplymessageExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andRidIsNull() {
            addCriterion("rid is null");
            return (Criteria) this;
        }

        public Criteria andRidIsNotNull() {
            addCriterion("rid is not null");
            return (Criteria) this;
        }

        public Criteria andRidEqualTo(Integer value) {
            addCriterion("rid =", value, "rid");
            return (Criteria) this;
        }

        public Criteria andRidNotEqualTo(Integer value) {
            addCriterion("rid <>", value, "rid");
            return (Criteria) this;
        }

        public Criteria andRidGreaterThan(Integer value) {
            addCriterion("rid >", value, "rid");
            return (Criteria) this;
        }

        public Criteria andRidGreaterThanOrEqualTo(Integer value) {
            addCriterion("rid >=", value, "rid");
            return (Criteria) this;
        }

        public Criteria andRidLessThan(Integer value) {
            addCriterion("rid <", value, "rid");
            return (Criteria) this;
        }

        public Criteria andRidLessThanOrEqualTo(Integer value) {
            addCriterion("rid <=", value, "rid");
            return (Criteria) this;
        }

        public Criteria andRidIn(List<Integer> values) {
            addCriterion("rid in", values, "rid");
            return (Criteria) this;
        }

        public Criteria andRidNotIn(List<Integer> values) {
            addCriterion("rid not in", values, "rid");
            return (Criteria) this;
        }

        public Criteria andRidBetween(Integer value1, Integer value2) {
            addCriterion("rid between", value1, value2, "rid");
            return (Criteria) this;
        }

        public Criteria andRidNotBetween(Integer value1, Integer value2) {
            addCriterion("rid not between", value1, value2, "rid");
            return (Criteria) this;
        }

        public Criteria andRcontentIsNull() {
            addCriterion("rcontent is null");
            return (Criteria) this;
        }

        public Criteria andRcontentIsNotNull() {
            addCriterion("rcontent is not null");
            return (Criteria) this;
        }

        public Criteria andRcontentEqualTo(String value) {
            addCriterion("rcontent =", value, "rcontent");
            return (Criteria) this;
        }

        public Criteria andRcontentNotEqualTo(String value) {
            addCriterion("rcontent <>", value, "rcontent");
            return (Criteria) this;
        }

        public Criteria andRcontentGreaterThan(String value) {
            addCriterion("rcontent >", value, "rcontent");
            return (Criteria) this;
        }

        public Criteria andRcontentGreaterThanOrEqualTo(String value) {
            addCriterion("rcontent >=", value, "rcontent");
            return (Criteria) this;
        }

        public Criteria andRcontentLessThan(String value) {
            addCriterion("rcontent <", value, "rcontent");
            return (Criteria) this;
        }

        public Criteria andRcontentLessThanOrEqualTo(String value) {
            addCriterion("rcontent <=", value, "rcontent");
            return (Criteria) this;
        }

        public Criteria andRcontentLike(String value) {
            addCriterion("rcontent like", value, "rcontent");
            return (Criteria) this;
        }

        public Criteria andRcontentNotLike(String value) {
            addCriterion("rcontent not like", value, "rcontent");
            return (Criteria) this;
        }

        public Criteria andRcontentIn(List<String> values) {
            addCriterion("rcontent in", values, "rcontent");
            return (Criteria) this;
        }

        public Criteria andRcontentNotIn(List<String> values) {
            addCriterion("rcontent not in", values, "rcontent");
            return (Criteria) this;
        }

        public Criteria andRcontentBetween(String value1, String value2) {
            addCriterion("rcontent between", value1, value2, "rcontent");
            return (Criteria) this;
        }

        public Criteria andRcontentNotBetween(String value1, String value2) {
            addCriterion("rcontent not between", value1, value2, "rcontent");
            return (Criteria) this;
        }

        public Criteria andRcreatetimeIsNull() {
            addCriterion("rcreateTime is null");
            return (Criteria) this;
        }

        public Criteria andRcreatetimeIsNotNull() {
            addCriterion("rcreateTime is not null");
            return (Criteria) this;
        }

        public Criteria andRcreatetimeEqualTo(Date value) {
            addCriterion("rcreateTime =", value, "rcreatetime");
            return (Criteria) this;
        }

        public Criteria andRcreatetimeNotEqualTo(Date value) {
            addCriterion("rcreateTime <>", value, "rcreatetime");
            return (Criteria) this;
        }

        public Criteria andRcreatetimeGreaterThan(Date value) {
            addCriterion("rcreateTime >", value, "rcreatetime");
            return (Criteria) this;
        }

        public Criteria andRcreatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("rcreateTime >=", value, "rcreatetime");
            return (Criteria) this;
        }

        public Criteria andRcreatetimeLessThan(Date value) {
            addCriterion("rcreateTime <", value, "rcreatetime");
            return (Criteria) this;
        }

        public Criteria andRcreatetimeLessThanOrEqualTo(Date value) {
            addCriterion("rcreateTime <=", value, "rcreatetime");
            return (Criteria) this;
        }

        public Criteria andRcreatetimeIn(List<Date> values) {
            addCriterion("rcreateTime in", values, "rcreatetime");
            return (Criteria) this;
        }

        public Criteria andRcreatetimeNotIn(List<Date> values) {
            addCriterion("rcreateTime not in", values, "rcreatetime");
            return (Criteria) this;
        }

        public Criteria andRcreatetimeBetween(Date value1, Date value2) {
            addCriterion("rcreateTime between", value1, value2, "rcreatetime");
            return (Criteria) this;
        }

        public Criteria andRcreatetimeNotBetween(Date value1, Date value2) {
            addCriterion("rcreateTime not between", value1, value2, "rcreatetime");
            return (Criteria) this;
        }

        public Criteria andLvidIsNull() {
            addCriterion("lvid is null");
            return (Criteria) this;
        }

        public Criteria andLvidIsNotNull() {
            addCriterion("lvid is not null");
            return (Criteria) this;
        }

        public Criteria andLvidEqualTo(Integer value) {
            addCriterion("lvid =", value, "lvid");
            return (Criteria) this;
        }

        public Criteria andLvidNotEqualTo(Integer value) {
            addCriterion("lvid <>", value, "lvid");
            return (Criteria) this;
        }

        public Criteria andLvidGreaterThan(Integer value) {
            addCriterion("lvid >", value, "lvid");
            return (Criteria) this;
        }

        public Criteria andLvidGreaterThanOrEqualTo(Integer value) {
            addCriterion("lvid >=", value, "lvid");
            return (Criteria) this;
        }

        public Criteria andLvidLessThan(Integer value) {
            addCriterion("lvid <", value, "lvid");
            return (Criteria) this;
        }

        public Criteria andLvidLessThanOrEqualTo(Integer value) {
            addCriterion("lvid <=", value, "lvid");
            return (Criteria) this;
        }

        public Criteria andLvidIn(List<Integer> values) {
            addCriterion("lvid in", values, "lvid");
            return (Criteria) this;
        }

        public Criteria andLvidNotIn(List<Integer> values) {
            addCriterion("lvid not in", values, "lvid");
            return (Criteria) this;
        }

        public Criteria andLvidBetween(Integer value1, Integer value2) {
            addCriterion("lvid between", value1, value2, "lvid");
            return (Criteria) this;
        }

        public Criteria andLvidNotBetween(Integer value1, Integer value2) {
            addCriterion("lvid not between", value1, value2, "lvid");
            return (Criteria) this;
        }

        public Criteria andUidIsNull() {
            addCriterion("uid is null");
            return (Criteria) this;
        }

        public Criteria andUidIsNotNull() {
            addCriterion("uid is not null");
            return (Criteria) this;
        }

        public Criteria andUidEqualTo(Integer value) {
            addCriterion("uid =", value, "uid");
            return (Criteria) this;
        }

        public Criteria andUidNotEqualTo(Integer value) {
            addCriterion("uid <>", value, "uid");
            return (Criteria) this;
        }

        public Criteria andUidGreaterThan(Integer value) {
            addCriterion("uid >", value, "uid");
            return (Criteria) this;
        }

        public Criteria andUidGreaterThanOrEqualTo(Integer value) {
            addCriterion("uid >=", value, "uid");
            return (Criteria) this;
        }

        public Criteria andUidLessThan(Integer value) {
            addCriterion("uid <", value, "uid");
            return (Criteria) this;
        }

        public Criteria andUidLessThanOrEqualTo(Integer value) {
            addCriterion("uid <=", value, "uid");
            return (Criteria) this;
        }

        public Criteria andUidIn(List<Integer> values) {
            addCriterion("uid in", values, "uid");
            return (Criteria) this;
        }

        public Criteria andUidNotIn(List<Integer> values) {
            addCriterion("uid not in", values, "uid");
            return (Criteria) this;
        }

        public Criteria andUidBetween(Integer value1, Integer value2) {
            addCriterion("uid between", value1, value2, "uid");
            return (Criteria) this;
        }

        public Criteria andUidNotBetween(Integer value1, Integer value2) {
            addCriterion("uid not between", value1, value2, "uid");
            return (Criteria) this;
        }

        public Criteria andStatusIsNull() {
            addCriterion("status is null");
            return (Criteria) this;
        }

        public Criteria andStatusIsNotNull() {
            addCriterion("status is not null");
            return (Criteria) this;
        }

        public Criteria andStatusEqualTo(Integer value) {
            addCriterion("status =", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotEqualTo(Integer value) {
            addCriterion("status <>", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThan(Integer value) {
            addCriterion("status >", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("status >=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThan(Integer value) {
            addCriterion("status <", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusLessThanOrEqualTo(Integer value) {
            addCriterion("status <=", value, "status");
            return (Criteria) this;
        }

        public Criteria andStatusIn(List<Integer> values) {
            addCriterion("status in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotIn(List<Integer> values) {
            addCriterion("status not in", values, "status");
            return (Criteria) this;
        }

        public Criteria andStatusBetween(Integer value1, Integer value2) {
            addCriterion("status between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andStatusNotBetween(Integer value1, Integer value2) {
            addCriterion("status not between", value1, value2, "status");
            return (Criteria) this;
        }

        public Criteria andIsviewIsNull() {
            addCriterion("isView is null");
            return (Criteria) this;
        }

        public Criteria andIsviewIsNotNull() {
            addCriterion("isView is not null");
            return (Criteria) this;
        }

        public Criteria andIsviewEqualTo(Boolean value) {
            addCriterion("isView =", value, "isview");
            return (Criteria) this;
        }

        public Criteria andIsviewNotEqualTo(Boolean value) {
            addCriterion("isView <>", value, "isview");
            return (Criteria) this;
        }

        public Criteria andIsviewGreaterThan(Boolean value) {
            addCriterion("isView >", value, "isview");
            return (Criteria) this;
        }

        public Criteria andIsviewGreaterThanOrEqualTo(Boolean value) {
            addCriterion("isView >=", value, "isview");
            return (Criteria) this;
        }

        public Criteria andIsviewLessThan(Boolean value) {
            addCriterion("isView <", value, "isview");
            return (Criteria) this;
        }

        public Criteria andIsviewLessThanOrEqualTo(Boolean value) {
            addCriterion("isView <=", value, "isview");
            return (Criteria) this;
        }

        public Criteria andIsviewIn(List<Boolean> values) {
            addCriterion("isView in", values, "isview");
            return (Criteria) this;
        }

        public Criteria andIsviewNotIn(List<Boolean> values) {
            addCriterion("isView not in", values, "isview");
            return (Criteria) this;
        }

        public Criteria andIsviewBetween(Boolean value1, Boolean value2) {
            addCriterion("isView between", value1, value2, "isview");
            return (Criteria) this;
        }

        public Criteria andIsviewNotBetween(Boolean value1, Boolean value2) {
            addCriterion("isView not between", value1, value2, "isview");
            return (Criteria) this;
        }

        public Criteria andResonIsNull() {
            addCriterion("reson is null");
            return (Criteria) this;
        }

        public Criteria andResonIsNotNull() {
            addCriterion("reson is not null");
            return (Criteria) this;
        }

        public Criteria andResonEqualTo(String value) {
            addCriterion("reson =", value, "reson");
            return (Criteria) this;
        }

        public Criteria andResonNotEqualTo(String value) {
            addCriterion("reson <>", value, "reson");
            return (Criteria) this;
        }

        public Criteria andResonGreaterThan(String value) {
            addCriterion("reson >", value, "reson");
            return (Criteria) this;
        }

        public Criteria andResonGreaterThanOrEqualTo(String value) {
            addCriterion("reson >=", value, "reson");
            return (Criteria) this;
        }

        public Criteria andResonLessThan(String value) {
            addCriterion("reson <", value, "reson");
            return (Criteria) this;
        }

        public Criteria andResonLessThanOrEqualTo(String value) {
            addCriterion("reson <=", value, "reson");
            return (Criteria) this;
        }

        public Criteria andResonLike(String value) {
            addCriterion("reson like", value, "reson");
            return (Criteria) this;
        }

        public Criteria andResonNotLike(String value) {
            addCriterion("reson not like", value, "reson");
            return (Criteria) this;
        }

        public Criteria andResonIn(List<String> values) {
            addCriterion("reson in", values, "reson");
            return (Criteria) this;
        }

        public Criteria andResonNotIn(List<String> values) {
            addCriterion("reson not in", values, "reson");
            return (Criteria) this;
        }

        public Criteria andResonBetween(String value1, String value2) {
            addCriterion("reson between", value1, value2, "reson");
            return (Criteria) this;
        }

        public Criteria andResonNotBetween(String value1, String value2) {
            addCriterion("reson not between", value1, value2, "reson");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}