package com.box.entity;

import java.util.Date;

public class DbArticle {
    private Integer arid;

    private String artitle;

    private String arcontent;

    private String simpledes;

    private Integer istop;

    private Integer uid;

    private Integer clicks;

    private Integer isview;

    private Integer upperid;

    private Integer artypeid;

    private String img;

    private Date arcreatetime;

    private Date updatetime;

    public Integer getArid() {
        return arid;
    }

    public void setArid(Integer arid) {
        this.arid = arid;
    }

    public String getArtitle() {
        return artitle;
    }

    public void setArtitle(String artitle) {
        this.artitle = artitle == null ? null : artitle.trim();
    }

    public String getArcontent() {
        return arcontent;
    }

    public void setArcontent(String arcontent) {
        this.arcontent = arcontent == null ? null : arcontent.trim();
    }

    public String getSimpledes() {
        return simpledes;
    }

    public void setSimpledes(String simpledes) {
        this.simpledes = simpledes == null ? null : simpledes.trim();
    }

    public Integer getIstop() {
        return istop;
    }

    public void setIstop(Integer istop) {
        this.istop = istop;
    }

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }

    public Integer getClicks() {
        return clicks;
    }

    public void setClicks(Integer clicks) {
        this.clicks = clicks;
    }

    public Integer getIsview() {
        return isview;
    }

    public void setIsview(Integer isview) {
        this.isview = isview;
    }

    public Integer getUpperid() {
        return upperid;
    }

    public void setUpperid(Integer upperid) {
        this.upperid = upperid;
    }

    public Integer getArtypeid() {
        return artypeid;
    }

    public void setArtypeid(Integer artypeid) {
        this.artypeid = artypeid;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img == null ? null : img.trim();
    }

    public Date getArcreatetime() {
        return arcreatetime;
    }

    public void setArcreatetime(Date arcreatetime) {
        this.arcreatetime = arcreatetime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}