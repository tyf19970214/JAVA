package com.box.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class DbEmailExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public DbEmailExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andEidIsNull() {
            addCriterion("eid is null");
            return (Criteria) this;
        }

        public Criteria andEidIsNotNull() {
            addCriterion("eid is not null");
            return (Criteria) this;
        }

        public Criteria andEidEqualTo(String value) {
            addCriterion("eid =", value, "eid");
            return (Criteria) this;
        }

        public Criteria andEidNotEqualTo(String value) {
            addCriterion("eid <>", value, "eid");
            return (Criteria) this;
        }

        public Criteria andEidGreaterThan(String value) {
            addCriterion("eid >", value, "eid");
            return (Criteria) this;
        }

        public Criteria andEidGreaterThanOrEqualTo(String value) {
            addCriterion("eid >=", value, "eid");
            return (Criteria) this;
        }

        public Criteria andEidLessThan(String value) {
            addCriterion("eid <", value, "eid");
            return (Criteria) this;
        }

        public Criteria andEidLessThanOrEqualTo(String value) {
            addCriterion("eid <=", value, "eid");
            return (Criteria) this;
        }

        public Criteria andEidLike(String value) {
            addCriterion("eid like", value, "eid");
            return (Criteria) this;
        }

        public Criteria andEidNotLike(String value) {
            addCriterion("eid not like", value, "eid");
            return (Criteria) this;
        }

        public Criteria andEidIn(List<String> values) {
            addCriterion("eid in", values, "eid");
            return (Criteria) this;
        }

        public Criteria andEidNotIn(List<String> values) {
            addCriterion("eid not in", values, "eid");
            return (Criteria) this;
        }

        public Criteria andEidBetween(String value1, String value2) {
            addCriterion("eid between", value1, value2, "eid");
            return (Criteria) this;
        }

        public Criteria andEidNotBetween(String value1, String value2) {
            addCriterion("eid not between", value1, value2, "eid");
            return (Criteria) this;
        }

        public Criteria andEsenderIsNull() {
            addCriterion("esender is null");
            return (Criteria) this;
        }

        public Criteria andEsenderIsNotNull() {
            addCriterion("esender is not null");
            return (Criteria) this;
        }

        public Criteria andEsenderEqualTo(String value) {
            addCriterion("esender =", value, "esender");
            return (Criteria) this;
        }

        public Criteria andEsenderNotEqualTo(String value) {
            addCriterion("esender <>", value, "esender");
            return (Criteria) this;
        }

        public Criteria andEsenderGreaterThan(String value) {
            addCriterion("esender >", value, "esender");
            return (Criteria) this;
        }

        public Criteria andEsenderGreaterThanOrEqualTo(String value) {
            addCriterion("esender >=", value, "esender");
            return (Criteria) this;
        }

        public Criteria andEsenderLessThan(String value) {
            addCriterion("esender <", value, "esender");
            return (Criteria) this;
        }

        public Criteria andEsenderLessThanOrEqualTo(String value) {
            addCriterion("esender <=", value, "esender");
            return (Criteria) this;
        }

        public Criteria andEsenderLike(String value) {
            addCriterion("esender like", value, "esender");
            return (Criteria) this;
        }

        public Criteria andEsenderNotLike(String value) {
            addCriterion("esender not like", value, "esender");
            return (Criteria) this;
        }

        public Criteria andEsenderIn(List<String> values) {
            addCriterion("esender in", values, "esender");
            return (Criteria) this;
        }

        public Criteria andEsenderNotIn(List<String> values) {
            addCriterion("esender not in", values, "esender");
            return (Criteria) this;
        }

        public Criteria andEsenderBetween(String value1, String value2) {
            addCriterion("esender between", value1, value2, "esender");
            return (Criteria) this;
        }

        public Criteria andEsenderNotBetween(String value1, String value2) {
            addCriterion("esender not between", value1, value2, "esender");
            return (Criteria) this;
        }

        public Criteria andEtitleIsNull() {
            addCriterion("etitle is null");
            return (Criteria) this;
        }

        public Criteria andEtitleIsNotNull() {
            addCriterion("etitle is not null");
            return (Criteria) this;
        }

        public Criteria andEtitleEqualTo(String value) {
            addCriterion("etitle =", value, "etitle");
            return (Criteria) this;
        }

        public Criteria andEtitleNotEqualTo(String value) {
            addCriterion("etitle <>", value, "etitle");
            return (Criteria) this;
        }

        public Criteria andEtitleGreaterThan(String value) {
            addCriterion("etitle >", value, "etitle");
            return (Criteria) this;
        }

        public Criteria andEtitleGreaterThanOrEqualTo(String value) {
            addCriterion("etitle >=", value, "etitle");
            return (Criteria) this;
        }

        public Criteria andEtitleLessThan(String value) {
            addCriterion("etitle <", value, "etitle");
            return (Criteria) this;
        }

        public Criteria andEtitleLessThanOrEqualTo(String value) {
            addCriterion("etitle <=", value, "etitle");
            return (Criteria) this;
        }

        public Criteria andEtitleLike(String value) {
            addCriterion("etitle like", value, "etitle");
            return (Criteria) this;
        }

        public Criteria andEtitleNotLike(String value) {
            addCriterion("etitle not like", value, "etitle");
            return (Criteria) this;
        }

        public Criteria andEtitleIn(List<String> values) {
            addCriterion("etitle in", values, "etitle");
            return (Criteria) this;
        }

        public Criteria andEtitleNotIn(List<String> values) {
            addCriterion("etitle not in", values, "etitle");
            return (Criteria) this;
        }

        public Criteria andEtitleBetween(String value1, String value2) {
            addCriterion("etitle between", value1, value2, "etitle");
            return (Criteria) this;
        }

        public Criteria andEtitleNotBetween(String value1, String value2) {
            addCriterion("etitle not between", value1, value2, "etitle");
            return (Criteria) this;
        }

        public Criteria andEreceiverIsNull() {
            addCriterion("ereceiver is null");
            return (Criteria) this;
        }

        public Criteria andEreceiverIsNotNull() {
            addCriterion("ereceiver is not null");
            return (Criteria) this;
        }

        public Criteria andEreceiverEqualTo(String value) {
            addCriterion("ereceiver =", value, "ereceiver");
            return (Criteria) this;
        }

        public Criteria andEreceiverNotEqualTo(String value) {
            addCriterion("ereceiver <>", value, "ereceiver");
            return (Criteria) this;
        }

        public Criteria andEreceiverGreaterThan(String value) {
            addCriterion("ereceiver >", value, "ereceiver");
            return (Criteria) this;
        }

        public Criteria andEreceiverGreaterThanOrEqualTo(String value) {
            addCriterion("ereceiver >=", value, "ereceiver");
            return (Criteria) this;
        }

        public Criteria andEreceiverLessThan(String value) {
            addCriterion("ereceiver <", value, "ereceiver");
            return (Criteria) this;
        }

        public Criteria andEreceiverLessThanOrEqualTo(String value) {
            addCriterion("ereceiver <=", value, "ereceiver");
            return (Criteria) this;
        }

        public Criteria andEreceiverLike(String value) {
            addCriterion("ereceiver like", value, "ereceiver");
            return (Criteria) this;
        }

        public Criteria andEreceiverNotLike(String value) {
            addCriterion("ereceiver not like", value, "ereceiver");
            return (Criteria) this;
        }

        public Criteria andEreceiverIn(List<String> values) {
            addCriterion("ereceiver in", values, "ereceiver");
            return (Criteria) this;
        }

        public Criteria andEreceiverNotIn(List<String> values) {
            addCriterion("ereceiver not in", values, "ereceiver");
            return (Criteria) this;
        }

        public Criteria andEreceiverBetween(String value1, String value2) {
            addCriterion("ereceiver between", value1, value2, "ereceiver");
            return (Criteria) this;
        }

        public Criteria andEreceiverNotBetween(String value1, String value2) {
            addCriterion("ereceiver not between", value1, value2, "ereceiver");
            return (Criteria) this;
        }

        public Criteria andAccepttimeIsNull() {
            addCriterion("accepttime is null");
            return (Criteria) this;
        }

        public Criteria andAccepttimeIsNotNull() {
            addCriterion("accepttime is not null");
            return (Criteria) this;
        }

        public Criteria andAccepttimeEqualTo(Date value) {
            addCriterion("accepttime =", value, "accepttime");
            return (Criteria) this;
        }

        public Criteria andAccepttimeNotEqualTo(Date value) {
            addCriterion("accepttime <>", value, "accepttime");
            return (Criteria) this;
        }

        public Criteria andAccepttimeGreaterThan(Date value) {
            addCriterion("accepttime >", value, "accepttime");
            return (Criteria) this;
        }

        public Criteria andAccepttimeGreaterThanOrEqualTo(Date value) {
            addCriterion("accepttime >=", value, "accepttime");
            return (Criteria) this;
        }

        public Criteria andAccepttimeLessThan(Date value) {
            addCriterion("accepttime <", value, "accepttime");
            return (Criteria) this;
        }

        public Criteria andAccepttimeLessThanOrEqualTo(Date value) {
            addCriterion("accepttime <=", value, "accepttime");
            return (Criteria) this;
        }

        public Criteria andAccepttimeIn(List<Date> values) {
            addCriterion("accepttime in", values, "accepttime");
            return (Criteria) this;
        }

        public Criteria andAccepttimeNotIn(List<Date> values) {
            addCriterion("accepttime not in", values, "accepttime");
            return (Criteria) this;
        }

        public Criteria andAccepttimeBetween(Date value1, Date value2) {
            addCriterion("accepttime between", value1, value2, "accepttime");
            return (Criteria) this;
        }

        public Criteria andAccepttimeNotBetween(Date value1, Date value2) {
            addCriterion("accepttime not between", value1, value2, "accepttime");
            return (Criteria) this;
        }

        public Criteria andMsgbodyIsNull() {
            addCriterion("msgBody is null");
            return (Criteria) this;
        }

        public Criteria andMsgbodyIsNotNull() {
            addCriterion("msgBody is not null");
            return (Criteria) this;
        }

        public Criteria andMsgbodyEqualTo(String value) {
            addCriterion("msgBody =", value, "msgbody");
            return (Criteria) this;
        }

        public Criteria andMsgbodyNotEqualTo(String value) {
            addCriterion("msgBody <>", value, "msgbody");
            return (Criteria) this;
        }

        public Criteria andMsgbodyGreaterThan(String value) {
            addCriterion("msgBody >", value, "msgbody");
            return (Criteria) this;
        }

        public Criteria andMsgbodyGreaterThanOrEqualTo(String value) {
            addCriterion("msgBody >=", value, "msgbody");
            return (Criteria) this;
        }

        public Criteria andMsgbodyLessThan(String value) {
            addCriterion("msgBody <", value, "msgbody");
            return (Criteria) this;
        }

        public Criteria andMsgbodyLessThanOrEqualTo(String value) {
            addCriterion("msgBody <=", value, "msgbody");
            return (Criteria) this;
        }

        public Criteria andMsgbodyLike(String value) {
            addCriterion("msgBody like", value, "msgbody");
            return (Criteria) this;
        }

        public Criteria andMsgbodyNotLike(String value) {
            addCriterion("msgBody not like", value, "msgbody");
            return (Criteria) this;
        }

        public Criteria andMsgbodyIn(List<String> values) {
            addCriterion("msgBody in", values, "msgbody");
            return (Criteria) this;
        }

        public Criteria andMsgbodyNotIn(List<String> values) {
            addCriterion("msgBody not in", values, "msgbody");
            return (Criteria) this;
        }

        public Criteria andMsgbodyBetween(String value1, String value2) {
            addCriterion("msgBody between", value1, value2, "msgbody");
            return (Criteria) this;
        }

        public Criteria andMsgbodyNotBetween(String value1, String value2) {
            addCriterion("msgBody not between", value1, value2, "msgbody");
            return (Criteria) this;
        }

        public Criteria andCheckstatusIsNull() {
            addCriterion("checkstatus is null");
            return (Criteria) this;
        }

        public Criteria andCheckstatusIsNotNull() {
            addCriterion("checkstatus is not null");
            return (Criteria) this;
        }

        public Criteria andCheckstatusEqualTo(Integer value) {
            addCriterion("checkstatus =", value, "checkstatus");
            return (Criteria) this;
        }

        public Criteria andCheckstatusNotEqualTo(Integer value) {
            addCriterion("checkstatus <>", value, "checkstatus");
            return (Criteria) this;
        }

        public Criteria andCheckstatusGreaterThan(Integer value) {
            addCriterion("checkstatus >", value, "checkstatus");
            return (Criteria) this;
        }

        public Criteria andCheckstatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("checkstatus >=", value, "checkstatus");
            return (Criteria) this;
        }

        public Criteria andCheckstatusLessThan(Integer value) {
            addCriterion("checkstatus <", value, "checkstatus");
            return (Criteria) this;
        }

        public Criteria andCheckstatusLessThanOrEqualTo(Integer value) {
            addCriterion("checkstatus <=", value, "checkstatus");
            return (Criteria) this;
        }

        public Criteria andCheckstatusIn(List<Integer> values) {
            addCriterion("checkstatus in", values, "checkstatus");
            return (Criteria) this;
        }

        public Criteria andCheckstatusNotIn(List<Integer> values) {
            addCriterion("checkstatus not in", values, "checkstatus");
            return (Criteria) this;
        }

        public Criteria andCheckstatusBetween(Integer value1, Integer value2) {
            addCriterion("checkstatus between", value1, value2, "checkstatus");
            return (Criteria) this;
        }

        public Criteria andCheckstatusNotBetween(Integer value1, Integer value2) {
            addCriterion("checkstatus not between", value1, value2, "checkstatus");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}