package com.box.entity;

import java.util.Date;

public class DbFiles {
    private Long id;

    private String fname;

    private String fpath;

    private Integer fid;

    private Integer uid;

    private Integer aid;

    private String fdescription;

    private Date fuploadtime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname == null ? null : fname.trim();
    }

    public String getFpath() {
        return fpath;
    }

    public void setFpath(String fpath) {
        this.fpath = fpath == null ? null : fpath.trim();
    }

    public Integer getFid() {
        return fid;
    }

    public void setFid(Integer fid) {
        this.fid = fid;
    }

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }

    public Integer getAid() {
        return aid;
    }

    public void setAid(Integer aid) {
        this.aid = aid;
    }

    public String getFdescription() {
        return fdescription;
    }

    public void setFdescription(String fdescription) {
        this.fdescription = fdescription == null ? null : fdescription.trim();
    }

    public Date getFuploadtime() {
        return fuploadtime;
    }

    public void setFuploadtime(Date fuploadtime) {
        this.fuploadtime = fuploadtime;
    }
}