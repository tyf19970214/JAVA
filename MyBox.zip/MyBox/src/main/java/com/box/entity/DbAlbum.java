package com.box.entity;

import java.util.Date;

public class DbAlbum {
    private Integer alid;

    private Integer uid;

    private String altitle;

    private String alt;

    private String src;

    private String message;

    private Long upperid;

    private Date creatime;

    public Integer getAlid() {
        return alid;
    }

    public void setAlid(Integer alid) {
        this.alid = alid;
    }

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }

    public String getAltitle() {
        return altitle;
    }

    public void setAltitle(String altitle) {
        this.altitle = altitle == null ? null : altitle.trim();
    }

    public String getAlt() {
        return alt;
    }

    public void setAlt(String alt) {
        this.alt = alt == null ? null : alt.trim();
    }

    public String getSrc() {
        return src;
    }

    public void setSrc(String src) {
        this.src = src == null ? null : src.trim();
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message == null ? null : message.trim();
    }

    public Long getUpperid() {
        return upperid;
    }

    public void setUpperid(Long upperid) {
        this.upperid = upperid;
    }

    public Date getCreatime() {
        return creatime;
    }

    public void setCreatime(Date creatime) {
        this.creatime = creatime;
    }
}