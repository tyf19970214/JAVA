package com.box.entity;

import java.util.Date;

public class DbEmail {
    private String eid;

    private String esender;

    private String etitle;

    private String ereceiver;

    private Date accepttime;

    private String msgbody;

    private Integer checkstatus;

    public String getEid() {
        return eid;
    }

    public void setEid(String eid) {
        this.eid = eid == null ? null : eid.trim();
    }

    public String getEsender() {
        return esender;
    }

    public void setEsender(String esender) {
        this.esender = esender == null ? null : esender.trim();
    }

    public String getEtitle() {
        return etitle;
    }

    public void setEtitle(String etitle) {
        this.etitle = etitle == null ? null : etitle.trim();
    }

    public String getEreceiver() {
        return ereceiver;
    }

    public void setEreceiver(String ereceiver) {
        this.ereceiver = ereceiver == null ? null : ereceiver.trim();
    }

    public Date getAccepttime() {
        return accepttime;
    }

    public void setAccepttime(Date accepttime) {
        this.accepttime = accepttime;
    }

    public String getMsgbody() {
        return msgbody;
    }

    public void setMsgbody(String msgbody) {
        this.msgbody = msgbody == null ? null : msgbody.trim();
    }

    public Integer getCheckstatus() {
        return checkstatus;
    }

    public void setCheckstatus(Integer checkstatus) {
        this.checkstatus = checkstatus;
    }
}