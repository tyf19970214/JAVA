package com.box.entity;

import java.util.Date;

public class DbTheme {
    private Integer id;

    private String themeTitle;

    private String themeImg;

    private Date createtime;

    private Date updatetime;

    private String themeContext;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getThemeTitle() {
        return themeTitle;
    }

    public void setThemeTitle(String themeTitle) {
        this.themeTitle = themeTitle == null ? null : themeTitle.trim();
    }

    public String getThemeImg() {
        return themeImg;
    }

    public void setThemeImg(String themeImg) {
        this.themeImg = themeImg == null ? null : themeImg.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }

    public String getThemeContext() {
        return themeContext;
    }

    public void setThemeContext(String themeContext) {
        this.themeContext = themeContext == null ? null : themeContext.trim();
    }
}