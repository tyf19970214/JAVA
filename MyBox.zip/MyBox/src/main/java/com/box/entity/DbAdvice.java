package com.box.entity;

import java.util.Date;

public class DbAdvice {
    private Integer advid;

    private String advtitle;

    private String advcontent;

    private Integer aid;

    private String advimg;

    private String advdescribe;

    private Date updatetime;

    public Integer getAdvid() {
        return advid;
    }

    public void setAdvid(Integer advid) {
        this.advid = advid;
    }

    public String getAdvtitle() {
        return advtitle;
    }

    public void setAdvtitle(String advtitle) {
        this.advtitle = advtitle == null ? null : advtitle.trim();
    }

    public String getAdvcontent() {
        return advcontent;
    }

    public void setAdvcontent(String advcontent) {
        this.advcontent = advcontent == null ? null : advcontent.trim();
    }

    public Integer getAid() {
        return aid;
    }

    public void setAid(Integer aid) {
        this.aid = aid;
    }

    public String getAdvimg() {
        return advimg;
    }

    public void setAdvimg(String advimg) {
        this.advimg = advimg == null ? null : advimg.trim();
    }

    public String getAdvdescribe() {
        return advdescribe;
    }

    public void setAdvdescribe(String advdescribe) {
        this.advdescribe = advdescribe == null ? null : advdescribe.trim();
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }
}