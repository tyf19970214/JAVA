package com.box.entity;

import java.util.ArrayList;
import java.util.List;

public class DbWebExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public DbWebExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andWidIsNull() {
            addCriterion("wid is null");
            return (Criteria) this;
        }

        public Criteria andWidIsNotNull() {
            addCriterion("wid is not null");
            return (Criteria) this;
        }

        public Criteria andWidEqualTo(Integer value) {
            addCriterion("wid =", value, "wid");
            return (Criteria) this;
        }

        public Criteria andWidNotEqualTo(Integer value) {
            addCriterion("wid <>", value, "wid");
            return (Criteria) this;
        }

        public Criteria andWidGreaterThan(Integer value) {
            addCriterion("wid >", value, "wid");
            return (Criteria) this;
        }

        public Criteria andWidGreaterThanOrEqualTo(Integer value) {
            addCriterion("wid >=", value, "wid");
            return (Criteria) this;
        }

        public Criteria andWidLessThan(Integer value) {
            addCriterion("wid <", value, "wid");
            return (Criteria) this;
        }

        public Criteria andWidLessThanOrEqualTo(Integer value) {
            addCriterion("wid <=", value, "wid");
            return (Criteria) this;
        }

        public Criteria andWidIn(List<Integer> values) {
            addCriterion("wid in", values, "wid");
            return (Criteria) this;
        }

        public Criteria andWidNotIn(List<Integer> values) {
            addCriterion("wid not in", values, "wid");
            return (Criteria) this;
        }

        public Criteria andWidBetween(Integer value1, Integer value2) {
            addCriterion("wid between", value1, value2, "wid");
            return (Criteria) this;
        }

        public Criteria andWidNotBetween(Integer value1, Integer value2) {
            addCriterion("wid not between", value1, value2, "wid");
            return (Criteria) this;
        }

        public Criteria andWtitleIsNull() {
            addCriterion("wtitle is null");
            return (Criteria) this;
        }

        public Criteria andWtitleIsNotNull() {
            addCriterion("wtitle is not null");
            return (Criteria) this;
        }

        public Criteria andWtitleEqualTo(String value) {
            addCriterion("wtitle =", value, "wtitle");
            return (Criteria) this;
        }

        public Criteria andWtitleNotEqualTo(String value) {
            addCriterion("wtitle <>", value, "wtitle");
            return (Criteria) this;
        }

        public Criteria andWtitleGreaterThan(String value) {
            addCriterion("wtitle >", value, "wtitle");
            return (Criteria) this;
        }

        public Criteria andWtitleGreaterThanOrEqualTo(String value) {
            addCriterion("wtitle >=", value, "wtitle");
            return (Criteria) this;
        }

        public Criteria andWtitleLessThan(String value) {
            addCriterion("wtitle <", value, "wtitle");
            return (Criteria) this;
        }

        public Criteria andWtitleLessThanOrEqualTo(String value) {
            addCriterion("wtitle <=", value, "wtitle");
            return (Criteria) this;
        }

        public Criteria andWtitleLike(String value) {
            addCriterion("wtitle like", value, "wtitle");
            return (Criteria) this;
        }

        public Criteria andWtitleNotLike(String value) {
            addCriterion("wtitle not like", value, "wtitle");
            return (Criteria) this;
        }

        public Criteria andWtitleIn(List<String> values) {
            addCriterion("wtitle in", values, "wtitle");
            return (Criteria) this;
        }

        public Criteria andWtitleNotIn(List<String> values) {
            addCriterion("wtitle not in", values, "wtitle");
            return (Criteria) this;
        }

        public Criteria andWtitleBetween(String value1, String value2) {
            addCriterion("wtitle between", value1, value2, "wtitle");
            return (Criteria) this;
        }

        public Criteria andWtitleNotBetween(String value1, String value2) {
            addCriterion("wtitle not between", value1, value2, "wtitle");
            return (Criteria) this;
        }

        public Criteria andWdesIsNull() {
            addCriterion("wdes is null");
            return (Criteria) this;
        }

        public Criteria andWdesIsNotNull() {
            addCriterion("wdes is not null");
            return (Criteria) this;
        }

        public Criteria andWdesEqualTo(String value) {
            addCriterion("wdes =", value, "wdes");
            return (Criteria) this;
        }

        public Criteria andWdesNotEqualTo(String value) {
            addCriterion("wdes <>", value, "wdes");
            return (Criteria) this;
        }

        public Criteria andWdesGreaterThan(String value) {
            addCriterion("wdes >", value, "wdes");
            return (Criteria) this;
        }

        public Criteria andWdesGreaterThanOrEqualTo(String value) {
            addCriterion("wdes >=", value, "wdes");
            return (Criteria) this;
        }

        public Criteria andWdesLessThan(String value) {
            addCriterion("wdes <", value, "wdes");
            return (Criteria) this;
        }

        public Criteria andWdesLessThanOrEqualTo(String value) {
            addCriterion("wdes <=", value, "wdes");
            return (Criteria) this;
        }

        public Criteria andWdesLike(String value) {
            addCriterion("wdes like", value, "wdes");
            return (Criteria) this;
        }

        public Criteria andWdesNotLike(String value) {
            addCriterion("wdes not like", value, "wdes");
            return (Criteria) this;
        }

        public Criteria andWdesIn(List<String> values) {
            addCriterion("wdes in", values, "wdes");
            return (Criteria) this;
        }

        public Criteria andWdesNotIn(List<String> values) {
            addCriterion("wdes not in", values, "wdes");
            return (Criteria) this;
        }

        public Criteria andWdesBetween(String value1, String value2) {
            addCriterion("wdes between", value1, value2, "wdes");
            return (Criteria) this;
        }

        public Criteria andWdesNotBetween(String value1, String value2) {
            addCriterion("wdes not between", value1, value2, "wdes");
            return (Criteria) this;
        }

        public Criteria andWurlIsNull() {
            addCriterion("wurl is null");
            return (Criteria) this;
        }

        public Criteria andWurlIsNotNull() {
            addCriterion("wurl is not null");
            return (Criteria) this;
        }

        public Criteria andWurlEqualTo(String value) {
            addCriterion("wurl =", value, "wurl");
            return (Criteria) this;
        }

        public Criteria andWurlNotEqualTo(String value) {
            addCriterion("wurl <>", value, "wurl");
            return (Criteria) this;
        }

        public Criteria andWurlGreaterThan(String value) {
            addCriterion("wurl >", value, "wurl");
            return (Criteria) this;
        }

        public Criteria andWurlGreaterThanOrEqualTo(String value) {
            addCriterion("wurl >=", value, "wurl");
            return (Criteria) this;
        }

        public Criteria andWurlLessThan(String value) {
            addCriterion("wurl <", value, "wurl");
            return (Criteria) this;
        }

        public Criteria andWurlLessThanOrEqualTo(String value) {
            addCriterion("wurl <=", value, "wurl");
            return (Criteria) this;
        }

        public Criteria andWurlLike(String value) {
            addCriterion("wurl like", value, "wurl");
            return (Criteria) this;
        }

        public Criteria andWurlNotLike(String value) {
            addCriterion("wurl not like", value, "wurl");
            return (Criteria) this;
        }

        public Criteria andWurlIn(List<String> values) {
            addCriterion("wurl in", values, "wurl");
            return (Criteria) this;
        }

        public Criteria andWurlNotIn(List<String> values) {
            addCriterion("wurl not in", values, "wurl");
            return (Criteria) this;
        }

        public Criteria andWurlBetween(String value1, String value2) {
            addCriterion("wurl between", value1, value2, "wurl");
            return (Criteria) this;
        }

        public Criteria andWurlNotBetween(String value1, String value2) {
            addCriterion("wurl not between", value1, value2, "wurl");
            return (Criteria) this;
        }

        public Criteria andWdescriptionIsNull() {
            addCriterion("wdescription is null");
            return (Criteria) this;
        }

        public Criteria andWdescriptionIsNotNull() {
            addCriterion("wdescription is not null");
            return (Criteria) this;
        }

        public Criteria andWdescriptionEqualTo(String value) {
            addCriterion("wdescription =", value, "wdescription");
            return (Criteria) this;
        }

        public Criteria andWdescriptionNotEqualTo(String value) {
            addCriterion("wdescription <>", value, "wdescription");
            return (Criteria) this;
        }

        public Criteria andWdescriptionGreaterThan(String value) {
            addCriterion("wdescription >", value, "wdescription");
            return (Criteria) this;
        }

        public Criteria andWdescriptionGreaterThanOrEqualTo(String value) {
            addCriterion("wdescription >=", value, "wdescription");
            return (Criteria) this;
        }

        public Criteria andWdescriptionLessThan(String value) {
            addCriterion("wdescription <", value, "wdescription");
            return (Criteria) this;
        }

        public Criteria andWdescriptionLessThanOrEqualTo(String value) {
            addCriterion("wdescription <=", value, "wdescription");
            return (Criteria) this;
        }

        public Criteria andWdescriptionLike(String value) {
            addCriterion("wdescription like", value, "wdescription");
            return (Criteria) this;
        }

        public Criteria andWdescriptionNotLike(String value) {
            addCriterion("wdescription not like", value, "wdescription");
            return (Criteria) this;
        }

        public Criteria andWdescriptionIn(List<String> values) {
            addCriterion("wdescription in", values, "wdescription");
            return (Criteria) this;
        }

        public Criteria andWdescriptionNotIn(List<String> values) {
            addCriterion("wdescription not in", values, "wdescription");
            return (Criteria) this;
        }

        public Criteria andWdescriptionBetween(String value1, String value2) {
            addCriterion("wdescription between", value1, value2, "wdescription");
            return (Criteria) this;
        }

        public Criteria andWdescriptionNotBetween(String value1, String value2) {
            addCriterion("wdescription not between", value1, value2, "wdescription");
            return (Criteria) this;
        }

        public Criteria andWkeywordsIsNull() {
            addCriterion("wkeywords is null");
            return (Criteria) this;
        }

        public Criteria andWkeywordsIsNotNull() {
            addCriterion("wkeywords is not null");
            return (Criteria) this;
        }

        public Criteria andWkeywordsEqualTo(String value) {
            addCriterion("wkeywords =", value, "wkeywords");
            return (Criteria) this;
        }

        public Criteria andWkeywordsNotEqualTo(String value) {
            addCriterion("wkeywords <>", value, "wkeywords");
            return (Criteria) this;
        }

        public Criteria andWkeywordsGreaterThan(String value) {
            addCriterion("wkeywords >", value, "wkeywords");
            return (Criteria) this;
        }

        public Criteria andWkeywordsGreaterThanOrEqualTo(String value) {
            addCriterion("wkeywords >=", value, "wkeywords");
            return (Criteria) this;
        }

        public Criteria andWkeywordsLessThan(String value) {
            addCriterion("wkeywords <", value, "wkeywords");
            return (Criteria) this;
        }

        public Criteria andWkeywordsLessThanOrEqualTo(String value) {
            addCriterion("wkeywords <=", value, "wkeywords");
            return (Criteria) this;
        }

        public Criteria andWkeywordsLike(String value) {
            addCriterion("wkeywords like", value, "wkeywords");
            return (Criteria) this;
        }

        public Criteria andWkeywordsNotLike(String value) {
            addCriterion("wkeywords not like", value, "wkeywords");
            return (Criteria) this;
        }

        public Criteria andWkeywordsIn(List<String> values) {
            addCriterion("wkeywords in", values, "wkeywords");
            return (Criteria) this;
        }

        public Criteria andWkeywordsNotIn(List<String> values) {
            addCriterion("wkeywords not in", values, "wkeywords");
            return (Criteria) this;
        }

        public Criteria andWkeywordsBetween(String value1, String value2) {
            addCriterion("wkeywords between", value1, value2, "wkeywords");
            return (Criteria) this;
        }

        public Criteria andWkeywordsNotBetween(String value1, String value2) {
            addCriterion("wkeywords not between", value1, value2, "wkeywords");
            return (Criteria) this;
        }

        public Criteria andWcopyrightIsNull() {
            addCriterion("wcopyright is null");
            return (Criteria) this;
        }

        public Criteria andWcopyrightIsNotNull() {
            addCriterion("wcopyright is not null");
            return (Criteria) this;
        }

        public Criteria andWcopyrightEqualTo(String value) {
            addCriterion("wcopyright =", value, "wcopyright");
            return (Criteria) this;
        }

        public Criteria andWcopyrightNotEqualTo(String value) {
            addCriterion("wcopyright <>", value, "wcopyright");
            return (Criteria) this;
        }

        public Criteria andWcopyrightGreaterThan(String value) {
            addCriterion("wcopyright >", value, "wcopyright");
            return (Criteria) this;
        }

        public Criteria andWcopyrightGreaterThanOrEqualTo(String value) {
            addCriterion("wcopyright >=", value, "wcopyright");
            return (Criteria) this;
        }

        public Criteria andWcopyrightLessThan(String value) {
            addCriterion("wcopyright <", value, "wcopyright");
            return (Criteria) this;
        }

        public Criteria andWcopyrightLessThanOrEqualTo(String value) {
            addCriterion("wcopyright <=", value, "wcopyright");
            return (Criteria) this;
        }

        public Criteria andWcopyrightLike(String value) {
            addCriterion("wcopyright like", value, "wcopyright");
            return (Criteria) this;
        }

        public Criteria andWcopyrightNotLike(String value) {
            addCriterion("wcopyright not like", value, "wcopyright");
            return (Criteria) this;
        }

        public Criteria andWcopyrightIn(List<String> values) {
            addCriterion("wcopyright in", values, "wcopyright");
            return (Criteria) this;
        }

        public Criteria andWcopyrightNotIn(List<String> values) {
            addCriterion("wcopyright not in", values, "wcopyright");
            return (Criteria) this;
        }

        public Criteria andWcopyrightBetween(String value1, String value2) {
            addCriterion("wcopyright between", value1, value2, "wcopyright");
            return (Criteria) this;
        }

        public Criteria andWcopyrightNotBetween(String value1, String value2) {
            addCriterion("wcopyright not between", value1, value2, "wcopyright");
            return (Criteria) this;
        }

        public Criteria andWrecordIsNull() {
            addCriterion("wrecord is null");
            return (Criteria) this;
        }

        public Criteria andWrecordIsNotNull() {
            addCriterion("wrecord is not null");
            return (Criteria) this;
        }

        public Criteria andWrecordEqualTo(String value) {
            addCriterion("wrecord =", value, "wrecord");
            return (Criteria) this;
        }

        public Criteria andWrecordNotEqualTo(String value) {
            addCriterion("wrecord <>", value, "wrecord");
            return (Criteria) this;
        }

        public Criteria andWrecordGreaterThan(String value) {
            addCriterion("wrecord >", value, "wrecord");
            return (Criteria) this;
        }

        public Criteria andWrecordGreaterThanOrEqualTo(String value) {
            addCriterion("wrecord >=", value, "wrecord");
            return (Criteria) this;
        }

        public Criteria andWrecordLessThan(String value) {
            addCriterion("wrecord <", value, "wrecord");
            return (Criteria) this;
        }

        public Criteria andWrecordLessThanOrEqualTo(String value) {
            addCriterion("wrecord <=", value, "wrecord");
            return (Criteria) this;
        }

        public Criteria andWrecordLike(String value) {
            addCriterion("wrecord like", value, "wrecord");
            return (Criteria) this;
        }

        public Criteria andWrecordNotLike(String value) {
            addCriterion("wrecord not like", value, "wrecord");
            return (Criteria) this;
        }

        public Criteria andWrecordIn(List<String> values) {
            addCriterion("wrecord in", values, "wrecord");
            return (Criteria) this;
        }

        public Criteria andWrecordNotIn(List<String> values) {
            addCriterion("wrecord not in", values, "wrecord");
            return (Criteria) this;
        }

        public Criteria andWrecordBetween(String value1, String value2) {
            addCriterion("wrecord between", value1, value2, "wrecord");
            return (Criteria) this;
        }

        public Criteria andWrecordNotBetween(String value1, String value2) {
            addCriterion("wrecord not between", value1, value2, "wrecord");
            return (Criteria) this;
        }

        public Criteria andWiconIsNull() {
            addCriterion("wicon is null");
            return (Criteria) this;
        }

        public Criteria andWiconIsNotNull() {
            addCriterion("wicon is not null");
            return (Criteria) this;
        }

        public Criteria andWiconEqualTo(String value) {
            addCriterion("wicon =", value, "wicon");
            return (Criteria) this;
        }

        public Criteria andWiconNotEqualTo(String value) {
            addCriterion("wicon <>", value, "wicon");
            return (Criteria) this;
        }

        public Criteria andWiconGreaterThan(String value) {
            addCriterion("wicon >", value, "wicon");
            return (Criteria) this;
        }

        public Criteria andWiconGreaterThanOrEqualTo(String value) {
            addCriterion("wicon >=", value, "wicon");
            return (Criteria) this;
        }

        public Criteria andWiconLessThan(String value) {
            addCriterion("wicon <", value, "wicon");
            return (Criteria) this;
        }

        public Criteria andWiconLessThanOrEqualTo(String value) {
            addCriterion("wicon <=", value, "wicon");
            return (Criteria) this;
        }

        public Criteria andWiconLike(String value) {
            addCriterion("wicon like", value, "wicon");
            return (Criteria) this;
        }

        public Criteria andWiconNotLike(String value) {
            addCriterion("wicon not like", value, "wicon");
            return (Criteria) this;
        }

        public Criteria andWiconIn(List<String> values) {
            addCriterion("wicon in", values, "wicon");
            return (Criteria) this;
        }

        public Criteria andWiconNotIn(List<String> values) {
            addCriterion("wicon not in", values, "wicon");
            return (Criteria) this;
        }

        public Criteria andWiconBetween(String value1, String value2) {
            addCriterion("wicon between", value1, value2, "wicon");
            return (Criteria) this;
        }

        public Criteria andWiconNotBetween(String value1, String value2) {
            addCriterion("wicon not between", value1, value2, "wicon");
            return (Criteria) this;
        }

        public Criteria andWleftinfoIsNull() {
            addCriterion("wleftinfo is null");
            return (Criteria) this;
        }

        public Criteria andWleftinfoIsNotNull() {
            addCriterion("wleftinfo is not null");
            return (Criteria) this;
        }

        public Criteria andWleftinfoEqualTo(String value) {
            addCriterion("wleftinfo =", value, "wleftinfo");
            return (Criteria) this;
        }

        public Criteria andWleftinfoNotEqualTo(String value) {
            addCriterion("wleftinfo <>", value, "wleftinfo");
            return (Criteria) this;
        }

        public Criteria andWleftinfoGreaterThan(String value) {
            addCriterion("wleftinfo >", value, "wleftinfo");
            return (Criteria) this;
        }

        public Criteria andWleftinfoGreaterThanOrEqualTo(String value) {
            addCriterion("wleftinfo >=", value, "wleftinfo");
            return (Criteria) this;
        }

        public Criteria andWleftinfoLessThan(String value) {
            addCriterion("wleftinfo <", value, "wleftinfo");
            return (Criteria) this;
        }

        public Criteria andWleftinfoLessThanOrEqualTo(String value) {
            addCriterion("wleftinfo <=", value, "wleftinfo");
            return (Criteria) this;
        }

        public Criteria andWleftinfoLike(String value) {
            addCriterion("wleftinfo like", value, "wleftinfo");
            return (Criteria) this;
        }

        public Criteria andWleftinfoNotLike(String value) {
            addCriterion("wleftinfo not like", value, "wleftinfo");
            return (Criteria) this;
        }

        public Criteria andWleftinfoIn(List<String> values) {
            addCriterion("wleftinfo in", values, "wleftinfo");
            return (Criteria) this;
        }

        public Criteria andWleftinfoNotIn(List<String> values) {
            addCriterion("wleftinfo not in", values, "wleftinfo");
            return (Criteria) this;
        }

        public Criteria andWleftinfoBetween(String value1, String value2) {
            addCriterion("wleftinfo between", value1, value2, "wleftinfo");
            return (Criteria) this;
        }

        public Criteria andWleftinfoNotBetween(String value1, String value2) {
            addCriterion("wleftinfo not between", value1, value2, "wleftinfo");
            return (Criteria) this;
        }

        public Criteria andWrightIsNull() {
            addCriterion("wright is null");
            return (Criteria) this;
        }

        public Criteria andWrightIsNotNull() {
            addCriterion("wright is not null");
            return (Criteria) this;
        }

        public Criteria andWrightEqualTo(String value) {
            addCriterion("wright =", value, "wright");
            return (Criteria) this;
        }

        public Criteria andWrightNotEqualTo(String value) {
            addCriterion("wright <>", value, "wright");
            return (Criteria) this;
        }

        public Criteria andWrightGreaterThan(String value) {
            addCriterion("wright >", value, "wright");
            return (Criteria) this;
        }

        public Criteria andWrightGreaterThanOrEqualTo(String value) {
            addCriterion("wright >=", value, "wright");
            return (Criteria) this;
        }

        public Criteria andWrightLessThan(String value) {
            addCriterion("wright <", value, "wright");
            return (Criteria) this;
        }

        public Criteria andWrightLessThanOrEqualTo(String value) {
            addCriterion("wright <=", value, "wright");
            return (Criteria) this;
        }

        public Criteria andWrightLike(String value) {
            addCriterion("wright like", value, "wright");
            return (Criteria) this;
        }

        public Criteria andWrightNotLike(String value) {
            addCriterion("wright not like", value, "wright");
            return (Criteria) this;
        }

        public Criteria andWrightIn(List<String> values) {
            addCriterion("wright in", values, "wright");
            return (Criteria) this;
        }

        public Criteria andWrightNotIn(List<String> values) {
            addCriterion("wright not in", values, "wright");
            return (Criteria) this;
        }

        public Criteria andWrightBetween(String value1, String value2) {
            addCriterion("wright between", value1, value2, "wright");
            return (Criteria) this;
        }

        public Criteria andWrightNotBetween(String value1, String value2) {
            addCriterion("wright not between", value1, value2, "wright");
            return (Criteria) this;
        }

        public Criteria andWxgzhIsNull() {
            addCriterion("wxgzh is null");
            return (Criteria) this;
        }

        public Criteria andWxgzhIsNotNull() {
            addCriterion("wxgzh is not null");
            return (Criteria) this;
        }

        public Criteria andWxgzhEqualTo(String value) {
            addCriterion("wxgzh =", value, "wxgzh");
            return (Criteria) this;
        }

        public Criteria andWxgzhNotEqualTo(String value) {
            addCriterion("wxgzh <>", value, "wxgzh");
            return (Criteria) this;
        }

        public Criteria andWxgzhGreaterThan(String value) {
            addCriterion("wxgzh >", value, "wxgzh");
            return (Criteria) this;
        }

        public Criteria andWxgzhGreaterThanOrEqualTo(String value) {
            addCriterion("wxgzh >=", value, "wxgzh");
            return (Criteria) this;
        }

        public Criteria andWxgzhLessThan(String value) {
            addCriterion("wxgzh <", value, "wxgzh");
            return (Criteria) this;
        }

        public Criteria andWxgzhLessThanOrEqualTo(String value) {
            addCriterion("wxgzh <=", value, "wxgzh");
            return (Criteria) this;
        }

        public Criteria andWxgzhLike(String value) {
            addCriterion("wxgzh like", value, "wxgzh");
            return (Criteria) this;
        }

        public Criteria andWxgzhNotLike(String value) {
            addCriterion("wxgzh not like", value, "wxgzh");
            return (Criteria) this;
        }

        public Criteria andWxgzhIn(List<String> values) {
            addCriterion("wxgzh in", values, "wxgzh");
            return (Criteria) this;
        }

        public Criteria andWxgzhNotIn(List<String> values) {
            addCriterion("wxgzh not in", values, "wxgzh");
            return (Criteria) this;
        }

        public Criteria andWxgzhBetween(String value1, String value2) {
            addCriterion("wxgzh between", value1, value2, "wxgzh");
            return (Criteria) this;
        }

        public Criteria andWxgzhNotBetween(String value1, String value2) {
            addCriterion("wxgzh not between", value1, value2, "wxgzh");
            return (Criteria) this;
        }

        public Criteria andWxxcxIsNull() {
            addCriterion("wxxcx is null");
            return (Criteria) this;
        }

        public Criteria andWxxcxIsNotNull() {
            addCriterion("wxxcx is not null");
            return (Criteria) this;
        }

        public Criteria andWxxcxEqualTo(String value) {
            addCriterion("wxxcx =", value, "wxxcx");
            return (Criteria) this;
        }

        public Criteria andWxxcxNotEqualTo(String value) {
            addCriterion("wxxcx <>", value, "wxxcx");
            return (Criteria) this;
        }

        public Criteria andWxxcxGreaterThan(String value) {
            addCriterion("wxxcx >", value, "wxxcx");
            return (Criteria) this;
        }

        public Criteria andWxxcxGreaterThanOrEqualTo(String value) {
            addCriterion("wxxcx >=", value, "wxxcx");
            return (Criteria) this;
        }

        public Criteria andWxxcxLessThan(String value) {
            addCriterion("wxxcx <", value, "wxxcx");
            return (Criteria) this;
        }

        public Criteria andWxxcxLessThanOrEqualTo(String value) {
            addCriterion("wxxcx <=", value, "wxxcx");
            return (Criteria) this;
        }

        public Criteria andWxxcxLike(String value) {
            addCriterion("wxxcx like", value, "wxxcx");
            return (Criteria) this;
        }

        public Criteria andWxxcxNotLike(String value) {
            addCriterion("wxxcx not like", value, "wxxcx");
            return (Criteria) this;
        }

        public Criteria andWxxcxIn(List<String> values) {
            addCriterion("wxxcx in", values, "wxxcx");
            return (Criteria) this;
        }

        public Criteria andWxxcxNotIn(List<String> values) {
            addCriterion("wxxcx not in", values, "wxxcx");
            return (Criteria) this;
        }

        public Criteria andWxxcxBetween(String value1, String value2) {
            addCriterion("wxxcx between", value1, value2, "wxxcx");
            return (Criteria) this;
        }

        public Criteria andWxxcxNotBetween(String value1, String value2) {
            addCriterion("wxxcx not between", value1, value2, "wxxcx");
            return (Criteria) this;
        }

        public Criteria andWxIsNull() {
            addCriterion("wx is null");
            return (Criteria) this;
        }

        public Criteria andWxIsNotNull() {
            addCriterion("wx is not null");
            return (Criteria) this;
        }

        public Criteria andWxEqualTo(String value) {
            addCriterion("wx =", value, "wx");
            return (Criteria) this;
        }

        public Criteria andWxNotEqualTo(String value) {
            addCriterion("wx <>", value, "wx");
            return (Criteria) this;
        }

        public Criteria andWxGreaterThan(String value) {
            addCriterion("wx >", value, "wx");
            return (Criteria) this;
        }

        public Criteria andWxGreaterThanOrEqualTo(String value) {
            addCriterion("wx >=", value, "wx");
            return (Criteria) this;
        }

        public Criteria andWxLessThan(String value) {
            addCriterion("wx <", value, "wx");
            return (Criteria) this;
        }

        public Criteria andWxLessThanOrEqualTo(String value) {
            addCriterion("wx <=", value, "wx");
            return (Criteria) this;
        }

        public Criteria andWxLike(String value) {
            addCriterion("wx like", value, "wx");
            return (Criteria) this;
        }

        public Criteria andWxNotLike(String value) {
            addCriterion("wx not like", value, "wx");
            return (Criteria) this;
        }

        public Criteria andWxIn(List<String> values) {
            addCriterion("wx in", values, "wx");
            return (Criteria) this;
        }

        public Criteria andWxNotIn(List<String> values) {
            addCriterion("wx not in", values, "wx");
            return (Criteria) this;
        }

        public Criteria andWxBetween(String value1, String value2) {
            addCriterion("wx between", value1, value2, "wx");
            return (Criteria) this;
        }

        public Criteria andWxNotBetween(String value1, String value2) {
            addCriterion("wx not between", value1, value2, "wx");
            return (Criteria) this;
        }

        public Criteria andWzcxIsNull() {
            addCriterion("wzcx is null");
            return (Criteria) this;
        }

        public Criteria andWzcxIsNotNull() {
            addCriterion("wzcx is not null");
            return (Criteria) this;
        }

        public Criteria andWzcxEqualTo(String value) {
            addCriterion("wzcx =", value, "wzcx");
            return (Criteria) this;
        }

        public Criteria andWzcxNotEqualTo(String value) {
            addCriterion("wzcx <>", value, "wzcx");
            return (Criteria) this;
        }

        public Criteria andWzcxGreaterThan(String value) {
            addCriterion("wzcx >", value, "wzcx");
            return (Criteria) this;
        }

        public Criteria andWzcxGreaterThanOrEqualTo(String value) {
            addCriterion("wzcx >=", value, "wzcx");
            return (Criteria) this;
        }

        public Criteria andWzcxLessThan(String value) {
            addCriterion("wzcx <", value, "wzcx");
            return (Criteria) this;
        }

        public Criteria andWzcxLessThanOrEqualTo(String value) {
            addCriterion("wzcx <=", value, "wzcx");
            return (Criteria) this;
        }

        public Criteria andWzcxLike(String value) {
            addCriterion("wzcx like", value, "wzcx");
            return (Criteria) this;
        }

        public Criteria andWzcxNotLike(String value) {
            addCriterion("wzcx not like", value, "wzcx");
            return (Criteria) this;
        }

        public Criteria andWzcxIn(List<String> values) {
            addCriterion("wzcx in", values, "wzcx");
            return (Criteria) this;
        }

        public Criteria andWzcxNotIn(List<String> values) {
            addCriterion("wzcx not in", values, "wzcx");
            return (Criteria) this;
        }

        public Criteria andWzcxBetween(String value1, String value2) {
            addCriterion("wzcx between", value1, value2, "wzcx");
            return (Criteria) this;
        }

        public Criteria andWzcxNotBetween(String value1, String value2) {
            addCriterion("wzcx not between", value1, value2, "wzcx");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}