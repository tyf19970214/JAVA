package com.box.entity;

import java.util.Date;

public class DbAdminlog {
    private Integer id;

    private String ip;

    private Date logtime;

    private Integer aid;

    private String computeraddress;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip == null ? null : ip.trim();
    }

    public Date getLogtime() {
        return logtime;
    }

    public void setLogtime(Date logtime) {
        this.logtime = logtime;
    }

    public Integer getAid() {
        return aid;
    }

    public void setAid(Integer aid) {
        this.aid = aid;
    }

    public String getComputeraddress() {
        return computeraddress;
    }

    public void setComputeraddress(String computeraddress) {
        this.computeraddress = computeraddress == null ? null : computeraddress.trim();
    }
}