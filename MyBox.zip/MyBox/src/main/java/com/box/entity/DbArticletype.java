package com.box.entity;

public class DbArticletype {
    private Integer id;

    private String typname;

    private String typdes;

    private Integer typeclicks;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTypname() {
        return typname;
    }

    public void setTypname(String typname) {
        this.typname = typname == null ? null : typname.trim();
    }

    public String getTypdes() {
        return typdes;
    }

    public void setTypdes(String typdes) {
        this.typdes = typdes == null ? null : typdes.trim();
    }

    public Integer getTypeclicks() {
        return typeclicks;
    }

    public void setTypeclicks(Integer typeclicks) {
        this.typeclicks = typeclicks;
    }
}