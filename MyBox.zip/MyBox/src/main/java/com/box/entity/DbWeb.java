package com.box.entity;

public class DbWeb {
    private Integer wid;

    private String wtitle;

    private String wdes;

    private String wurl;

    private String wdescription;

    private String wkeywords;

    private String wcopyright;

    private String wrecord;

    private String wicon;

    private String wleftinfo;

    private String wright;

    private String wxgzh;

    private String wxxcx;

    private String wx;

    private String wzcx;

    public Integer getWid() {
        return wid;
    }

    public void setWid(Integer wid) {
        this.wid = wid;
    }

    public String getWtitle() {
        return wtitle;
    }

    public void setWtitle(String wtitle) {
        this.wtitle = wtitle == null ? null : wtitle.trim();
    }

    public String getWdes() {
        return wdes;
    }

    public void setWdes(String wdes) {
        this.wdes = wdes == null ? null : wdes.trim();
    }

    public String getWurl() {
        return wurl;
    }

    public void setWurl(String wurl) {
        this.wurl = wurl == null ? null : wurl.trim();
    }

    public String getWdescription() {
        return wdescription;
    }

    public void setWdescription(String wdescription) {
        this.wdescription = wdescription == null ? null : wdescription.trim();
    }

    public String getWkeywords() {
        return wkeywords;
    }

    public void setWkeywords(String wkeywords) {
        this.wkeywords = wkeywords == null ? null : wkeywords.trim();
    }

    public String getWcopyright() {
        return wcopyright;
    }

    public void setWcopyright(String wcopyright) {
        this.wcopyright = wcopyright == null ? null : wcopyright.trim();
    }

    public String getWrecord() {
        return wrecord;
    }

    public void setWrecord(String wrecord) {
        this.wrecord = wrecord == null ? null : wrecord.trim();
    }

    public String getWicon() {
        return wicon;
    }

    public void setWicon(String wicon) {
        this.wicon = wicon == null ? null : wicon.trim();
    }

    public String getWleftinfo() {
        return wleftinfo;
    }

    public void setWleftinfo(String wleftinfo) {
        this.wleftinfo = wleftinfo == null ? null : wleftinfo.trim();
    }

    public String getWright() {
        return wright;
    }

    public void setWright(String wright) {
        this.wright = wright == null ? null : wright.trim();
    }

    public String getWxgzh() {
        return wxgzh;
    }

    public void setWxgzh(String wxgzh) {
        this.wxgzh = wxgzh == null ? null : wxgzh.trim();
    }

    public String getWxxcx() {
        return wxxcx;
    }

    public void setWxxcx(String wxxcx) {
        this.wxxcx = wxxcx == null ? null : wxxcx.trim();
    }

    public String getWx() {
        return wx;
    }

    public void setWx(String wx) {
        this.wx = wx == null ? null : wx.trim();
    }

    public String getWzcx() {
        return wzcx;
    }

    public void setWzcx(String wzcx) {
        this.wzcx = wzcx == null ? null : wzcx.trim();
    }
}