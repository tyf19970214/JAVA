package com.box.entity;

import java.util.Date;

/**
 * @author 文章文章类型用户表，三表联查
 *
 */
public class DbUserAndDbArticleResultAndDbArticleType {
	private Integer arid;//文章编号
	private String artitle;//文章标题
	private String arcontent;//文章内容
	private String simpledes;//文章简介
	private Integer isTop;//置顶0.不置顶1.置顶
	private String username;//用户用户名
	private Integer clicks;//点击率
	private Boolean isView;//审核，是否可看。
	private String typname;//文章类型名称
	private String img;//文章图片
	private Date arcreatetime;//文章创建时间
	private Date updatetime;//文章修改时间
	public Integer getArid() {
		return arid;
	}
	public void setArid(Integer arid) {
		this.arid = arid;
	}
	public String getArtitle() {
		return artitle;
	}
	public void setArtitle(String artitle) {
		this.artitle = artitle;
	}
	public String getArcontent() {
		return arcontent;
	}
	public void setArcontent(String arcontent) {
		this.arcontent = arcontent;
	}
	public String getSimpledes() {
		return simpledes;
	}
	public void setSimpledes(String simpledes) {
		this.simpledes = simpledes;
	}
	public Integer getIsTop() {
		return isTop;
	}
	public void setIsTop(Integer isTop) {
		this.isTop = isTop;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public Integer getClicks() {
		return clicks;
	}
	public void setClicks(Integer clicks) {
		this.clicks = clicks;
	}
	public Boolean getIsView() {
		return isView;
	}
	public void setIsView(Boolean isView) {
		this.isView = isView;
	}
	public String getTypname() {
		return typname;
	}
	public void setTypname(String typname) {
		this.typname = typname;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	public Date getArcreatetime() {
		return arcreatetime;
	}
	public void setArcreatetime(Date arcreatetime) {
		this.arcreatetime = arcreatetime;
	}
	public Date getUpdatetime() {
		return updatetime;
	}
	public void setUpdatetime(Date updatetime) {
		this.updatetime = updatetime;
	}
	@Override
	public String toString() {
		return "DbUserAndDbArticleResultAndDbArticleType [arid=" + arid
				+ ", artitle=" + artitle + ", arcontent=" + arcontent
				+ ", simpledes=" + simpledes + ", isTop=" + isTop
				+ ", username=" + username + ", clicks=" + clicks + ", isView="
				+ isView + ", typname=" + typname + ", img=" + img
				+ ", arcreatetime=" + arcreatetime + ", updatetime="
				+ updatetime + "]";
	}
	public DbUserAndDbArticleResultAndDbArticleType(Integer arid,
			String artitle, String arcontent, String simpledes, Integer isTop,
			String username, Integer clicks, Boolean isView, String typname,
			String img, Date arcreatetime, Date updatetime) {
		super();
		this.arid = arid;
		this.artitle = artitle;
		this.arcontent = arcontent;
		this.simpledes = simpledes;
		this.isTop = isTop;
		this.username = username;
		this.clicks = clicks;
		this.isView = isView;
		this.typname = typname;
		this.img = img;
		this.arcreatetime = arcreatetime;
		this.updatetime = updatetime;
	}
	public DbUserAndDbArticleResultAndDbArticleType() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
