package com.box.entity;

/**
 * @author 文章搜索关键词
 *
 */
public class ArticleSearch {
	private String artitle;
	private String artypeid;
	private String isView;
	private String uid;
	private String arcontent;
	private String simpledes;
	private String createTimeStart;
	private String createTimeEnd;
	private String operation;
	public String getArtitle() {
		return artitle;
	}
	public void setArtitle(String artitle) {
		this.artitle = artitle;
	}
	public String getArtypeid() {
		return artypeid;
	}
	public void setArtypeid(String artypeid) {
		this.artypeid = artypeid;
	}
	public String getIsView() {
		return isView;
	}
	public void setIsView(String isView) {
		this.isView = isView;
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getArcontent() {
		return arcontent;
	}
	public void setArcontent(String arcontent) {
		this.arcontent = arcontent;
	}
	public String getSimpledes() {
		return simpledes;
	}
	public void setSimpledes(String simpledes) {
		this.simpledes = simpledes;
	}
	public String getCreateTimeStart() {
		return createTimeStart;
	}
	public void setCreateTimeStart(String createTimeStart) {
		this.createTimeStart = createTimeStart;
	}
	public String getCreateTimeEnd() {
		return createTimeEnd;
	}
	public void setCreateTimeEnd(String createTimeEnd) {
		this.createTimeEnd = createTimeEnd;
	}
	public String getOperation() {
		return operation;
	}
	public void setOperation(String operation) {
		this.operation = operation;
	}
	@Override
	public String toString() {
		return "ArticleSearch [artitle=" + artitle + ", artypeid=" + artypeid
				+ ", isView=" + isView + ", uid=" + uid + ", arcontent="
				+ arcontent + ", simpledes=" + simpledes + ", createTimeStart="
				+ createTimeStart + ", createTimeEnd=" + createTimeEnd
				+ ", operation=" + operation + "]";
	}
	public ArticleSearch(String artitle, String artypeid, String isView,
			String uid, String arcontent, String simpledes,
			String createTimeStart, String createTimeEnd, String operation) {
		super();
		this.artitle = artitle;
		this.artypeid = artypeid;
		this.isView = isView;
		this.uid = uid;
		this.arcontent = arcontent;
		this.simpledes = simpledes;
		this.createTimeStart = createTimeStart;
		this.createTimeEnd = createTimeEnd;
		this.operation = operation;
	}
	public ArticleSearch() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
