package com.box.entity;

import java.sql.Timestamp;
import java.util.Date;

public class ResultAdminLog {
	
	private String username;
	private String realname;	
	private String ip;
	private Date logtime;
	private String computeraddress;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getRealname() {
		return realname;
	}
	public void setRealname(String realname) {
		this.realname = realname;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public Date getLogtime() {
		return logtime;
	}
	public void setLogtime(Date logtime) {
		this.logtime = logtime;
	}
	public String getComputeraddress() {
		return computeraddress;
	}
	public void setComputeraddress(String computeraddress) {
		this.computeraddress = computeraddress;
	}
	public ResultAdminLog(String username, String ip, Date logtime,
			String computeraddress) {
		super();
		this.username = username;
		this.ip = ip;
		this.logtime = logtime;
		this.computeraddress = computeraddress;
	}
	public ResultAdminLog() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "ResultAdminLog [username=" + username + ", ip=" + ip
				+ ", logtime=" + logtime + ", computeraddress="
				+ computeraddress + "]";
	}
	

}
