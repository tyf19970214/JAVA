package com.box.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class DbArticleExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public DbArticleExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andAridIsNull() {
            addCriterion("arid is null");
            return (Criteria) this;
        }

        public Criteria andAridIsNotNull() {
            addCriterion("arid is not null");
            return (Criteria) this;
        }

        public Criteria andAridEqualTo(Integer value) {
            addCriterion("arid =", value, "arid");
            return (Criteria) this;
        }

        public Criteria andAridNotEqualTo(Integer value) {
            addCriterion("arid <>", value, "arid");
            return (Criteria) this;
        }

        public Criteria andAridGreaterThan(Integer value) {
            addCriterion("arid >", value, "arid");
            return (Criteria) this;
        }

        public Criteria andAridGreaterThanOrEqualTo(Integer value) {
            addCriterion("arid >=", value, "arid");
            return (Criteria) this;
        }

        public Criteria andAridLessThan(Integer value) {
            addCriterion("arid <", value, "arid");
            return (Criteria) this;
        }

        public Criteria andAridLessThanOrEqualTo(Integer value) {
            addCriterion("arid <=", value, "arid");
            return (Criteria) this;
        }

        public Criteria andAridIn(List<Integer> values) {
            addCriterion("arid in", values, "arid");
            return (Criteria) this;
        }

        public Criteria andAridNotIn(List<Integer> values) {
            addCriterion("arid not in", values, "arid");
            return (Criteria) this;
        }

        public Criteria andAridBetween(Integer value1, Integer value2) {
            addCriterion("arid between", value1, value2, "arid");
            return (Criteria) this;
        }

        public Criteria andAridNotBetween(Integer value1, Integer value2) {
            addCriterion("arid not between", value1, value2, "arid");
            return (Criteria) this;
        }

        public Criteria andArtitleIsNull() {
            addCriterion("artitle is null");
            return (Criteria) this;
        }

        public Criteria andArtitleIsNotNull() {
            addCriterion("artitle is not null");
            return (Criteria) this;
        }

        public Criteria andArtitleEqualTo(String value) {
            addCriterion("artitle =", value, "artitle");
            return (Criteria) this;
        }

        public Criteria andArtitleNotEqualTo(String value) {
            addCriterion("artitle <>", value, "artitle");
            return (Criteria) this;
        }

        public Criteria andArtitleGreaterThan(String value) {
            addCriterion("artitle >", value, "artitle");
            return (Criteria) this;
        }

        public Criteria andArtitleGreaterThanOrEqualTo(String value) {
            addCriterion("artitle >=", value, "artitle");
            return (Criteria) this;
        }

        public Criteria andArtitleLessThan(String value) {
            addCriterion("artitle <", value, "artitle");
            return (Criteria) this;
        }

        public Criteria andArtitleLessThanOrEqualTo(String value) {
            addCriterion("artitle <=", value, "artitle");
            return (Criteria) this;
        }

        public Criteria andArtitleLike(String value) {
            addCriterion("artitle like", value, "artitle");
            return (Criteria) this;
        }

        public Criteria andArtitleNotLike(String value) {
            addCriterion("artitle not like", value, "artitle");
            return (Criteria) this;
        }

        public Criteria andArtitleIn(List<String> values) {
            addCriterion("artitle in", values, "artitle");
            return (Criteria) this;
        }

        public Criteria andArtitleNotIn(List<String> values) {
            addCriterion("artitle not in", values, "artitle");
            return (Criteria) this;
        }

        public Criteria andArtitleBetween(String value1, String value2) {
            addCriterion("artitle between", value1, value2, "artitle");
            return (Criteria) this;
        }

        public Criteria andArtitleNotBetween(String value1, String value2) {
            addCriterion("artitle not between", value1, value2, "artitle");
            return (Criteria) this;
        }

        public Criteria andArcontentIsNull() {
            addCriterion("arcontent is null");
            return (Criteria) this;
        }

        public Criteria andArcontentIsNotNull() {
            addCriterion("arcontent is not null");
            return (Criteria) this;
        }

        public Criteria andArcontentEqualTo(String value) {
            addCriterion("arcontent =", value, "arcontent");
            return (Criteria) this;
        }

        public Criteria andArcontentNotEqualTo(String value) {
            addCriterion("arcontent <>", value, "arcontent");
            return (Criteria) this;
        }

        public Criteria andArcontentGreaterThan(String value) {
            addCriterion("arcontent >", value, "arcontent");
            return (Criteria) this;
        }

        public Criteria andArcontentGreaterThanOrEqualTo(String value) {
            addCriterion("arcontent >=", value, "arcontent");
            return (Criteria) this;
        }

        public Criteria andArcontentLessThan(String value) {
            addCriterion("arcontent <", value, "arcontent");
            return (Criteria) this;
        }

        public Criteria andArcontentLessThanOrEqualTo(String value) {
            addCriterion("arcontent <=", value, "arcontent");
            return (Criteria) this;
        }

        public Criteria andArcontentLike(String value) {
            addCriterion("arcontent like", value, "arcontent");
            return (Criteria) this;
        }

        public Criteria andArcontentNotLike(String value) {
            addCriterion("arcontent not like", value, "arcontent");
            return (Criteria) this;
        }

        public Criteria andArcontentIn(List<String> values) {
            addCriterion("arcontent in", values, "arcontent");
            return (Criteria) this;
        }

        public Criteria andArcontentNotIn(List<String> values) {
            addCriterion("arcontent not in", values, "arcontent");
            return (Criteria) this;
        }

        public Criteria andArcontentBetween(String value1, String value2) {
            addCriterion("arcontent between", value1, value2, "arcontent");
            return (Criteria) this;
        }

        public Criteria andArcontentNotBetween(String value1, String value2) {
            addCriterion("arcontent not between", value1, value2, "arcontent");
            return (Criteria) this;
        }

        public Criteria andSimpledesIsNull() {
            addCriterion("simpledes is null");
            return (Criteria) this;
        }

        public Criteria andSimpledesIsNotNull() {
            addCriterion("simpledes is not null");
            return (Criteria) this;
        }

        public Criteria andSimpledesEqualTo(String value) {
            addCriterion("simpledes =", value, "simpledes");
            return (Criteria) this;
        }

        public Criteria andSimpledesNotEqualTo(String value) {
            addCriterion("simpledes <>", value, "simpledes");
            return (Criteria) this;
        }

        public Criteria andSimpledesGreaterThan(String value) {
            addCriterion("simpledes >", value, "simpledes");
            return (Criteria) this;
        }

        public Criteria andSimpledesGreaterThanOrEqualTo(String value) {
            addCriterion("simpledes >=", value, "simpledes");
            return (Criteria) this;
        }

        public Criteria andSimpledesLessThan(String value) {
            addCriterion("simpledes <", value, "simpledes");
            return (Criteria) this;
        }

        public Criteria andSimpledesLessThanOrEqualTo(String value) {
            addCriterion("simpledes <=", value, "simpledes");
            return (Criteria) this;
        }

        public Criteria andSimpledesLike(String value) {
            addCriterion("simpledes like", value, "simpledes");
            return (Criteria) this;
        }

        public Criteria andSimpledesNotLike(String value) {
            addCriterion("simpledes not like", value, "simpledes");
            return (Criteria) this;
        }

        public Criteria andSimpledesIn(List<String> values) {
            addCriterion("simpledes in", values, "simpledes");
            return (Criteria) this;
        }

        public Criteria andSimpledesNotIn(List<String> values) {
            addCriterion("simpledes not in", values, "simpledes");
            return (Criteria) this;
        }

        public Criteria andSimpledesBetween(String value1, String value2) {
            addCriterion("simpledes between", value1, value2, "simpledes");
            return (Criteria) this;
        }

        public Criteria andSimpledesNotBetween(String value1, String value2) {
            addCriterion("simpledes not between", value1, value2, "simpledes");
            return (Criteria) this;
        }

        public Criteria andIstopIsNull() {
            addCriterion("isTop is null");
            return (Criteria) this;
        }

        public Criteria andIstopIsNotNull() {
            addCriterion("isTop is not null");
            return (Criteria) this;
        }

        public Criteria andIstopEqualTo(Integer value) {
            addCriterion("isTop =", value, "istop");
            return (Criteria) this;
        }

        public Criteria andIstopNotEqualTo(Integer value) {
            addCriterion("isTop <>", value, "istop");
            return (Criteria) this;
        }

        public Criteria andIstopGreaterThan(Integer value) {
            addCriterion("isTop >", value, "istop");
            return (Criteria) this;
        }

        public Criteria andIstopGreaterThanOrEqualTo(Integer value) {
            addCriterion("isTop >=", value, "istop");
            return (Criteria) this;
        }

        public Criteria andIstopLessThan(Integer value) {
            addCriterion("isTop <", value, "istop");
            return (Criteria) this;
        }

        public Criteria andIstopLessThanOrEqualTo(Integer value) {
            addCriterion("isTop <=", value, "istop");
            return (Criteria) this;
        }

        public Criteria andIstopIn(List<Integer> values) {
            addCriterion("isTop in", values, "istop");
            return (Criteria) this;
        }

        public Criteria andIstopNotIn(List<Integer> values) {
            addCriterion("isTop not in", values, "istop");
            return (Criteria) this;
        }

        public Criteria andIstopBetween(Integer value1, Integer value2) {
            addCriterion("isTop between", value1, value2, "istop");
            return (Criteria) this;
        }

        public Criteria andIstopNotBetween(Integer value1, Integer value2) {
            addCriterion("isTop not between", value1, value2, "istop");
            return (Criteria) this;
        }

        public Criteria andUidIsNull() {
            addCriterion("uid is null");
            return (Criteria) this;
        }

        public Criteria andUidIsNotNull() {
            addCriterion("uid is not null");
            return (Criteria) this;
        }

        public Criteria andUidEqualTo(Integer value) {
            addCriterion("uid =", value, "uid");
            return (Criteria) this;
        }

        public Criteria andUidNotEqualTo(Integer value) {
            addCriterion("uid <>", value, "uid");
            return (Criteria) this;
        }

        public Criteria andUidGreaterThan(Integer value) {
            addCriterion("uid >", value, "uid");
            return (Criteria) this;
        }

        public Criteria andUidGreaterThanOrEqualTo(Integer value) {
            addCriterion("uid >=", value, "uid");
            return (Criteria) this;
        }

        public Criteria andUidLessThan(Integer value) {
            addCriterion("uid <", value, "uid");
            return (Criteria) this;
        }

        public Criteria andUidLessThanOrEqualTo(Integer value) {
            addCriterion("uid <=", value, "uid");
            return (Criteria) this;
        }

        public Criteria andUidIn(List<Integer> values) {
            addCriterion("uid in", values, "uid");
            return (Criteria) this;
        }

        public Criteria andUidNotIn(List<Integer> values) {
            addCriterion("uid not in", values, "uid");
            return (Criteria) this;
        }

        public Criteria andUidBetween(Integer value1, Integer value2) {
            addCriterion("uid between", value1, value2, "uid");
            return (Criteria) this;
        }

        public Criteria andUidNotBetween(Integer value1, Integer value2) {
            addCriterion("uid not between", value1, value2, "uid");
            return (Criteria) this;
        }

        public Criteria andClicksIsNull() {
            addCriterion("clicks is null");
            return (Criteria) this;
        }

        public Criteria andClicksIsNotNull() {
            addCriterion("clicks is not null");
            return (Criteria) this;
        }

        public Criteria andClicksEqualTo(Integer value) {
            addCriterion("clicks =", value, "clicks");
            return (Criteria) this;
        }

        public Criteria andClicksNotEqualTo(Integer value) {
            addCriterion("clicks <>", value, "clicks");
            return (Criteria) this;
        }

        public Criteria andClicksGreaterThan(Integer value) {
            addCriterion("clicks >", value, "clicks");
            return (Criteria) this;
        }

        public Criteria andClicksGreaterThanOrEqualTo(Integer value) {
            addCriterion("clicks >=", value, "clicks");
            return (Criteria) this;
        }

        public Criteria andClicksLessThan(Integer value) {
            addCriterion("clicks <", value, "clicks");
            return (Criteria) this;
        }

        public Criteria andClicksLessThanOrEqualTo(Integer value) {
            addCriterion("clicks <=", value, "clicks");
            return (Criteria) this;
        }

        public Criteria andClicksIn(List<Integer> values) {
            addCriterion("clicks in", values, "clicks");
            return (Criteria) this;
        }

        public Criteria andClicksNotIn(List<Integer> values) {
            addCriterion("clicks not in", values, "clicks");
            return (Criteria) this;
        }

        public Criteria andClicksBetween(Integer value1, Integer value2) {
            addCriterion("clicks between", value1, value2, "clicks");
            return (Criteria) this;
        }

        public Criteria andClicksNotBetween(Integer value1, Integer value2) {
            addCriterion("clicks not between", value1, value2, "clicks");
            return (Criteria) this;
        }

        public Criteria andIsviewIsNull() {
            addCriterion("isView is null");
            return (Criteria) this;
        }

        public Criteria andIsviewIsNotNull() {
            addCriterion("isView is not null");
            return (Criteria) this;
        }

        public Criteria andIsviewEqualTo(Integer value) {
            addCriterion("isView =", value, "isview");
            return (Criteria) this;
        }

        public Criteria andIsviewNotEqualTo(Integer value) {
            addCriterion("isView <>", value, "isview");
            return (Criteria) this;
        }

        public Criteria andIsviewGreaterThan(Integer value) {
            addCriterion("isView >", value, "isview");
            return (Criteria) this;
        }

        public Criteria andIsviewGreaterThanOrEqualTo(Integer value) {
            addCriterion("isView >=", value, "isview");
            return (Criteria) this;
        }

        public Criteria andIsviewLessThan(Integer value) {
            addCriterion("isView <", value, "isview");
            return (Criteria) this;
        }

        public Criteria andIsviewLessThanOrEqualTo(Integer value) {
            addCriterion("isView <=", value, "isview");
            return (Criteria) this;
        }

        public Criteria andIsviewIn(List<Integer> values) {
            addCriterion("isView in", values, "isview");
            return (Criteria) this;
        }

        public Criteria andIsviewNotIn(List<Integer> values) {
            addCriterion("isView not in", values, "isview");
            return (Criteria) this;
        }

        public Criteria andIsviewBetween(Integer value1, Integer value2) {
            addCriterion("isView between", value1, value2, "isview");
            return (Criteria) this;
        }

        public Criteria andIsviewNotBetween(Integer value1, Integer value2) {
            addCriterion("isView not between", value1, value2, "isview");
            return (Criteria) this;
        }

        public Criteria andUpperidIsNull() {
            addCriterion("upperid is null");
            return (Criteria) this;
        }

        public Criteria andUpperidIsNotNull() {
            addCriterion("upperid is not null");
            return (Criteria) this;
        }

        public Criteria andUpperidEqualTo(Integer value) {
            addCriterion("upperid =", value, "upperid");
            return (Criteria) this;
        }

        public Criteria andUpperidNotEqualTo(Integer value) {
            addCriterion("upperid <>", value, "upperid");
            return (Criteria) this;
        }

        public Criteria andUpperidGreaterThan(Integer value) {
            addCriterion("upperid >", value, "upperid");
            return (Criteria) this;
        }

        public Criteria andUpperidGreaterThanOrEqualTo(Integer value) {
            addCriterion("upperid >=", value, "upperid");
            return (Criteria) this;
        }

        public Criteria andUpperidLessThan(Integer value) {
            addCriterion("upperid <", value, "upperid");
            return (Criteria) this;
        }

        public Criteria andUpperidLessThanOrEqualTo(Integer value) {
            addCriterion("upperid <=", value, "upperid");
            return (Criteria) this;
        }

        public Criteria andUpperidIn(List<Integer> values) {
            addCriterion("upperid in", values, "upperid");
            return (Criteria) this;
        }

        public Criteria andUpperidNotIn(List<Integer> values) {
            addCriterion("upperid not in", values, "upperid");
            return (Criteria) this;
        }

        public Criteria andUpperidBetween(Integer value1, Integer value2) {
            addCriterion("upperid between", value1, value2, "upperid");
            return (Criteria) this;
        }

        public Criteria andUpperidNotBetween(Integer value1, Integer value2) {
            addCriterion("upperid not between", value1, value2, "upperid");
            return (Criteria) this;
        }

        public Criteria andArtypeidIsNull() {
            addCriterion("artypeid is null");
            return (Criteria) this;
        }

        public Criteria andArtypeidIsNotNull() {
            addCriterion("artypeid is not null");
            return (Criteria) this;
        }

        public Criteria andArtypeidEqualTo(Integer value) {
            addCriterion("artypeid =", value, "artypeid");
            return (Criteria) this;
        }

        public Criteria andArtypeidNotEqualTo(Integer value) {
            addCriterion("artypeid <>", value, "artypeid");
            return (Criteria) this;
        }

        public Criteria andArtypeidGreaterThan(Integer value) {
            addCriterion("artypeid >", value, "artypeid");
            return (Criteria) this;
        }

        public Criteria andArtypeidGreaterThanOrEqualTo(Integer value) {
            addCriterion("artypeid >=", value, "artypeid");
            return (Criteria) this;
        }

        public Criteria andArtypeidLessThan(Integer value) {
            addCriterion("artypeid <", value, "artypeid");
            return (Criteria) this;
        }

        public Criteria andArtypeidLessThanOrEqualTo(Integer value) {
            addCriterion("artypeid <=", value, "artypeid");
            return (Criteria) this;
        }

        public Criteria andArtypeidIn(List<Integer> values) {
            addCriterion("artypeid in", values, "artypeid");
            return (Criteria) this;
        }

        public Criteria andArtypeidNotIn(List<Integer> values) {
            addCriterion("artypeid not in", values, "artypeid");
            return (Criteria) this;
        }

        public Criteria andArtypeidBetween(Integer value1, Integer value2) {
            addCriterion("artypeid between", value1, value2, "artypeid");
            return (Criteria) this;
        }

        public Criteria andArtypeidNotBetween(Integer value1, Integer value2) {
            addCriterion("artypeid not between", value1, value2, "artypeid");
            return (Criteria) this;
        }

        public Criteria andImgIsNull() {
            addCriterion("img is null");
            return (Criteria) this;
        }

        public Criteria andImgIsNotNull() {
            addCriterion("img is not null");
            return (Criteria) this;
        }

        public Criteria andImgEqualTo(String value) {
            addCriterion("img =", value, "img");
            return (Criteria) this;
        }

        public Criteria andImgNotEqualTo(String value) {
            addCriterion("img <>", value, "img");
            return (Criteria) this;
        }

        public Criteria andImgGreaterThan(String value) {
            addCriterion("img >", value, "img");
            return (Criteria) this;
        }

        public Criteria andImgGreaterThanOrEqualTo(String value) {
            addCriterion("img >=", value, "img");
            return (Criteria) this;
        }

        public Criteria andImgLessThan(String value) {
            addCriterion("img <", value, "img");
            return (Criteria) this;
        }

        public Criteria andImgLessThanOrEqualTo(String value) {
            addCriterion("img <=", value, "img");
            return (Criteria) this;
        }

        public Criteria andImgLike(String value) {
            addCriterion("img like", value, "img");
            return (Criteria) this;
        }

        public Criteria andImgNotLike(String value) {
            addCriterion("img not like", value, "img");
            return (Criteria) this;
        }

        public Criteria andImgIn(List<String> values) {
            addCriterion("img in", values, "img");
            return (Criteria) this;
        }

        public Criteria andImgNotIn(List<String> values) {
            addCriterion("img not in", values, "img");
            return (Criteria) this;
        }

        public Criteria andImgBetween(String value1, String value2) {
            addCriterion("img between", value1, value2, "img");
            return (Criteria) this;
        }

        public Criteria andImgNotBetween(String value1, String value2) {
            addCriterion("img not between", value1, value2, "img");
            return (Criteria) this;
        }

        public Criteria andArcreatetimeIsNull() {
            addCriterion("arcreatetime is null");
            return (Criteria) this;
        }

        public Criteria andArcreatetimeIsNotNull() {
            addCriterion("arcreatetime is not null");
            return (Criteria) this;
        }

        public Criteria andArcreatetimeEqualTo(Date value) {
            addCriterion("arcreatetime =", value, "arcreatetime");
            return (Criteria) this;
        }

        public Criteria andArcreatetimeNotEqualTo(Date value) {
            addCriterion("arcreatetime <>", value, "arcreatetime");
            return (Criteria) this;
        }

        public Criteria andArcreatetimeGreaterThan(Date value) {
            addCriterion("arcreatetime >", value, "arcreatetime");
            return (Criteria) this;
        }

        public Criteria andArcreatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("arcreatetime >=", value, "arcreatetime");
            return (Criteria) this;
        }

        public Criteria andArcreatetimeLessThan(Date value) {
            addCriterion("arcreatetime <", value, "arcreatetime");
            return (Criteria) this;
        }

        public Criteria andArcreatetimeLessThanOrEqualTo(Date value) {
            addCriterion("arcreatetime <=", value, "arcreatetime");
            return (Criteria) this;
        }

        public Criteria andArcreatetimeIn(List<Date> values) {
            addCriterion("arcreatetime in", values, "arcreatetime");
            return (Criteria) this;
        }

        public Criteria andArcreatetimeNotIn(List<Date> values) {
            addCriterion("arcreatetime not in", values, "arcreatetime");
            return (Criteria) this;
        }

        public Criteria andArcreatetimeBetween(Date value1, Date value2) {
            addCriterion("arcreatetime between", value1, value2, "arcreatetime");
            return (Criteria) this;
        }

        public Criteria andArcreatetimeNotBetween(Date value1, Date value2) {
            addCriterion("arcreatetime not between", value1, value2, "arcreatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIsNull() {
            addCriterion("updatetime is null");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIsNotNull() {
            addCriterion("updatetime is not null");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeEqualTo(Date value) {
            addCriterion("updatetime =", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotEqualTo(Date value) {
            addCriterion("updatetime <>", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeGreaterThan(Date value) {
            addCriterion("updatetime >", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("updatetime >=", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeLessThan(Date value) {
            addCriterion("updatetime <", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeLessThanOrEqualTo(Date value) {
            addCriterion("updatetime <=", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIn(List<Date> values) {
            addCriterion("updatetime in", values, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotIn(List<Date> values) {
            addCriterion("updatetime not in", values, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeBetween(Date value1, Date value2) {
            addCriterion("updatetime between", value1, value2, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotBetween(Date value1, Date value2) {
            addCriterion("updatetime not between", value1, value2, "updatetime");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}