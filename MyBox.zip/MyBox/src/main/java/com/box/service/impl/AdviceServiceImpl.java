package com.box.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.box.entity.AdviceSearch;
import com.box.entity.DbAdvice;
import com.box.entity.DbAdviceExample;
import com.box.entity.DbAdviceExample.Criteria;
import com.box.mapper.DbAdviceMapper;
import com.box.service.AdviceService;
import com.box.utils.LayuiResult;
import com.box.utils.MyUtil;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

/**
*<p>Title:AdviceServiceImpl.java</p>
*<p>Description:</p>
*<p>Company:www.99weixinxcx.cn</p>
*@author 陕西电子科技学院:滕一帆
*@date	2019年5月9日上午3:25:17
*@version 1.0
*
*
*
 */
@Service
public class AdviceServiceImpl implements AdviceService {
	
	@Autowired
	private DbAdviceMapper adviceMapper;

	public LayuiResult selAdviceBySearch(Integer page, Integer limit,
			AdviceSearch search) {
		// TODO Auto-generated method stub
		try {
			PageHelper.startPage(page, limit);
			DbAdviceExample examlpe=new DbAdviceExample();
			examlpe.setOrderByClause("updatetime desc");
			Criteria createCriteria = examlpe.createCriteria();
			//公告标题不为空
			if(search.getAdvtitle()!=null&&!search.getAdvtitle().equals("")){
				createCriteria.andAdvtitleLike("%"+search.getAdvtitle()+"%");
				
			}
			if(search.getAid()!=null&&!"-1".equals(search.getAid())){
				createCriteria.andAidEqualTo(Integer.parseInt(search.getAid()));
			}
			if(search.getAdvcontent()!=null&&!search.getAdvcontent().equals("")){
				createCriteria.andAdvcontentLike("%"+search.getAdvcontent()+"%");
			}
			if(search.getAdvdescribe()!=null&&!search.getAdvdescribe().equals("")){
				createCriteria.andAdvdescribeLike("%"+search.getAdvdescribe()+"%");
			}
			if(search.getCreateTimeStart()!=null&&!"".equals(search.getCreateTimeStart())){
				
				createCriteria.andUpdatetimeGreaterThanOrEqualTo(MyUtil.getDateByString(search.getCreateTimeStart()));
			}
			if(search.getCreateTimeEnd()!=null&&!"".equals(search.getCreateTimeEnd())){
				createCriteria.andUpdatetimeLessThanOrEqualTo(MyUtil.getDateByString(search.getCreateTimeEnd()));
			}
			List<DbAdvice> list= adviceMapper.selectByExample(examlpe);
			PageInfo<DbAdvice> pageinfo=new PageInfo<DbAdvice>(list);
			LayuiResult result=new LayuiResult();
			result.setCode(0);
			result.setCount(pageinfo.getTotal());
			result.setMsg("成功获取数据列表");
			result.setData(pageinfo.getList());
			return result;
		} catch (Exception e) {
			// TODO: handle exception
			LayuiResult result=new LayuiResult();
			result.setCode(0);
			result.setCount(null);
			result.setMsg("失败");
			result.setData(e);
			return result;
		}
		//

	}

	public LayuiResult delOneByAdvice(String advid) {
		// TODO Auto-generated method stub
		try {
			Integer n=adviceMapper.deleteByPrimaryKey(Integer.parseInt(advid));
			System.out.println("成功删除:"+n);
			
			return new LayuiResult(0, "成功删除一条记录");
		} catch (Exception e) {
			// TODO: handle exception
			return new LayuiResult(500, ""+e);
		}
		
	}

	public LayuiResult delDataByAdvieForOne(String adviceStr) {
		// TODO Auto-generated method stub
		try {
			String[] ids = adviceStr.split(",");
			Integer n=0;
			if(ids!=null&&ids.length>0){
				for (String advid : ids) {
					
				n=	adviceMapper.deleteByPrimaryKey(Integer.parseInt(advid));
				}
				System.out.println("成功批量删除数据"+n);
			}
			return new LayuiResult(0, "成功批量删除数据");
		} catch (Exception e) {
			// TODO: handle exception
			return new LayuiResult(500, "批量删除数据失败");
		}
		
		
	}

	public DbAdvice selAdviceDataById(String advid) {
		// TODO Auto-generated method stub
		
		return adviceMapper.selectByPrimaryKey(Integer.parseInt(advid));
	}

	public LayuiResult AddAdvice(DbAdvice advice) {
		// TODO Auto-generated method stub
		try {
			advice.setUpdatetime(new Date());
		Integer n=	adviceMapper.insert(advice);
		System.out.println("成功添加记录:"+n);
			return new LayuiResult(0, "成功添加记录");
		} catch (Exception e) {
			// TODO: handle exception
			return new LayuiResult(500, "记录添加失败");
		}
	
	}

	public LayuiResult UpdateAdvice(DbAdvice advice) {
		// TODO Auto-generated method stub
		try {
			advice.setUpdatetime(new Date());
	Integer n=		adviceMapper.updateByPrimaryKey(advice);
	System.out.println("成功修改:"+n);
			return new LayuiResult(0, "成功修改记录");
		} catch (Exception e) {
			// TODO: handle exception
			return new LayuiResult(500, "修改记录失败");
		}
		
	}

}
