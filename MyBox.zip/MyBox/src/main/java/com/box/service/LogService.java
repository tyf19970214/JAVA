package com.box.service;

import java.util.Date;

import com.box.entity.DbLog;
import com.box.utils.LayuiResult;

public interface LogService {
	
	//添加日志
	public LayuiResult insertLof(DbLog log);
	
	
	//获取日志列表
	public LayuiResult selLogList(Integer page,Integer limit);
	
	
	//清除指定日期日志
	public Integer delLogsByDate(Date date);

}
