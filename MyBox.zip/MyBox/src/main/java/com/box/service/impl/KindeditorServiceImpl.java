package com.box.service.impl;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.box.service.KindeditorPicService;
import com.box.utils.FastDFSClient;
import com.box.utils.PictureResult;
import com.box.utils.SessionUtils;



/**
*<p>Title:KindeditorServiceImpl.java</p>
*<p>Description:kindeditor上传图片组件</p>
*<p>Company:www.99weixinxcx.cn</p>
*@author 陕西电子科技学院:滕一帆
*@date	2019年4月22日上午12:26:47
*@version 1.0
*
*
*
 */
@Service
public class KindeditorServiceImpl implements KindeditorPicService {
	
	@Value("${IMAGE_SERVER_BASE_URL}")
	private String IMAGE_SERVER_BASE_URL;

	public PictureResult uploadPic(MultipartFile uploadFile) throws Exception {
		try {
            // 首先接收页面上传的文件
            byte[] content = uploadFile.getBytes();
            // 取出文件的扩展名
            String originalFilename = uploadFile.getOriginalFilename();
            String ext = originalFilename.substring(originalFilename.lastIndexOf(".") + 1);
            // 把这个文件内容上传到图片服务器/src/main/resources/properties/client.conf
          //  FastDFSClient fastDFSClient = new FastDFSClient("F:\\Users\\tyf19\\Workspaces\\MyEclipse Professional 2014\\taotao-manager\\taotao-manager-web\\src\\main\\resources\\properties\\client.conf");
            FastDFSClient fastDFSClient = new FastDFSClient("classpath:resource/config.conf");
            String url = fastDFSClient.uploadFile(content, ext);
            // 从配置文件中取图片服务器的url
            // 创建返回结果对象
         String src=   IMAGE_SERVER_BASE_URL+url;
            PictureResult result=new PictureResult();
            result.setError(0);
            result.setUrl(src);
            SessionUtils.setSessionAttribute("src", src);
          System.out.println(result.getUrl()+"..............图片地址:.....");
            // 返回结果
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            PictureResult result=new PictureResult();
            result.setError( 1);
            result.setMessage( "图片上传失败");
            return result;
        }
	}

}
