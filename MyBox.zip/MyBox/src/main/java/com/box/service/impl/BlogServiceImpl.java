package com.box.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.box.entity.BlogSearch;
import com.box.entity.DbBlog;
import com.box.entity.DbBlogExample;
import com.box.entity.DbBlogExample.Criteria;
import com.box.mapper.DbBlogMapper;
import com.box.service.BlogService;
import com.box.utils.LayuiResult;
import com.box.utils.MyUtil;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

@Service
public class BlogServiceImpl implements BlogService {
	
	@Autowired
	private DbBlogMapper BlogMapper;

	public LayuiResult selBlogList(Integer page, Integer limit,
			BlogSearch search) {
		// TODO Auto-generated method stub
		try {
			//分页插件
			PageHelper.startPage(page, limit);
			//添加查询
			DbBlogExample example=new DbBlogExample();
			example.setOrderByClause("leaseDaet desc");
			Criteria criteria = example.createCriteria();
			if(search.getTitle()!=null&&!search.getTitle().equals("")){
				criteria.andTitleLike("%"+search.getTitle()+"%");
				
			}
			if(search.getContent()!=null&&!search.getContent().equals("")){
				criteria.andContentLike("%"+search.getContent()+"%");
			}
			if(search.getKeyword()!=null&&!search.getKeyword().equals("")){
				criteria.andKeywordLike("%"+search.getKeyword()+"%");
			}
			if(search.getSummary()!=null&&!search.getSummary().equals("")){
				
				criteria.andSummaryLike("%"+search.getSummary()+"%");
				
			}
			if(search.getUppid()!=null&&!search.getUppid().equals("-1")){
				Integer uppid=Integer.parseInt(search.getUppid());
				criteria.andUppidEqualTo(uppid);
			}
			if(search.getCreateTimeStart()!=null&&!search.getCreateTimeStart().equals("")){
				criteria.andLeasedaetGreaterThanOrEqualTo(MyUtil.getDateByString(search.getCreateTimeStart()));
			}
			if(search.getCreateTimeEnd()!=null&&!search.getCreateTimeEnd().equals("")){
				
				criteria.andLeasedaetLessThanOrEqualTo(MyUtil.getDateByString(search.getCreateTimeEnd()));
			}
			List<DbBlog> list = BlogMapper.selectByExample(example);
			PageInfo<DbBlog> pageinfo=new PageInfo<DbBlog>(list);
			LayuiResult result=new LayuiResult();
			result.setCode(0);
			result.setMsg("获取博客列表成功");
			result.setCount(pageinfo.getTotal());
			result.setData(pageinfo.getList());
			
			return result;
		} catch (Exception e) {
			LayuiResult result=new LayuiResult();
			result.setCode(0);
			result.setMsg("获取博客列表失败");
			result.setCount(null);
			result.setData(e);
			
			return result;
		}
		
	}

	public Integer delBlogById(Integer id) {
		// TODO Auto-generated method stub
		return BlogMapper.deleteByPrimaryKey(id);
	}

	public Integer delBlogByMany(String BlogStr) {
		// TODO Auto-generated method stub
		String[] ids = BlogStr.split(",");
		Integer n=0;
		if(ids.length>0&&ids!=null){
			for (String id : ids) {
			n=	BlogMapper.deleteByPrimaryKey(Integer.parseInt(id));
			}
		}
		System.out.println("成功批量删除:"+n);
		
		return n;
	}

	public DbBlog selBlogById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	public Integer InsertBlog(DbBlog blog) {
		// TODO Auto-generated method stub
		return null;
	}

	public Integer UpdateBlog(DbBlog blog) {
		// TODO Auto-generated method stub
		return null;
	}

	public DbBlog selBlogByType(Integer typeid) {
		// TODO Auto-generated method stub
		return null;
	}

}
