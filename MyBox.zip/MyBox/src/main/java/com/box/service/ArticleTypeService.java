package com.box.service;

import java.util.List;

import com.box.entity.DbArticletype;
import com.box.utils.LayuiResult;

public interface ArticleTypeService {
	
	List<DbArticletype> getArticleTypeList();
	
	DbArticletype selArticleById(Integer artypeid);
	//获取文章类型列表
	public LayuiResult selArticleTypeList(Integer page,Integer limit);
	//添加文章类型
	public LayuiResult insertArticleType(DbArticletype type);
	//文章类型单个删除
	public LayuiResult delTypeById(Integer id);
	//文章类型批量删除
	public Integer delArticletypeAll(String articletypeStr);
	//根据id查询文章类型
	public DbArticletype getTypeItem(String id);
	//更新文章类型
	public LayuiResult updeArticleType(DbArticletype articleType);

}
