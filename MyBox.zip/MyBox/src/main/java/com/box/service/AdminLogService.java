package com.box.service;

import com.box.utils.LayuiResult;

public interface AdminLogService {
	
	//查询列表
	public LayuiResult getAdminLogList(Integer page,Integer limit);
	//单个删除日志列表
	public LayuiResult delLogByid(String id);
	//批量删除日志记录
	public LayuiResult deladminlogAll(String adminlogStr);

}
