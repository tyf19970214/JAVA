package com.box.service;

import org.springframework.web.multipart.MultipartFile;

import com.box.utils.PictureUtils;



public interface PicUploadService {
	
	PictureUtils uploadPic(MultipartFile pic) throws Exception;

}
