package com.box.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.box.entity.DbWeb;
import com.box.entity.DbWebExample;
import com.box.mapper.DbWebMapper;
import com.box.service.WebService;
import com.box.utils.LayuiResult;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
/**
 * @author 网站设置业务
 *
 */
@Service
public class WebServiceImpl implements WebService {
	
	@Autowired
	private DbWebMapper webMapper;

	public LayuiResult updateWeb(DbWeb web) {
		try {
			int insert = webMapper.insert(web);
			System.out.println(insert+"...................成功添加一条网站记录");
			return new LayuiResult(0,"成功添加一条数据");
		} catch (Exception e) {
		
			return new LayuiResult(500, "添加网站信息错误"+e);
		}
		
	}

	public LayuiResult upsetWeb(DbWeb web) {
		// TODO Auto-generated method stub
		try {
		Integer n=	webMapper.updateByPrimaryKey(web);
		System.out.println("成功修改了"+n+"条记录");
		return new LayuiResult(0, "成功修改网站信息");
		} catch (Exception e) {
			// TODO: handle exception
			return new LayuiResult(500, "修改网站信息错误"+e);
		}

	}

	public DbWeb selDbWeb(String id) {
		// TODO Auto-generated method stub
		DbWeb web = webMapper.selectByPrimaryKey(Integer.parseInt(id));
		
		return web;
	}

	public LayuiResult selDbWebList(Integer page, Integer limit) {
		// TODO Auto-generated method stub
		try {
			PageHelper.startPage(page,limit);
			DbWebExample example=new DbWebExample();
			List<DbWeb> list = webMapper.selectByExample(example);
			PageInfo<DbWeb> pageinfo=new PageInfo<DbWeb>(list);
			LayuiResult result=new LayuiResult();
			result.setCode(0);
			result.setCount(pageinfo.getTotal());
			result.setMsg("成功 获取网站信息列表");
			result.setData(pageinfo.getList());
			return result;

		} catch (Exception e) {
			// TODO: handle exception
			LayuiResult result=new LayuiResult();
			result.setCode(0);
			result.setCount(null);
			result.setMsg("失败");
			result.setData(null);
			return result;
		}
		
	}

	public LayuiResult delWebByWid(String wid) {
		// TODO Auto-generated method stub
		try {
			System.out.println("接收到了id:"+wid);
			int n = webMapper.deleteByPrimaryKey(Integer.parseInt(wid));
			System.out.println("成功删除了一条网站信息记录:"+n);
			return new LayuiResult(0, "删除网站信息记录成功");
			
		} catch (Exception e) {
			// TODO: handle exception
			return new LayuiResult(500, ""+e);
		}
		
	}

	public LayuiResult delWebAllWid(String webStr) {
		// TODO Auto-generated method stub
		try {
			String[] ids = webStr.split(",");
			Integer n=0;
			if(ids!=null&&ids.length>0){
				for (String wid : ids) {
					n=webMapper.deleteByPrimaryKey(Integer.parseInt(wid));
					
				}
				
				System.out.println("成功批量删除了"+n+"条记录");
			}
			return new LayuiResult(0, "成功批量删除了"+n+"记录");
		
		} catch (Exception e) {
			// TODO: handle exception
			return new LayuiResult(500, "批量删除失败"+e);
		}
		
	}

	public DbWeb selWebByOne(Integer id) {
		// TODO Auto-generated method stub
		
		
		return webMapper.selectByPrimaryKey(id);
	}

}
