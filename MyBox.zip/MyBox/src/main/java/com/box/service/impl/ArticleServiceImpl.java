package com.box.service.impl;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.jdbc.SQL;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.box.entity.ArticleSearch;
import com.box.entity.DbArticle;
import com.box.entity.DbArticleExample;
import com.box.entity.DbArticleExample.Criteria;
import com.box.entity.DbArticletype;
import com.box.entity.DbUserAndDbArticleResultAndDbArticleType;
import com.box.entity.DbUsers;
import com.box.entity.QueryType;
import com.box.entity.ViewSearch;
import com.box.entity.isViewSearch;
import com.box.mapper.DbArticleMapper;
import com.box.mapper.DbArticletypeMapper;
import com.box.mapper.DbUserAndDbArticleResultAndDbArticleTypeMapper;
import com.box.mapper.DbUsersMapper;
import com.box.service.ArticleService;
import com.box.utils.LayuiResult;
import com.box.utils.MyUtil;
import com.box.utils.ResponseResult;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

@Service
public class ArticleServiceImpl implements ArticleService {

	
	
	@Autowired
	private DbArticleMapper articleMapper;	
	
	//获取文章模糊查询列表
	public LayuiResult selArticleList(Integer page, Integer limit,
			ArticleSearch search) {
		
		try {
			
			//分页
			PageHelper.startPage(page,limit);
			DbArticleExample example=new DbArticleExample();
			 example.setOrderByClause("arcreatetime DESC");
			Criteria createCriteria = example.createCriteria();
			if(search.getArtitle()!=null&&!search.getArtitle().equals("")){
				//注意：模糊查询需要进行拼接”%“  如下，不进行拼接是不能完成查询的哦。
				createCriteria.andArtitleLike("%"+search.getArtitle()+"%");
				
			}
			if(search.getArcontent()!=null&&!search.getArcontent().equals("")){
				createCriteria.andArcontentLike("%"+search.getArcontent()+"%");
			}
			if(search.getSimpledes()!=null&&!search.getSimpledes().equals("")){
				createCriteria.andSimpledesLike("%"+search.getSimpledes()+"%");
			}
			if(search.getIsView()!=null&&!"-1".equals(search.getIsView())){
				Integer isView = Integer.parseInt(search.getIsView());
				createCriteria.andIsviewEqualTo(isView);
				
			}
			if(search.getUid()!=null&&!"-1".equals(search.getUid())){
				Integer uid=Integer.parseInt(search.getUid());
				createCriteria.andUidEqualTo(uid);
			}
			if(search.getArtypeid()!=null&&!"-1".equals(search.getArtypeid())){
				Integer id=Integer.parseInt(search.getArtypeid());
				createCriteria.andArtypeidEqualTo(id);
			}
			if(search.getCreateTimeStart()!=null&&!"".equals(search.getCreateTimeStart())){
				createCriteria.andArcreatetimeGreaterThanOrEqualTo(MyUtil.getDateByString(search.getCreateTimeStart()));
			}
			if(search.getCreateTimeEnd()!=null&&!"".equals(search.getCreateTimeEnd())){
			createCriteria.andArcreatetimeLessThanOrEqualTo(MyUtil.getDateByString(search.getCreateTimeEnd()));
			}
			List<DbArticle> list = articleMapper.selectByExample(example);
			PageInfo<DbArticle> pageinfo=new PageInfo<DbArticle>(list);
			LayuiResult result=new LayuiResult ();
			result.setCode(0);
			result.setCount(pageinfo.getTotal());
			result.setMsg("success");
			result.setData(pageinfo.getList());
			return result;
			
		} catch (Exception e) {
			// TODO: handle exception
			LayuiResult result=new LayuiResult();
			result.setCode(1);
			result.setMsg("fail");
			result.setCount(null);
			result.setData(e);
			return result;
		}
		
		
		
	}
	//待审核未审核列表
	public LayuiResult selArticleListByNotIsView(Integer page, Integer limit,
			isViewSearch search) {
try {
			
			//分页
			PageHelper.startPage(page,limit);
			DbArticleExample example=new DbArticleExample();
			 example.setOrderByClause("isView DESC");
			Criteria createCriteria = example.createCriteria();
			if(search.getArtitle()!=null&&!search.getArtitle().equals("")){
				//注意：模糊查询需要进行拼接”%“  如下，不进行拼接是不能完成查询的哦。
				createCriteria.andArtitleLike("%"+search.getArtitle()+"%");
				
			}
			if(search.getArcontent()!=null&&!search.getArcontent().equals("")){
				createCriteria.andArcontentLike("%"+search.getArcontent()+"%");
			}
			if(search.getSimpledes()!=null&&!search.getSimpledes().equals("")){
				createCriteria.andSimpledesLike("%"+search.getSimpledes()+"%");
			}
			if(search.getIsView()!=null&&!"-1".equals(search.getIsView())){
				Integer isView = Integer.parseInt(search.getIsView());
				createCriteria.andIsviewEqualTo(isView);
				
			}
			if(search.getUid()!=null&&!"-1".equals(search.getUid())){
				Integer uid=Integer.parseInt(search.getUid());
				createCriteria.andUidEqualTo(uid);
			}
			if(search.getArtypeid()!=null&&!"-1".equals(search.getArtypeid())){
				Integer id=Integer.parseInt(search.getArtypeid());
				createCriteria.andArtypeidEqualTo(id);
			}
			if(search.getCreateTimeStart()!=null&&!"".equals(search.getCreateTimeStart())){
				createCriteria.andArcreatetimeGreaterThanOrEqualTo(MyUtil.getDateByString(search.getCreateTimeStart()));
			}
			if(search.getCreateTimeEnd()!=null&&!"".equals(search.getCreateTimeEnd())){
			createCriteria.andArcreatetimeLessThanOrEqualTo(MyUtil.getDateByString(search.getCreateTimeEnd()));
			}
			
			List<DbArticle> list = articleMapper.selectByExample(example);
			PageInfo<DbArticle> pageinfo=new PageInfo<DbArticle>(list);
			LayuiResult result=new LayuiResult ();
			result.setCode(0);
			result.setCount(pageinfo.getTotal());
			result.setMsg("success");
			result.setData(pageinfo.getList());
			return result;
			
		} catch (Exception e) {
			// TODO: handle exception
			LayuiResult result=new LayuiResult();
			result.setCode(1);
			result.setMsg("fail");
			result.setCount(null);
			result.setData(e);
			return result;
		}
		
		
		
	}

	
	

	public Integer delArticleById(String arid) {
		// TODO Auto-generated method stub
		Integer n=0;
		try {
		n=	articleMapper.deleteByPrimaryKey(Integer.parseInt(arid));
		System.out.println("成功删除文章记录"+n+"条");
			return n;
		} catch (Exception e) {
			// TODO: handle exception
			return n;
		}
		
	}

	public DbArticle selArticleById(String arid) {
		// TODO Auto-generated method stub
		DbArticle article  = articleMapper.selectByPrimaryKey(Integer.parseInt(arid));
		
		return article;
	}

	public Integer updArticleByStringArticle(DbArticle article) {
		// TODO Auto-generated method stub
		Integer n=0;
		
		try {
			
			article.setUpdatetime(new Date());
			article.setArcreatetime(new Date());
		n=	articleMapper.updateByPrimaryKey(article);
		return n;
		} catch (Exception e) {
			// TODO: handle exception
			return n;
		}
		
		
		
		
		
	}

	public Integer delArticleService(String articleStr) {
		// TODO Auto-generated method stub
		String [] ids=articleStr.split(",");
		Integer n=0;
		if(ids!=null&&ids.length>0){
			for (String arid : ids) {
			n=	articleMapper.deleteByPrimaryKey(Integer.parseInt(arid));
			}
		}
		System.out.println("成功批量删除文章的"+n+"条记录");
		return n;
	}

	public Integer insertArticle(DbArticle article) {
		// TODO Auto-generated method stub
		article.setArcreatetime(new Date());
		article.setUpdatetime(new Date());
		int n = articleMapper.insert(article);
		System.out.println("成功添加了文章记录:"+n);
		return n;
	}
	public LayuiResult updArticleByIsView(String arid) {
		// TODO Auto-generated method stub
		Integer n=3;
		try {
			DbArticle article= articleMapper.selectByPrimaryKey(Integer.parseInt(arid));		
			article.setIsview(1);
			 n = articleMapper.updateByPrimaryKeySelective(article);
			 return  LayuiResult.ok();
		} catch (Exception e) {
			// TODO: handle exception
			
			return new LayuiResult(500, "审核出错");
		}
	
		
		
	
	}
	public LayuiResult delArticleByIsView(String arid) {
		// TODO Auto-generated method stub
		
		try {
			DbArticle article = articleMapper.selectByPrimaryKey(Integer.parseInt(arid));			
		

				Integer n=articleMapper.deleteByPrimaryKey(Integer.parseInt(arid));
			
				return LayuiResult.ok();
			


		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return new LayuiResult(500, "单个删除失败");
		}
	
		
	}
	public Integer delArticleByIsViewByAll(String articleStr) {
		// TODO Auto-generated method stub
				String [] ids=articleStr.split(",");
				Integer n=0;
				if(ids!=null&&ids.length>0){
					for (String arid : ids) {
						Integer id = Integer.parseInt(arid);
				
							n=	articleMapper.deleteByPrimaryKey(id);
				
					
					}
				}
				System.out.println("成功批量删除文章的"+n+"条记录");
				return n;
	}
	public LayuiResult selArticleListByIsView(Integer page, Integer limit,
			ViewSearch search) {
try {
			
			//分页
			PageHelper.startPage(page,limit);
			DbArticleExample example=new DbArticleExample();
			 example.setOrderByClause("isView DESC");
			Criteria createCriteria = example.createCriteria();
			if(search.getArtitle()!=null&&!search.getArtitle().equals("")){
				//注意：模糊查询需要进行拼接”%“  如下，不进行拼接是不能完成查询的哦。
				createCriteria.andArtitleLike("%"+search.getArtitle()+"%");
				
			}
			if(search.getArcontent()!=null&&!search.getArcontent().equals("")){
				createCriteria.andArcontentLike("%"+search.getArcontent()+"%");
			}
			if(search.getSimpledes()!=null&&!search.getSimpledes().equals("")){
				createCriteria.andSimpledesLike("%"+search.getSimpledes()+"%");
			}
			if(search.getIsView()!=null&&!"-1".equals(search.getIsView())){
				Integer isView = Integer.parseInt(search.getIsView());
				createCriteria.andIsviewEqualTo(isView);
				
			}
			if(search.getUid()!=null&&!"-1".equals(search.getUid())){
				Integer uid=Integer.parseInt(search.getUid());
				createCriteria.andUidEqualTo(uid);
			}
			if(search.getArtypeid()!=null&&!"-1".equals(search.getArtypeid())){
				Integer id=Integer.parseInt(search.getArtypeid());
				createCriteria.andArtypeidEqualTo(id);
			}
			if(search.getCreateTimeStart()!=null&&!"".equals(search.getCreateTimeStart())){
				createCriteria.andArcreatetimeGreaterThanOrEqualTo(MyUtil.getDateByString(search.getCreateTimeStart()));
			}
			if(search.getCreateTimeEnd()!=null&&!"".equals(search.getCreateTimeEnd())){
			createCriteria.andArcreatetimeLessThanOrEqualTo(MyUtil.getDateByString(search.getCreateTimeEnd()));
			}
			
			List<DbArticle> list = articleMapper.selectByExample(example);
			PageInfo<DbArticle> pageinfo=new PageInfo<DbArticle>(list);
			LayuiResult result=new LayuiResult ();
			result.setCode(0);
			result.setCount(pageinfo.getTotal());
			result.setMsg("success");
			result.setData(pageinfo.getList());
			return result;
			
		} catch (Exception e) {
			// TODO: handle exception
			LayuiResult result=new LayuiResult();
			result.setCode(1);
			result.setMsg("fail");
			result.setCount(null);
			result.setData(e);
			return result;
		}
		
		
	}
	public LayuiResult updArticleByNotIsView(String arid) {
		// TODO Auto-generated method stub
				Integer n=3;
				try {
					DbArticle article= articleMapper.selectByPrimaryKey(Integer.parseInt(arid));				
					article.setIsview(0);
					 n = articleMapper.updateByPrimaryKeySelective(article);
					 return  LayuiResult.ok();
				} catch (Exception e) {
					// TODO: handle exception
					
					return new LayuiResult(500, "审核出错");
				}
			
	}



	


}
