package com.box.service;

import com.box.entity.DbUsers;


public interface AccountService {
	
	//根据ecode和status查询用户
	public DbUsers selUserByCodeAndStatus(String eCode,String status);
	
	//更新用户状态
	public Integer updUserStatus(DbUsers users);

}
