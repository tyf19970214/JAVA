package com.box.service;



import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.box.entity.DbAdmin;
import com.box.entity.DbAdminlog;
import com.box.entity.DbRoles;
import com.box.entity.Menu;
import com.box.entity.ResultAdminLog;
import com.box.utils.LayuiResult;
import com.box.utils.ResponseResult;


public interface AdminService {
	
	List<DbAdmin> login(String username,String password) ;
	

	
	ResponseResult register(DbAdmin admin);
	
	DbAdmin getDbAdminItems();	

	
	ResponseResult addUser(DbAdmin admin);
	
	//退出登录，清楚cookie，跳转登录界面
	ResponseResult LogOut();
	
	//登录同时插入管理员日志
	ResponseResult insertLogByAdmin();
	
	List<ResultAdminLog> selectByAdminlog();
	
	//查询管理员列表
	List<DbAdmin> getDbAdmin();
	
	DbAdmin selAdminById(Integer id);
	
	DbAdmin selAdminByUserName(String username);
	

	
	
	

}
