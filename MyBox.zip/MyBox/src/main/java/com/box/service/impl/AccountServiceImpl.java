package com.box.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.box.entity.DbUsers;
import com.box.entity.DbUsersExample;
import com.box.entity.DbUsersExample.Criteria;
import com.box.mapper.DbUsersMapper;
import com.box.service.AccountService;
@Service
public class AccountServiceImpl implements AccountService {
	@Autowired
	private DbUsersMapper usersMapper;

	public DbUsers selUserByCodeAndStatus(String eCode, String status) {
		// TODO Auto-generated method stub
		DbUsersExample example=new DbUsersExample ();
		Criteria createCriteria = example.createCriteria();
		createCriteria .andECodeEqualTo(eCode);
		Integer stuts=Integer.parseInt(status);
		createCriteria.andStatusEqualTo(stuts);
		List<DbUsers> list = usersMapper.selectByExample(example);
		if(list!=null&&list.size()>0){
			
			return list.get(0);
		}
		return null;
	}

	public Integer updUserStatus(DbUsers users) {
		// TODO Auto-generated method stub
		int n = usersMapper.updateByPrimaryKey(users);
		return n;
	}

}
