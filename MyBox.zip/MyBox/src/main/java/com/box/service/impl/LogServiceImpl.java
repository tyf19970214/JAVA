package com.box.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.box.entity.DbLog;
import com.box.entity.DbLogExample;
import com.box.entity.DbLogExample.Criteria;
import com.box.mapper.DbLogMapper;
import com.box.service.LogService;
import com.box.utils.LayuiResult;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

@Service
public class LogServiceImpl implements LogService {

	@Autowired
	private DbLogMapper logMapper;
	
	
	public LayuiResult insertLof(DbLog log) {
		// TODO Auto-generated method stub
		try {
			logMapper.insert(log);
			return new LayuiResult(0, "没问题，添加成功");
		} catch (Exception e) {
			// TODO: handle exception
			return new LayuiResult(500, "有问题");
		}

	}

	public LayuiResult selLogList(Integer page, Integer limit) {
		// TODO Auto-generated method stub
		try {
			PageHelper.startPage(page, limit);
			DbLogExample example=new DbLogExample();
			example.setOrderByClause("create_time DESC");
			List<DbLog> logs = logMapper.selectByExample(example);
			PageInfo<DbLog> pageinfo=new PageInfo<DbLog>();
			LayuiResult result=new LayuiResult();
			result.setCode(0);
			result.setCount(pageinfo.getTotal());
			result.setMsg("获取日志列表成功");
			result.setData(pageinfo.getList());
			return result;
		} catch (Exception e) {
			LayuiResult result=new LayuiResult();
			result.setCode(0);
			result.setCount(null);
			result.setMsg("获取日志列表失败");
			result.setData(e);
			return result;
		}

	}

	public Integer delLogsByDate(Date date) {
		// TODO Auto-generated method stub
	
			DbLogExample example = new DbLogExample();
			Criteria createCriteria = example.createCriteria();
			createCriteria.andCreateTimeLessThanOrEqualTo(date);
			int n = logMapper.deleteByExample(example);
			return n;
	
	
				

	}

}
