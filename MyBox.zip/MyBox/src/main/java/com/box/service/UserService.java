package com.box.service;

import java.util.List;

import com.box.entity.DbUsers;
import com.box.entity.UserSearch;
import com.box.utils.LayuiResult;




public interface UserService {
	
	//获取用户信息
	public LayuiResult selUsers(Integer page, Integer limit,UserSearch search);
	
	//检验昵称是否一致
	public DbUsers checkUserByNickname(String nickname,Long uid) throws Exception;

	//检验邮箱是否可用
	public DbUsers checkUserByEmail(String email,Long uid) throws Exception;
	
	//添加用户
	public Integer insertUserBySerliaze(DbUsers users) throws Exception;
	
	//检测用户名是否可用
	public DbUsers checkUserByUserName(String username,Long uid) throws Exception;
	
	//获取用户列表
	public List<DbUsers> getUserList();
	
	//根据id删除用户记录
	public Integer delUserById(String uid);
	
	//根据id查询用户
	public DbUsers selUserById(Long uid);
	
	//更新用户信息
	public Integer updUserService(DbUsers users);
	
	//批量删除用户
	public Integer delUsersService(String userStr);
	
	
}
