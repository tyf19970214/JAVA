package com.box.service;

import com.box.entity.AdviceSearch;
import com.box.entity.DbAdvice;
import com.box.utils.LayuiResult;

public interface AdviceService {
	//查询列表带模糊搜索
	public LayuiResult selAdviceBySearch(Integer page,Integer limit,AdviceSearch search);
	//单个删除
	public LayuiResult delOneByAdvice(String advid);
	//批量删除
	public LayuiResult delDataByAdvieForOne(String adviceStr);
	//根据id查询数据
	public DbAdvice selAdviceDataById(String advid);
	//添加数据
	public LayuiResult AddAdvice(DbAdvice advice);
	//修改数据
	public LayuiResult UpdateAdvice(DbAdvice advice);
}
