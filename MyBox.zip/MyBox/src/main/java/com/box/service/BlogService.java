package com.box.service;

import com.box.entity.BlogSearch;
import com.box.entity.DbBlog;
import com.box.utils.LayuiResult;

public interface BlogService {
	
	//获取博客列表
	public LayuiResult selBlogList(Integer page,Integer limit,BlogSearch search);
	
	//删除单个记录
	public Integer delBlogById(Integer id);
	
	//批量删除
	public Integer delBlogByMany(String BlogStr);
	
	//通过ID查询博客记录
	public DbBlog selBlogById(Integer id);
	
	//添加博客记录
	public Integer InsertBlog(DbBlog blog);
	
	//修改博客记录
	public Integer UpdateBlog(DbBlog blog);
	
	//根据博客类型ID查询博客记录
	public DbBlog selBlogByType(Integer typeid);

}
