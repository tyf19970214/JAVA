package com.box.service;

import com.box.entity.DbWeb;
import com.box.utils.LayuiResult;

public interface WebService {
	//添加
	public LayuiResult updateWeb(DbWeb web);

	//修改网站信息
	public LayuiResult upsetWeb(DbWeb web);
	
	//根据id查询对象
	public DbWeb selDbWeb(String id);
	
	//根据分页查询网站信息列表
	public LayuiResult selDbWebList(Integer page,Integer limit);
	
	//单个删除
	public LayuiResult delWebByWid(String wid);
	
	//批量删除
	public LayuiResult delWebAllWid(String webStr);
	
	//查询单个
	public DbWeb selWebByOne(Integer id);

}
