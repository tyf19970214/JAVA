package com.box.service;


import com.box.utils.LayuiResult;


public interface RolesService {
	//获取所有角色
		public LayuiResult selRoles(Integer page,Integer limit);
		
		//单个删除
		public LayuiResult delRolesById(Long roleId);
		
		//批量删除
		public LayuiResult delRolesByAll(String roleStr);
}
