package com.box.service;

import com.box.entity.ArticleSearch;
import com.box.entity.DbArticle;
import com.box.entity.ViewSearch;
import com.box.entity.isViewSearch;
import com.box.utils.LayuiResult;




public interface ArticleService {
	
	//获取文章列表
	public LayuiResult selArticleList(Integer page,Integer limit,ArticleSearch articleSearch);
	//删除单个文章记录
	public Integer delArticleById(String arid);
	//根据文章id查询单条文章记录
	public DbArticle selArticleById(String arid);
	//更新文章
	public Integer updArticleByStringArticle(DbArticle article);
	//批量删除
	public Integer delArticleService(String articleStr);
	//添加文章
	public Integer insertArticle(DbArticle article);
	//获取文章待审核列表
	public LayuiResult selArticleListByNotIsView(Integer page,Integer limit,isViewSearch articleSearch);
	//获取文章已审核列表
	public LayuiResult selArticleListByIsView(Integer page,Integer limit,ViewSearch articleSearch);
	//更新审核
	public LayuiResult updArticleByIsView(String arid);
	//待审核表单个删除
	public LayuiResult delArticleByIsView(String arid);
	//待审核表批量删除
	public Integer delArticleByIsViewByAll(String articleStr);
	//驳回
	public LayuiResult updArticleByNotIsView(String arid);
	



}
