package com.box.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.box.entity.DbLink;
import com.box.entity.DbLinkExample;
import com.box.mapper.DbLinkMapper;
import com.box.service.LinkService;
import com.box.utils.LayuiResult;
import com.box.utils.ResponseResult;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;


/**
 * @author 友情链接业务逻辑
 *
 */

@Service
public class LinkServiceImpl implements LinkService {
	
	@Autowired
	private DbLinkMapper linkMapper;

	public LayuiResult getLinkList(Integer page, Integer limit) {
		// TODO Auto-generated method stub
		try {
			PageHelper.startPage(page, limit);
			DbLinkExample example=new DbLinkExample();
			List<DbLink> list = linkMapper.selectByExample(example);
			PageInfo<DbLink> pageinfo=new PageInfo<DbLink>(list);
			LayuiResult result=new LayuiResult();
			result.setCode(0);
			result.setCount(pageinfo.getTotal());
			result.setMsg("成功获取友情链接列表");
			result.setData(pageinfo.getList());
			return result;
		} catch (Exception e) {
			LayuiResult result=new LayuiResult();
			result.setCode(0);
			result.setCount(null);
			result.setMsg("获取友情链接列表失败");
			return result;
		}
		
	}

	public LayuiResult delLinkById(String id) {
		// TODO Auto-generated method stub
		try {
			Integer n=linkMapper.deleteByPrimaryKey(Integer.parseInt(id));
			System.out.println("成功删除"+n+"条友情链接记录");
			
			return new LayuiResult(0, "成功删除1条记录");
		} catch (Exception e) {
			// TODO: handle exception
			return new LayuiResult(500, "删除失败");
		}

	}

	public LayuiResult updLinkByLink(DbLink link) {
		// TODO Auto-generated method stub
		try {
			
			Integer n=linkMapper.updateByPrimaryKey(link);
			System.out.println("成功修改"+n+"条友情链接记录");
			
			return new LayuiResult(0, "成功修改1条记录");
		} catch (Exception e) {
			// TODO: handle exception
			return new LayuiResult(500, "修改失败");
		}

	}

	public LayuiResult delLinkByAll(String LinkStr) {
		// TODO Auto-generated method stub
		try {
			String[] ids = LinkStr.split(",");
			Integer n=0;
			if(ids!=null&&ids.length>0){
				
				for (String id : ids) {
					 n = linkMapper.deleteByPrimaryKey(Integer.parseInt(id));
					
				}
				System.out.println("成功批量删除"+n);
			}
			
			return new LayuiResult(0, "成功批量删除1条记录");
		} catch (Exception e) {
			// TODO: handle exception
			return new LayuiResult(500, "批量删除失败");
		}

	}

	public DbLink selLinkByOne(String id) {
		// TODO Auto-generated method stub
		try {
			DbLink link = linkMapper.selectByPrimaryKey(Integer.parseInt(id));
		System.out.println("......................."+link+".......................");
			return link;
		} catch (Exception e) {
			// TODO: handle exception
			return null;
		}
		
	}

	public LayuiResult AddLink(DbLink link) {
		// TODO Auto-generated method stub
		try {
			int n = linkMapper.insert(link);
			System.out.println("成功添加"+n);
			
			
			return new LayuiResult(0, "成功添加"+n+"条记录");
		} catch (Exception e) {
			// TODO: handle exception
			return new LayuiResult(500, "添加失败");
		}

	}

	public List<DbLink> selLinks() {
		// TODO Auto-generated method stub
		DbLinkExample example=new DbLinkExample();
		
		return linkMapper.selectByExample(example);
	}

}
