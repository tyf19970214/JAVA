package com.box.service;

import java.util.List;

import com.box.entity.DbLink;
import com.box.utils.LayuiResult;

public interface LinkService {
	

	//获取友情链接列表
	public LayuiResult getLinkList(Integer page,Integer limit);
	
	//单个删除
	public LayuiResult delLinkById(String id);
	
	//编辑修改
	public LayuiResult updLinkByLink(DbLink link);
	
	//批量删除
	public LayuiResult delLinkByAll(String LinkStr);
	
	//根据id查询单个
	public DbLink selLinkByOne(String id);
	
	//添加
	public LayuiResult AddLink(DbLink link);
	
	//获取所有友情链接
	public List<DbLink> selLinks();

}
