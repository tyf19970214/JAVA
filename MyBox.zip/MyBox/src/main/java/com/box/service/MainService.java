package com.box.service;

import com.box.entity.DbUsers;
import java.util.List;

import org.apache.ibatis.annotations.Select;

public interface MainService {
	
	public List<DbUsers> selUserList(); 
	
	public List<DbUsers> selUsersToday();	
	
	public List<DbUsers> selUsersYesterday();	
	
	public List<DbUsers> selUsersYearWeek();	

	public List<DbUsers> selUsersMonth();
	
	public Integer selUsersCountBySex(Integer i);

}
