package com.box.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.box.entity.DbRoles;
import com.box.entity.DbRolesExample;
import com.box.entity.DbRolesExample.Criteria;
import com.box.mapper.DbRolesMapper;
import com.box.service.RolesService;
import com.box.utils.LayuiResult;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;



/**
 * @author Administrator
 *
 */
@Service
public class RolesServiceImpl implements RolesService {
	
	@Autowired
	private DbRolesMapper rolesMapper;

	public LayuiResult selRoles(Integer page, Integer limit) {
		// TODO Auto-generated method stub
		try {
			PageHelper.startPage(page, limit);
			DbRolesExample example=new DbRolesExample ();
		List<DbRoles> list = rolesMapper.selectByExample(example);
		PageInfo<DbRoles> pageinfo=new PageInfo<DbRoles>(list);
		LayuiResult result=new LayuiResult();
		result.setCode(0);
		result.setCount(pageinfo.getTotal());
		result.setMsg("角色获取成功");
		result.setData(pageinfo.getList());
		return result;
		} catch (Exception e) {
			LayuiResult result=new LayuiResult();
			result.setCode(1);
			result.setCount(null);
			result.setMsg("角色获取失败");
			result.setData(e);
			return result;
		}
	
		

	}

	public LayuiResult delRolesById(Long roleId) {
		// TODO Auto-generated method stub
		try {
			int n= rolesMapper.deleteByPrimaryKey(roleId);
			
			return new LayuiResult(0, "单个删除成功");
		} catch (Exception e) {
			// TODO: handle exception
			return new LayuiResult(500, "单个删除失败");
		}
	
	}

	public LayuiResult delRolesByAll(String roleStr) {
		// TODO Auto-generated method stub
		Integer n=0;
		try {
			String[] ids = roleStr.split(",");
			if(ids!=null&&ids.length>0){
				for (String roleId : ids) {
				n=	rolesMapper.deleteByPrimaryKey(Long.parseLong(roleId));
				}
				System.out.println(n+"========批量删除成功=========");
			}
			
			
			return new LayuiResult(0, "批量删除"+n+"成功");
		} catch (Exception e) {
			// TODO: handle exception
			return new LayuiResult(500, "批量删除失败");
		}
	
	}

}
