package com.box.service;

import java.util.List;

import com.box.entity.DbBtype;
import com.box.utils.LayuiResult;

public interface BlogTypeService {
	
	//查询列表
	public LayuiResult selBlogTypeList(Integer page,Integer limit);
	
	//添加博客类型列表
	public Integer insertBlogType(DbBtype BlogType);
	
	//单个删除
	public Integer delBlogTypeById(Integer tid);
	
	//批量删除
	public Integer delBlogTypeByAll(String BlogTypeStr);
	
	//根据ID查询博客类型
	public DbBtype selBlogTypeById(Integer tid);
	
	//博客类型更新
	public Integer updateBlogType(DbBtype BlogType);
	
	
	//查询列表
	public List<DbBtype> selBlogTypeList();
	

}
