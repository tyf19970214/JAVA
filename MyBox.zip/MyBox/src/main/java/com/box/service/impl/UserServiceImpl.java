package com.box.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;


import com.box.entity.DbUsers;
import com.box.entity.DbUsersExample;
import com.box.entity.DbUsersExample.Criteria;
import com.box.entity.UserSearch;

import com.box.mapper.DbUsersMapper;
import com.box.service.UserService;
import com.box.utils.EmailUtil;
import com.box.utils.LayuiResult;
import com.box.utils.MyUtil;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;



@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private DbUsersMapper usersMapper;

	public LayuiResult selUsers(Integer page, Integer limit, UserSearch search) {
		// TODO Auto-generated method stub
		try {
			
			//分页
			PageHelper.startPage(page, limit);
			DbUsersExample example=new DbUsersExample();
			example.setOrderByClause("lasttime DESC");
			Criteria createCriteria = example.createCriteria();
			if(search.getNickname()!=null&&!"".equals(search.getNickname())){
				//注意：模糊查询需要进行拼接”%“  如下，不进行拼接是不能完成查询的哦。
				createCriteria.andNicknameLike("%"+search.getNickname()+"%");
			}
			if(search.getSex()!=null&&!"-1".equals(search.getSex())){
				createCriteria.andSexEqualTo(search.getSex());
			}
			if(search.getStatus()!=null&&!"-1".equals(search.getStatus())){
				
				Integer status=Integer.parseInt(search.getStatus());
				createCriteria.andStatusEqualTo(status);
			}
			if(search.getCreateTimeStart()!=null&&!"".equals(search.getCreateTimeStart())){
				createCriteria.andLasttimeGreaterThanOrEqualTo(MyUtil.getDateByString(search.getCreateTimeStart()));
			}
			if(search.getCreateTimeEnd()!=null&&!"".equals(search.getCreateTimeEnd())){
			createCriteria.andLasttimeLessThanOrEqualTo(MyUtil.getDateByString(search.getCreateTimeEnd()));
			}
			List<DbUsers> list = usersMapper.selectByExample(example);
			PageInfo<DbUsers> pageinfo=new PageInfo<DbUsers>(list);
			LayuiResult result=new LayuiResult();
			result.setCode(0);
			result.setMsg("success");
			result.setCount(pageinfo.getTotal());
			result.setData(pageinfo.getList());
			return result;
		} catch (Exception e) {
			// TODO: handle exception
			LayuiResult result=new LayuiResult();
			result.setCode(1);
			result.setMsg("fail");
			result.setCount(null);
			result.setData(e);
			return result;
		}
		
		
		
	
	}

	public DbUsers checkUserByNickname(String nickname, Long uid)
			throws Exception {
		// TODO Auto-generated method stub
		//通过用户名和id进行数据库对比，如果存在就是一致
		DbUsersExample example=new DbUsersExample();
		Criteria create = example.createCriteria();
		//先进行用户名比对，再将id拿出来对比
		create.andNicknameEqualTo(nickname);
		if(uid!=null&&!uid.equals("")){
			create.andUidEqualTo(uid);
		}
		List<DbUsers> userlist = usersMapper.selectByExample(example);
		if(userlist!=null&&userlist.size()>0){
			return userlist.get(0);
		}
		
		
		return null;
	}

	public DbUsers checkUserByEmail(String email, Long uid) throws Exception {
		// TODO Auto-generated method stub
		DbUsersExample example=new DbUsersExample();
		Criteria createCriteria = example.createCriteria();
		createCriteria .andEmailEqualTo(email);
		if(uid!=null&&!uid.equals("")){
			createCriteria.andUidEqualTo(uid);
		}
		List<DbUsers> list = usersMapper.selectByExample(example);
		if(list!=null&&list.size()>0){
			return list.get(0);
		}
		return null;
	}

	
	
	public Integer insertUserBySerliaze(DbUsers users) throws Exception {
		// TODO Auto-generated method stub
		users.setPassword(DigestUtils.md5DigestAsHex(users.getPassword().getBytes()));
		String code=MyUtil.getStrUUID();
		users.seteCode(code);
		users.setStatus(0);//0:未激活，1，正常，2，禁用
		Date date=new Date();		
		users.setLasttime(date);
		//发送邮件工具
		EmailUtil.sendMail(users.getEmail(),code);

		int n = usersMapper.insertSelective(users);
		return n;
	}

	public DbUsers checkUserByUserName(String username, Long uid)
			throws Exception {
		// TODO Auto-generated method stub
		DbUsersExample example=new DbUsersExample();
		Criteria createCriteria = example.createCriteria();
		createCriteria.andUsernameEqualTo(username);
		List<DbUsers> list = usersMapper.selectByExample(example);
		if(uid!=null&&!uid.equals("")){
			createCriteria.andUidEqualTo(uid);
		
		}
		if(list!=null&&list.size()>0){
			return list.get(0);
		}
		return null;
	}

	public List<DbUsers> getUserList() {
		// TODO Auto-generated method stub
		DbUsersExample example=new DbUsersExample();
		List<DbUsers> list = usersMapper.selectByExample(example);
		return list;
	}

	public Integer delUserById(String uid) {
		// TODO Auto-generated method stub
		Long id=Long.parseLong(uid);
		int n= usersMapper.deleteByPrimaryKey(id);
		return n;
	}

	public DbUsers selUserById(Long uid) {
		// TODO Auto-generated method stub
		DbUsers users = usersMapper.selectByPrimaryKey(uid);
		
		return users;
	}

	public Integer updUserService(DbUsers users) {
		// TODO Auto-generated method stub
		DbUsers u = usersMapper.selectByPrimaryKey(users.getUid());		
		users.seteCode(u.geteCode());
		users.setPassword(u.getPassword());
		users.setLasttime(u.getLasttime());	
		
	
		
		int n = usersMapper.updateByPrimaryKeySelective(users);
		System.out.println("成功修改用户记录:"+n+"条");
		return n;
	}

	public Integer delUsersService(String userStr) {
		// TODO Auto-generated method stub
		String[] users = userStr.split(",");
		int n =0;
		if(users!=null&&users.length>0){
			for (String uid : users) {
				n= usersMapper.deleteByPrimaryKey(Long.parseLong(uid));
			}
		}
		System.out.println("成功批量删除了"+n+"条记录");
		return n;
	}

}
