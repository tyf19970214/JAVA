package com.box.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.box.entity.DbAdminlog;
import com.box.entity.DbAdminlogExample;
import com.box.mapper.DbAdminlogMapper;
import com.box.service.AdminLogService;
import com.box.utils.LayuiResult;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

/**
 * @author 日志业务逻辑
 *
 */

@Service
public class AdminLogServiceImpl implements AdminLogService {
	
	@Autowired
	private DbAdminlogMapper log;

	public LayuiResult getAdminLogList(Integer page, Integer limit) {
		// TODO Auto-generated method stub
		try {	PageHelper.startPage(page, limit);
		
		DbAdminlogExample example=new DbAdminlogExample();
		List<DbAdminlog> list= log.selectByExample(example);
		PageInfo<DbAdminlog> pageinfo=new PageInfo<DbAdminlog>(list);
		LayuiResult result=new LayuiResult();
		result.setCode(0);
		result.setCount(pageinfo.getTotal());
		result.setMsg("成功获取日志列表");
		result.setData(pageinfo.getList());
			return result;
		} catch (Exception e) {
			// TODO: handle exception
			LayuiResult result=new LayuiResult();
			result.setCode(0);
			result.setCount(null);
			result.setMsg("获取失败"+e);
			result.setData(e);
				return result;
		}
	
		
	}

	public LayuiResult delLogByid(String id) {
		// TODO Auto-generated method stub
		try {
			log.deleteByPrimaryKey(Integer.parseInt(id));
			return new LayuiResult(0, "单个删除成功");
		} catch (Exception e) {
			// TODO: handle exception
			return new LayuiResult(500,"单个删除失败"+e);
		}
		
	}

	public LayuiResult deladminlogAll(String adminlogStr) {
		
		try {
			
			String[] ids = adminlogStr.split(",");
			Integer n=0;
			if(ids!=null&&ids.length>0){
			for (String id : ids) {
			n=	log.deleteByPrimaryKey(Integer.parseInt(id));
				
			}
			System.out.println("成功删除了"+n+"条记录");
			}
			return new LayuiResult(0, "成功批量删除记录");
		} catch (Exception e) {
			// TODO: handle exception
			return new LayuiResult(500, "删除失败");
		}
		
		
	}

}
