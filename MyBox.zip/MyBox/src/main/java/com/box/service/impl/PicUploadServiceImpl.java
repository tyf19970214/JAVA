package com.box.service.impl;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.box.service.PicUploadService;
import com.box.utils.FastDFSClient;
import com.box.utils.PictureUtils;
import com.box.utils.SessionUtils;

/**
*<p>Title:PicUploadServiceImpl.java</p>
*<p>Description:图片文件上传layui</p>
*<p>Company:www.99weixinxcx.cn</p>
*@author 陕西电子科技学院:滕一帆
*@date	2019年4月9日上午2:15:16
*@version 1.0
*
*
*
 */
@Service
public class PicUploadServiceImpl implements PicUploadService {

	@Value("${IMAGE_SERVER_BASE_URL}")
    private String IMAGE_SERVER_BASE_URL;
	
	
	public PictureUtils uploadPic(MultipartFile pic) throws Exception {
		// TODO Auto-generated method stub
		try {

			  // 首先接收页面上传的文件
	        byte[] content = pic.getBytes();
	        // 取出文件的扩展名
	        String originalFilename = pic.getOriginalFilename();
	        String ext = originalFilename.substring(originalFilename.lastIndexOf(".") + 1);
	        // 把这个文件内容上传到图片服务器/src/main/resources/properties/client.conf
	      //  FastDFSClient fastDFSClient = new FastDFSClient("F:\\Users\\tyf19\\Workspaces\\MyEclipse Professional 2014\\taotao-manager\\taotao-manager-web\\src\\main\\resources\\properties\\client.conf");
	        FastDFSClient fastDFSClient = new FastDFSClient("classpath:resource/config.conf");
	        String url = fastDFSClient.uploadFile(content, ext);
	        String src=IMAGE_SERVER_BASE_URL+ url ;
	        Map<String,String> map=new HashMap<String,String>();
	        SessionUtils.setSessionAttribute("imgUrl", src);
	        map.put("src", src);
	        PictureUtils result=new PictureUtils();
	        result.setCode(0);
	        result.setMsg("上传成功");
	        result.setData(map);
	        return result;
		} catch (Exception e) {
			// TODO: handle exception
			PictureUtils result=new PictureUtils();
	        result.setCode(1);
	        result.setMsg("上传失败");
	        result.setData(null);
	        return result;
		}
		
	}

}
