package com.box.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.box.entity.DbAdmin;
import com.box.entity.DbMenus;
import com.box.entity.DbMenusExample;
import com.box.entity.DbRolesMenusExample;
import com.box.entity.DbRolesMenusExample.Criteria;
import com.box.entity.DbRolesMenusKey;
import com.box.entity.Menu;
import com.box.entity.XtreeData;
import com.box.mapper.AdminMenusMapper;
import com.box.mapper.DbMenusMapper;
import com.box.mapper.DbRolesMenusMapper;
import com.box.service.MenuService;





@Service
public class MenuServiceImpl implements MenuService {
	
	@Autowired
	private DbMenusMapper menusMapper;
	
	@Autowired
	private DbRolesMenusMapper rolesMenuMapper;
	
	@Autowired
	private AdminMenusMapper adminMenusMapper;

	public List<Menu> selMenus(DbAdmin admin) {
		// TODO Auto-generated method stub
		List<Menu> results=new ArrayList<Menu>();
		 Long roleId = admin.getRoleId();
		//取出管理员的权限id和权限表的id进行比较
		DbRolesMenusExample example=new DbRolesMenusExample();
		Criteria createCriteria = example.createCriteria();
		createCriteria.andRoleIdEqualTo(roleId);
		List<DbRolesMenusKey> list = rolesMenuMapper.selectByExample(example);
		if(list!=null&list.size()>0){
			List<DbMenus> menus = adminMenusMapper.getMenus(roleId.longValue());
			for (int i = 0; i < menus.size(); i++) {
				if(menus.get(i).getParentId()==0){
					
					Menu menu=new Menu();
					menu.setTitle(menus.get(i).getTitle());
					menu.setIcon(menus.get(i).getIcon());
					menu.setHref(menus.get(i).getHref());
					menu.setSpread(menus.get(i).getSpread());
					List<Menu> menus2 = new ArrayList<Menu>();
					for (int j = 0; j < menus.size(); j++) {
						if (menus.get(j).getParentId() == menus.get(i).getMenuId()) {
							Menu menu2 = new Menu();
							menu2.setTitle(menus.get(j).getTitle());
							menu2.setIcon(menus.get(j).getIcon());
							menu2.setHref(menus.get(j).getHref());
							menu2.setSpread(menus.get(j).getSpread());
							menus2.add(menu2);
						}
					}
					menu.setChildren(menus2);
					results.add(menu);
				}
			}
			
			
		}
		
		
		return results;
	}

	public List<XtreeData> selXtreeData(DbAdmin admin) {
		// TODO Auto-generated method stub
		List<XtreeData> list = new ArrayList<XtreeData>();
		//获取所有权限菜单
		DbMenusExample example=new DbMenusExample();
		com.box.entity.DbMenusExample.Criteria createCriteria = example.createCriteria();
		List<DbMenus> allMenus = menusMapper.selectByExample(example);
		
		
		//获取指定角色的菜单
		List<DbMenus> menus = adminMenusMapper.getMenus(admin.getRoleId().longValue());
		for (DbMenus m : allMenus) {
			if(m.getParentId()==0){
				XtreeData x=new XtreeData();
				x.setTitle(m.getTitle());
				x.setValue(m.getMenuId()+"");
				List<XtreeData> list2 = new ArrayList<XtreeData>();
				
				for (DbMenus m1 : allMenus) {
					
					if(m1.getParentId()==m.getMenuId()){
						XtreeData x1=new XtreeData();
						x1.setTitle(m1.getTitle());
						x1.setValue(m1.getMenuId()+"");
						//是否拥有权限
						x1.setChecked(false);
						for (DbMenus mh :menus) {
							if(mh.getMenuId()==m1.getMenuId()){
								x1.setChecked(true);
								break;
							}
							
						}
						// 使数据data不为null
						List<XtreeData> l = new ArrayList<XtreeData>();
						x1.setData(l);
						list2.add(x1);
						
					}
					
				}
				x.setData(list2);
				list.add(x);
			}
			
		}
		
		
		
		// 拥有没有子节点的节点，设置选中
		for (XtreeData xd : list) {
			if(xd.getData()==null||xd.getData().size()==0){
				for (DbMenus dbMenus : menus) {
					if(dbMenus.getMenuId()==Long.parseLong(xd.getValue())){
						xd.setChecked(true);
						break;
					}
				}
			}
			
		}
		//默认拥有首页权限
		list.get(0).setDisabled(true);
		list.get(0).setChecked(true);
		return list;
	}

	public List<XtreeData> selXtreeData1(DbAdmin admin) {
		List<XtreeData> list = new ArrayList<XtreeData>();
		// 获取所有的权限菜单
		DbMenusExample example = new DbMenusExample();
		com.box.entity.DbMenusExample.Criteria criteria = example.createCriteria();
		List<DbMenus> allMenus =menusMapper.selectByExample(example);
		
		// 获取指定角色的菜单
		List<DbMenus> menus = adminMenusMapper.getMenus(admin.getRoleId().longValue());
		for (DbMenus m : allMenus) {
			if (m.getParentId() == 0) {
				XtreeData x = new XtreeData();
				x.setTitle(m.getTitle());
				x.setValue(m.getMenuId() + "");
				List<XtreeData> list2 = new ArrayList<XtreeData>();
				for (DbMenus m1 : allMenus) {
					if (m1.getParentId() == m.getMenuId()) {
						XtreeData x1 = new XtreeData();
						x1.setTitle(m1.getTitle());
						x1.setValue(m1.getMenuId() + "");
						List<XtreeData> list3 = new ArrayList<XtreeData>();
						for (DbMenus m2 : allMenus) {
							if (m2.getParentId() == m1.getMenuId()) {
								XtreeData x2 = new XtreeData();
								x2.setTitle(m2.getTitle());
								x2.setValue(m2.getMenuId() + "");
								// 是否拥有权限
								x2.setChecked(false);
								for (DbMenus mh : menus) {
									if (mh.getMenuId() == m2.getMenuId()) {
										x2.setChecked(true);
										break;
									}
								}
								// 使数据data不为null
								List<XtreeData> l = new ArrayList<XtreeData>();
								x2.setData(l);
								list3.add(x2);
							}
						}
						
						x1.setData(list3);
						list2.add(x1);
					}
				}
				x.setData(list2);
				list.add(x);
			}
		}
		
		// 拥有没有子节点的节点，设置选中
		for (XtreeData xd : list) {
			if (xd.getData() == null || xd.getData().size() == 0) {
				for (DbMenus tbMenus : menus) {
					if (tbMenus.getMenuId() == Long.parseLong(xd.getValue())) {
						xd.setChecked(true);
					}
				}
			}
		}
		//默认拥有首页菜单权限
		list.get(0).setDisabled(true);
		list.get(0).setChecked(true);
		return list;
	}

	public List<DbMenus> selMenusByParentId() {
		// TODO Auto-generated method stub
		DbMenusExample example=new DbMenusExample();
		 
		return menusMapper.selectByExample(example);
	}

	public DbMenus selMenuById(Long menuId) {
		// TODO Auto-generated method stub
		DbMenusExample example=new DbMenusExample();

		return menusMapper.selectByPrimaryKey(menuId);
	}

	public void insMenu(DbMenus menus) {
		// TODO Auto-generated method stub
		Long menuId = menus.getMenuId();
		if(menuId!=null){
			DbRolesMenusKey rome=new DbRolesMenusKey();
			rome.setMenuId(menuId);
			rolesMenuMapper.insert(rome);
		}
		
		int insert = menusMapper.insert(menus);
		
		
		System.out.println(insert+">>>>>>>>>>>>>>添加菜单");

	}

	public void updMenu(DbMenus menus) {
		// TODO Auto-generated method stub
			Integer n=		menusMapper.updateByPrimaryKey(menus);
			System.out.println("成功修改了"+n);
	}

	public DbMenus selMenuByTitle(String title) {
		DbMenusExample example=new DbMenusExample();
		com.box.entity.DbMenusExample.Criteria criteria = example.createCriteria();
		criteria.andTitleEqualTo(title);
		List<DbMenus> data = menusMapper.selectByExample(example);
		if(data!=null&&data.size()>0){
			return data.get(0);
		}
		return null;
	}

	public DbMenus selMenusById(Long menuId) {
		DbMenusExample example=new DbMenusExample();
		com.box.entity.DbMenusExample.Criteria criteria = example.createCriteria();
		criteria.andMenuIdEqualTo(menuId);
		List<DbMenus> data = menusMapper.selectByExample(example);
		if(data!=null&&data.size()>0){
			return data.get(0);
		}
		return null;
	}

	public void delMenuById(Long menuId) {
		// TODO Auto-generated method stub
menusMapper.deleteByPrimaryKey(menuId);
	}

	public List<DbMenus> selMenusById1(Long menuId) {
		DbMenusExample example=new DbMenusExample();
	 com.box.entity.DbMenusExample.Criteria criteria = example.createCriteria();
		criteria.andParentIdEqualTo(menuId);
		List<DbMenus> data = menusMapper.selectByExample(example);
		return data;
	}

}
