package com.box.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.box.entity.DbBtype;
import com.box.entity.DbBtypeExample;
import com.box.mapper.DbBtypeMapper;
import com.box.service.BlogTypeService;
import com.box.utils.LayuiResult;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;


@Service
public class BlogTypeServiceImpl implements BlogTypeService {

	
	@Autowired
	private DbBtypeMapper BlogTypeMapper;
	public LayuiResult selBlogTypeList(Integer page, Integer limit) {
		// TODO Auto-generated method stub
		try {
			PageHelper.startPage(page, limit);
			DbBtypeExample example=new DbBtypeExample();
			List<DbBtype> list = BlogTypeMapper.selectByExample(example);
			PageInfo<DbBtype> pageinfo=new PageInfo<DbBtype>(list);
			LayuiResult result=new LayuiResult ();
			result.setCode(0);
			result.setMsg("获取博客类型列表成功");
			result.setCount(pageinfo.getTotal());
			result.setData(pageinfo.getList());
			return result;
		} catch (Exception e) {
			// TODO: handle exception
			LayuiResult result=new LayuiResult ();
			result.setCode(500);
			result.setMsg("获取博客类型列表失败");
			result.setCount(null);
			result.setData(e);
			return result;
			
		}
	
		
	}

	public Integer insertBlogType(DbBtype BlogType) {
		// TODO Auto-generated method stub
		return BlogTypeMapper.insert(BlogType);
	}

	public Integer delBlogTypeById(Integer tid) {
		// TODO Auto-generated method stub
		return BlogTypeMapper.deleteByPrimaryKey(tid);
	}

	public Integer delBlogTypeByAll(String BlogTypeStr) {
		// TODO Auto-generated method stub
		String[] ids = BlogTypeStr.split(",");
		Integer n=0;
	if(ids!=null&&ids.length>0){
		for (String tid : ids) {
			
			n = BlogTypeMapper.deleteByPrimaryKey(Integer.parseInt(tid));
		}
		
	}
	System.out.println("成功批量删除"+n);
	
		return n;
	}

	public DbBtype selBlogTypeById(Integer tid) {
		// TODO Auto-generated method stub
		return BlogTypeMapper.selectByPrimaryKey(tid);
	}

	public Integer updateBlogType(DbBtype BlogType) {
		// TODO Auto-generated method stub
	
		return BlogTypeMapper.updateByPrimaryKey(BlogType);
	}

	public List<DbBtype> selBlogTypeList() {
		// TODO Auto-generated method stub
		DbBtypeExample example=new DbBtypeExample();
	
		return 	BlogTypeMapper.selectByExample(example);
	}

}
