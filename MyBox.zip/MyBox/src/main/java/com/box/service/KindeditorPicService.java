package com.box.service;

import org.springframework.web.multipart.MultipartFile;

import com.box.utils.PictureResult;

public interface KindeditorPicService {
	
	PictureResult uploadPic(MultipartFile uploadFile) throws Exception ;

}
