package com.box.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.box.entity.DbUsers;
import com.box.entity.DbUsersExample;
import com.box.entity.DbUsersExample.Criteria;
import com.box.mapper.DbUsersMapper;
import com.box.mapper.MainMapper;
import com.box.service.MainService;


@Service
public class MainServiceImpl implements MainService {
	
	@Autowired
	private MainMapper mainMapper;
	
	@Autowired
	private DbUsersMapper usersMapper;

	public List<DbUsers> selUsersToday() {
		// TODO Auto-generated method stub
		return mainMapper.selUsersToday();
	}

	public List<DbUsers> selUsersYesterday() {
		// TODO Auto-generated method stub
		return mainMapper.selUsersYesterday();
	}

	public List<DbUsers> selUsersYearWeek() {
		// TODO Auto-generated method stub
		return mainMapper.selUsersYearWeek();
	}

	public List<DbUsers> selUsersMonth() {
		// TODO Auto-generated method stub
		return mainMapper.selUsersMonth();
	}

	public List<DbUsers> selUserList() {
		// TODO Auto-generated method stub
		DbUsersExample example=new DbUsersExample();
		return usersMapper.selectByExample(example);
	}

	public Integer selUsersCountBySex(Integer i) {
		// TODO Auto-generated method stub
		DbUsersExample example=new DbUsersExample();
		Criteria createCriteria = example.createCriteria();
		createCriteria .andSexEqualTo(i+"");
		List<DbUsers> list = usersMapper.selectByExample(example);
		return list.size();
	}

}
