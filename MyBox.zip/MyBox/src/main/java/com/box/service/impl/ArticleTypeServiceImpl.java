package com.box.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.box.entity.DbArticletype;
import com.box.entity.DbArticletypeExample;
import com.box.mapper.DbArticletypeMapper;
import com.box.service.ArticleTypeService;
import com.box.utils.LayuiResult;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

/**
*<p>Title:ArticleTypeServiceImpl.java</p>
*<p>Description:文章类型实现类</p>
*<p>Company:www.99weixinxcx.cn</p>
*@author 陕西电子科技学院:滕一帆
*@date	2019年4月20日上午2:11:31
*@version 1.0
*
*
*
 */

@Service
public class ArticleTypeServiceImpl implements ArticleTypeService {

	@Autowired
	private DbArticletypeMapper typeMapper;
	public List<DbArticletype> getArticleTypeList() {
		// TODO Auto-generated method stub
		DbArticletypeExample example=new DbArticletypeExample();
		List<DbArticletype> list = typeMapper.selectByExample(example);
		
		return  list;
	}
	public DbArticletype selArticleById(Integer artypeid) {
		
		DbArticletype type = typeMapper.selectByPrimaryKey(artypeid);
		return type;
	}
	public LayuiResult selArticleTypeList(Integer page, Integer limit) {
		try {
			PageHelper.startPage(page,limit);
			DbArticletypeExample example=new DbArticletypeExample();
			List<DbArticletype> list = typeMapper.selectByExample(example);
			PageInfo<DbArticletype> pageinfo=new PageInfo<DbArticletype>(list);
			LayuiResult result=new LayuiResult();
			result.setCode(0);
			result.setCount(pageinfo.getTotal());
			result.setMsg("成功获取列表"+pageinfo.getList());
			result.setData(pageinfo.getList());
			return result;
		} catch (Exception e) {
			
			
			LayuiResult result=new LayuiResult();
			result.setCode(0);
			result.setCount(null);
			result.setMsg("获取错误");
			result.setData(e);
			return result;
			
			
		}
		
	
	}
	public LayuiResult insertArticleType(DbArticletype type) {
		// TODO Auto-generated method stub
		
		try {
			int n = typeMapper.insert(type);
			System.out.println("成功添加文章类型"+n);
				return new LayuiResult(0,"成功添加文章类型");
	
		} catch (Exception e) {
			// TODO: handle exception
			return new LayuiResult(500,"添加文章类型出问题了!");
		}
		
		
	
	}
	public LayuiResult delTypeById(Integer id) {
		// TODO Auto-generated method stub

		try {
		Integer n=	 typeMapper.deleteByPrimaryKey(id);
		System.out.println("成功删除"+n+"条记录");
		return new LayuiResult(0,"删除文章类型成功");
			 
		} catch (Exception e) {
			// TODO: handle exception
			return new LayuiResult(500, e.toString());
		}
		
	}
	//批量删除
	public Integer delArticletypeAll(String articletypeStr) {
		String [] ids=articletypeStr.split(",");
		Integer n=0;
		if(ids!=null&&ids.length>0){
			for (String id : ids) {
			n=typeMapper.deleteByPrimaryKey(Integer.parseInt(id));
			}
		}
		System.out.println("成功批量删除文章的"+n+"条记录");
		return n;
	}
	public DbArticletype getTypeItem(String id) {
		// TODO Auto-generated method stub
		DbArticletype selectByPrimaryKey = typeMapper.selectByPrimaryKey(Integer.parseInt(id));
		
		return selectByPrimaryKey;
	}
	public LayuiResult updeArticleType(DbArticletype articleType) {
		// TODO Auto-generated method stub
		try {
			typeMapper.updateByPrimaryKey(articleType);
			return new LayuiResult(0,"修改成功");
		} catch (Exception e) {
			// TODO: handle exception
			return new LayuiResult(500, "修改失败");
		}
		
		
		
	}

}
