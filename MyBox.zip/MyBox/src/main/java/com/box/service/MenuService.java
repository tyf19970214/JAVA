package com.box.service;

import java.util.List;

import com.box.entity.DbAdmin;
import com.box.entity.Menu;
import com.box.entity.XtreeData;
import com.box.entity.DbMenus;




public interface MenuService {
	
		//获取菜单
		public List<Menu> selMenus(DbAdmin admin);
		//获取指定角色权限树
		public List<XtreeData> selXtreeData(DbAdmin admin);
		//获取指定角色权限树
		public List<XtreeData> selXtreeData1(DbAdmin admin);
		
		public List<DbMenus> selMenusByParentId();

		public DbMenus selMenuById(Long menuId);

		public void insMenu(DbMenus menus);

		public void updMenu(DbMenus menus);

		public DbMenus selMenuByTitle(String title);

		public DbMenus selMenusById(Long menuId);

		public void delMenuById(Long menuId);

		public List<DbMenus> selMenusById1(Long menuId);
}
