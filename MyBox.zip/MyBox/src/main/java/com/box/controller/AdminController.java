package com.box.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.authc.LockedAccountException;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.box.entity.DbAdmin;
import com.box.entity.DbArticletype;
import com.box.entity.DbUsers;
import com.box.entity.ResultAdminLog;
import com.box.entity.UserSearch;
import com.box.service.AdminService;
import com.box.service.ArticleTypeService;
import com.box.service.UserService;
import com.box.utils.JsonUtils;
import com.box.utils.LayuiResult;
import com.box.utils.RRException;
import com.box.utils.ResponseResult;
import com.box.utils.ShiroUtils;




/**
*<p>Title:AdminController.java</p>
*<p>Description:管理员控制器</p>
*<p>Company:www.99weixinxcx.cn</p>
*@author 陕西电子科技学院:滕一帆
*@date	2019年4月6日下午10:24:46
*@version 1.0
*
*
*
 */
@Controller
@RequestMapping("/admin")
public class AdminController {
	
	@Autowired
private	AdminService adminService;
	
	@Autowired
	private ArticleTypeService typService;
	
	@Autowired
	private UserService userService;

	
	/*
	@RequestMapping(value="/login",method={RequestMethod.GET,RequestMethod.POST})
	@ResponseBody
	public String login(String userName,String  passWord,HttpServletRequest request,HttpServletResponse response){
		
	try {
			ResponseResult login = adminService.login( userName, passWord,request, response);
	
		
			String json = JsonUtils.objectToJson(login);
			return json;
		} catch (Exception e) {
			// TODO: handle exception
			ResponseResult build = ResponseResult.build(500, "登录失败");
			String objectToJson = JsonUtils.objectToJson(build );
			return objectToJson ;
		}
		


	}*/

	@RequestMapping("/shiro/login")
	@ResponseBody
	public LayuiResult login(String userName, String passWord) {
		if(StringUtils.isEmpty(userName)||StringUtils.isEmpty(passWord)){
			throw new RRException("参数不能为空");
		}
	System.out.println(userName+passWord+".............................用户名和密码");
		
	try{
		Subject subject = ShiroUtils.getSubject();
		//md5加密
		passWord=DigestUtils.md5DigestAsHex(passWord.getBytes());
		UsernamePasswordToken token = new UsernamePasswordToken(userName, passWord);
		subject.login(token);
	}catch (UnknownAccountException e) {
		return LayuiResult.error(e.getMessage());
	}catch (IncorrectCredentialsException e) {
		return LayuiResult.error(e.getMessage());
	}catch (LockedAccountException e) {
		return LayuiResult.error(e.getMessage());
	}catch (AuthenticationException e) {
		return LayuiResult.error("账户验证失败");
	}
	return LayuiResult.ok();
		
	}


	
	
	//管理员注册
	
	@RequestMapping(value="/register",method={RequestMethod.GET,RequestMethod.POST})
	@ResponseBody
	public String register(String userName,String  passWord){
		DbAdmin admin=new DbAdmin();
		admin.setUsername(userName);
	
		String md5 = DigestUtils.md5DigestAsHex(passWord.getBytes());
		admin.setPassword( md5);
		
		try {
			  ResponseResult register = adminService.register(admin);
String json = JsonUtils.objectToJson(register);
			return  json;
		} catch (Exception e) {
			// TODO: handle exception
			ResponseResult build = ResponseResult.build(500, "注册失败");
	String error=		 JsonUtils.objectToJson(build);
			return error ;
		}
	
	}
	
	//返回队形
	@RequestMapping(value="/adminMsg",method={RequestMethod.GET,RequestMethod.POST})
	public String getadminsmsg(Model model){
		
		DbAdmin admin= adminService.getDbAdminItems();
		model.addAttribute("admin", admin);
		
		return "adminMsg";
		
	}
	
	//返回队形
		@RequestMapping(value="/adminUser",method={RequestMethod.GET,RequestMethod.POST})
		public String getAdminUser(Model model){
			
			DbAdmin admin= adminService.getDbAdminItems();
			model.addAttribute("admin", admin);
			
			return "adminUser";
			
		}
		
		@RequestMapping(value="/addUser",method={RequestMethod.GET,RequestMethod.POST})
		@ResponseBody
		public String getAdminUser(DbAdmin admin){
			
			 ResponseResult addUser = adminService.addUser(admin);
			 String objectToJson = JsonUtils.objectToJson(addUser);
			System.out.println(addUser+"..................成功记录");
			return objectToJson;
			
		}
		
		//退出界面
		@RequestMapping(value="/logout",method={RequestMethod.GET,RequestMethod.POST})
		public String LogOut(){
			
			 adminService.LogOut();
			
			
			return "login";
			
		}
		
		@RequestMapping(value="/welcome",method={RequestMethod.GET,RequestMethod.POST})
		public String showlog(Model model){
			DbAdmin dbAdminItems = adminService.getDbAdminItems();
			
			model.addAttribute("admin", dbAdminItems );
			
			 List<ResultAdminLog> list = adminService.selectByAdminlog();
			 
			 model.addAttribute("adminlog", list);
			
			
			return "welcome";
			
		}
		
		
		@RequestMapping(value="/articleList",method={RequestMethod.GET,RequestMethod.POST})
		public String showList(Model model){
			DbAdmin dbAdminItems = adminService.getDbAdminItems();
			
			model.addAttribute("admin", dbAdminItems );
			
			 List<ResultAdminLog> list = adminService.selectByAdminlog();
			 
			 model.addAttribute("adminlog", list);
			 
			 List<DbArticletype> typelist = typService.getArticleTypeList();
			 
			 model.addAttribute("articletype", typelist );
			 
			 List<DbUsers> userList = userService.getUserList();
			 
			 model.addAttribute("user", userList);
			
			
			return "articleList";
			
		}
		
		
		
		
		
		
	
		@RequestMapping("/userList")
		public String showUsersListPage(Model model){
			DbAdmin dbAdminItems = adminService.getDbAdminItems();
			model.addAttribute("admin", dbAdminItems);
			return "userList";
		}
		
		@RequestMapping(value="/user/getUserList",method={RequestMethod.GET,RequestMethod.POST},produces="application/json;charset=UTF-8")
		@ResponseBody
		public LayuiResult getUserList(Integer page,Integer limit,UserSearch search){
			System.out.println(search.getNickname()+"..............昵称");
			System.out.println(search.getUsername()+"..............用户名");
			System.out.println(search.getEmail()+"..............邮箱");
			System.out.println(search.getSex()+"..............性别");
			LayuiResult selUsers = userService.selUsers(page, limit, search);
			return selUsers;
		}
		
		@RequestMapping("/goPage")
		public String showAddUserPage(Model model){
			DbAdmin dbAdminItems = adminService.getDbAdminItems();
			model.addAttribute("admin", dbAdminItems);
			return "user/addUser";
		}
		
		@RequestMapping(value="/shiro/main",method={RequestMethod.GET,RequestMethod.POST})
		public String getLittleMessage(Model model){
			
			DbAdmin admin= adminService.getDbAdminItems();
			model.addAttribute("admin",admin);
			
			return "main";
			
		}
		
}
