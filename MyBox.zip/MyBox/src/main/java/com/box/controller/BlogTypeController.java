package com.box.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.box.entity.DbAdmin;
import com.box.entity.DbBtype;
import com.box.service.AdminService;
import com.box.service.BlogTypeService;
import com.box.utils.LayuiResult;
import com.box.utils.SessionUtils;

@Controller
@RequestMapping("/blogtype")
public class BlogTypeController {
	
	@Value("${USERNAME}")
	private String USERNAME;
	
	@Autowired
	private AdminService adminService;
	
	@Autowired
	private BlogTypeService blogTypeService;
	
	
	//获取列表
	@RequestMapping(value="/geBlogTypeList",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult getTypeList(Integer page,Integer limit){
		
		LayuiResult result= blogTypeService.selBlogTypeList(page, limit);
		
		return result;
	}
	
	//单个删除
	@RequestMapping(value="/delBlogTypeByTid/{tid}",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult delBlogTypeByTid(@PathVariable("tid") String tid){
		
		Integer n = blogTypeService.delBlogTypeById(Integer.parseInt(tid));
		if(n>0){
			return new LayuiResult(0,"单个删除成功");
		}else{
			return new LayuiResult(500, "单个删除失败");
		}
		
		
	}
	
	
	//修改
	@RequestMapping(value="/updBlogType",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult editBlogTypeByTid(DbBtype BlogType){
		
		Integer n = blogTypeService.updateBlogType(BlogType);
		if(n>0){
			return new LayuiResult(0,"修改成功");
		}else{
			return new LayuiResult(500, "修改失败");
		}
		
		
	}
	
	
	//添加
	@RequestMapping(value="/insertBlogType",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult insertBlogType(DbBtype BlogType){
		
		Integer n = blogTypeService.insertBlogType(BlogType);
		if(n>0){
			return new LayuiResult(0,"添加成功");
		}else{
			return new LayuiResult(500, "添加失败");
		}
		
		
	}
	
	//批量删除
		@RequestMapping(value="/delBlogTypeAll/{BlogTypeStr}",method={RequestMethod.POST,RequestMethod.GET})
		@ResponseBody
		public LayuiResult deleteAllByBlogType(@PathVariable("BlogTypeStr") String BlogTypeStr){
			
			Integer n = blogTypeService.delBlogTypeByAll(BlogTypeStr);
			if(n>0){
				return new LayuiResult(0,"批量删除成功");
			}else{
				return new LayuiResult(500, "批量删除失败");
			}
			
			
		}
	
	/**
	 * 
	 * 
	 * =================页面跳转============
	 * 
	 * 
	 */
	@RequestMapping("/page/blogtype")
	public String showBlogTypePage(Model model){
		
		DbAdmin admin = adminService.getDbAdminItems();
		model.addAttribute("admin", admin );
		return "blogType/BlogTypeList";
	}
	
	@RequestMapping("/page/EditBlogType/{tid}")
	public String showEditBlogTypePage(@PathVariable("tid") String tid,Model model){
		DbAdmin admin = adminService.getDbAdminItems();
		model.addAttribute("admin", admin );
		DbBtype BlogType = blogTypeService.selBlogTypeById(Integer.parseInt(tid));
		model.addAttribute("BlogType", BlogType);
		return "blogType/EditBlogType";
	}
	
	@RequestMapping("/page/AddBlogType")
	public String showAddBlogTypePage(Model model){
		DbAdmin admin = adminService.getDbAdminItems();
		model.addAttribute("admin", admin );

		return "blogType/AddBlogType";
	}

}
