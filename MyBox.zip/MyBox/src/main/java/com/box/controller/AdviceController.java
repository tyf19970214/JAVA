package com.box.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.box.entity.AdviceSearch;
import com.box.entity.DbAdmin;
import com.box.entity.DbAdvice;
import com.box.service.AdminService;
import com.box.service.AdviceService;
import com.box.utils.LayuiResult;

/**
*<p>Title:AdviceController.java</p>
*<p>Description:公告控制器</p>
*<p>Company:www.99weixinxcx.cn</p>
*@author 陕西电子科技学院:滕一帆
*@date	2019年5月9日上午2:46:31
*@version 1.0
*
*
*
 */
@Controller
@RequestMapping("/advice")
public class AdviceController {
	
	@Autowired
	private AdminService adminService;
	
	@Autowired
	private AdviceService adviService;
	
	//获取公告列表
	@RequestMapping(value="/adviceList",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult getAdviceByList(Integer page,Integer limit,AdviceSearch search){
		System.out.println(search.getAdvtitle()+"............公告标题");
		System.out.println(search.getAdvcontent()+"............公告内容");
		System.out.println(search.getAid()+"............公告管理员");
		System.out.println(search.getAdvdescribe()+"............公告说明");
		
		LayuiResult selAdviceBySearch = adviService.selAdviceBySearch(page, limit, search);
		return selAdviceBySearch;
		
	}
	//单个删除
	@RequestMapping(value="/delAdviceByAdvid",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult delAdviceByAdvid(String advid){
		
		
		return adviService.delOneByAdvice(advid);
		
	}
	//修改公告
	@RequestMapping(value="/updArticle",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult updArticle(DbAdvice advice){
		
		
		return adviService.UpdateAdvice(advice);
		
	}
	//添加公告
	@RequestMapping(value="/InsertAdvice",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult InsertAdvice(DbAdvice advice){
		
		
		return adviService.AddAdvice(advice);
		
	}
	//批量删除
	@RequestMapping(value="/delAdviceByAll/{adviceStr}",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult delAdviceByAll(@PathVariable("adviceStr") String adviceStr){
		
		
		return adviService.delDataByAdvieForOne(adviceStr);
		
	}
	
/**
 * --------------------------------------页面跳转
 * 
 * 
 * 
 */
	@RequestMapping(value="/page/adviceList",method={RequestMethod.POST,RequestMethod.GET})
	public String showPageByList(Model model){
		DbAdmin admin = adminService.getDbAdminItems();
		model.addAttribute("admin", admin);
		List<DbAdmin> admins = adminService.getDbAdmin();
		model.addAttribute("admins", admins);
		
		return "advice/adviceList";
		
	}
	
	@RequestMapping(value="/page/editAdvice/{advid}",method={RequestMethod.POST,RequestMethod.GET})
	public String showEditAdvicePage(@PathVariable("advid") String advid,Model model){
		DbAdmin admin = adminService.getDbAdminItems();
		model.addAttribute("admin", admin);
		System.out.println("成功从公告页面接收的:"+advid);
		DbAdvice advice = adviService.selAdviceDataById(advid);
		Integer aid = advice.getAid();
		DbAdmin sel = adminService.selAdminById(aid);
		model.addAttribute("sel", sel);
		model.addAttribute("advice", advice);
		
		return "advice/editAdvice";
		
	}
	
	@RequestMapping(value="/page/addAdvice",method={RequestMethod.POST,RequestMethod.GET})
	public String showAddAdvicePage(Model model){
		DbAdmin admin = adminService.getDbAdminItems();
		model.addAttribute("admin", admin);
	
		
		
		return "advice/addAdvice";
		
	}
	

}
