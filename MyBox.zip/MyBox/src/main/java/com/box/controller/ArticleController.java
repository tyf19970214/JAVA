package com.box.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.box.entity.ArticleSearch;
import com.box.entity.DbAdmin;
import com.box.entity.DbArticle;
import com.box.entity.DbArticletype;
import com.box.entity.DbUsers;
import com.box.entity.ResultAdminLog;
import com.box.entity.ViewSearch;
import com.box.entity.isViewSearch;
import com.box.service.AdminService;
import com.box.service.ArticleService;
import com.box.service.ArticleTypeService;
import com.box.service.UserService;
import com.box.utils.LayuiResult;

@Controller
@RequestMapping("/article")
public class ArticleController {
	
	@Autowired
	private ArticleService artService;
	
	@Autowired
	private AdminService adminService;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private ArticleTypeService TYPE;
	
	
	@Autowired
	private ArticleTypeService typeService;
	
	@RequestMapping(value="/articleList",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult getArticleList(Integer page,Integer limit,ArticleSearch search){
		System.out.println(search.getArtitle()+"............文章标题");
		System.out.println(search.getArcontent()+"............文章内容");
		System.out.println(search.getIsView()+"............文章审核");
		System.out.println(search.getUid()+"............用户id");
		System.out.println(search.getArtypeid()+"............文章类型编号");
		System.out.println(search.getSimpledes()+"............文章简介");
		LayuiResult selArticleList = artService.selArticleList(page, limit, search);
		
		return selArticleList;
		
		
	}
	
	@RequestMapping(value="/delUserByUid",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult delArticleById(String arid){
		try {
			Integer n = artService.delArticleById(arid);
			System.out.println("删除了文章"+n+"条记录");
			return LayuiResult.ok();
		} catch (Exception e) {
			// TODO: handle exception
			String ex=String.valueOf(e);
			return new LayuiResult(500,ex);
		}
		 
		
	
		
		
	}
	
	@RequestMapping(value="/editArticle/{arid}",method={RequestMethod.POST,RequestMethod.GET})
	public String updateArticle(@PathVariable("arid") String arid,Model model){
		
		System.out.println(arid+"................我进到控制器啦...........");
	
		 DbArticle article = artService.selArticleById(arid);
		 
		 model.addAttribute("article", article );
		
		 DbAdmin dbAdminItems  = adminService.getDbAdminItems();
	
		 model.addAttribute("admin", dbAdminItems );
		 
		 long uid = article.getUid().longValue();
		 DbUsers users = userService.selUserById(uid);
		 
		 model.addAttribute("users", users);
		 
		 Integer artypeid = article.getArtypeid();
		 DbArticletype type = typeService.selArticleById(artypeid);
		 model.addAttribute("type", type);
		 
		 List<DbArticletype> articleTypeList = TYPE.getArticleTypeList();
		 
		 model.addAttribute("articleType", articleTypeList);
		
		return "article/editArticle";
	}
	
	@RequestMapping(value="/updArticle",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult updArticle(DbArticle article){
		try {
			System.out.println(article.getArcontent()+"...............文章内容");
			Integer n = artService.updArticleByStringArticle(article);
			System.out.println("修改了文章"+n+"条记录");
			return new LayuiResult(0,"成功修改文章记录");
		} catch (Exception e) {
			// TODO: handle exception
			String ex=String.valueOf(e);
			return new LayuiResult(500,ex);
		}
		 
		
	
		
		
	}
	
	
	@RequestMapping(value="/delArticle/{articleStr}",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult delArticleService(@PathVariable("articleStr") String  articleStr){
		try {
			Integer n = artService.delArticleService(articleStr);
			System.out.println("批量删除了文章"+n+"条记录");
			return LayuiResult.ok();
		} catch (Exception e) {
			// TODO: handle exception
			String ex=String.valueOf(e);
			return new LayuiResult(500,ex);
		}
		 
		
	
		
		
	}
	
	@RequestMapping(value="/addArticle",method={RequestMethod.POST,RequestMethod.GET})
	public String addArticle(Model model){
		
		
	
	
		
		 DbAdmin dbAdminItems  = adminService.getDbAdminItems();
	
		 model.addAttribute("admin", dbAdminItems );
		 
		 
		 List<DbUsers> userList = userService.getUserList();
		 
		 model.addAttribute("users", userList);	 
		
		 
		 List<DbArticletype> articleTypeList = TYPE.getArticleTypeList();
		 
		 model.addAttribute("articleType", articleTypeList);
		
		return "article/addArticle";
	}
	
	
	
	@RequestMapping(value="/insertArticle",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult addArticleService(DbArticle article){
		try {
			System.out.println(article.getArcontent()+"...........文章内容");
			Integer n = artService.insertArticle(article);
			System.out.println("成功添加了文章"+n+"条记录");
			return new LayuiResult(0,"文章添加成功");
		} catch (Exception e) {
			// TODO: handle exception
			String ex=String.valueOf(e);
			return new LayuiResult(500,ex);
		}
		 
		
	
		
		
	}
	//待审核页面
	@RequestMapping(value="/articleIsViewList",method={RequestMethod.GET,RequestMethod.POST})
	public String showIsViewList(Model model){
		DbAdmin dbAdminItems = adminService.getDbAdminItems();
		
		model.addAttribute("admin", dbAdminItems );
		
		 List<ResultAdminLog> list = adminService.selectByAdminlog();
		 
		 model.addAttribute("adminlog", list);
		 
		 List<DbArticletype> typelist =TYPE.getArticleTypeList();
		 
		 model.addAttribute("articletype", typelist );
		 
		 List<DbUsers> userList = userService.getUserList();
		 
		 model.addAttribute("user", userList);
		
		
		return "article/articleListByNotIsView";
	}
	
	//已审核页面
	@RequestMapping(value="/articleListByIsView",method={RequestMethod.GET,RequestMethod.POST})
	public String articleListByIsView(Model model){
		DbAdmin dbAdminItems = adminService.getDbAdminItems();
		
		model.addAttribute("admin", dbAdminItems );
		
		 List<ResultAdminLog> list = adminService.selectByAdminlog();
		 
		 model.addAttribute("adminlog", list);
		 
		 List<DbArticletype> typelist =TYPE.getArticleTypeList();
		 
		 model.addAttribute("articletype", typelist );
		 
		 List<DbUsers> userList = userService.getUserList();
		 
		 model.addAttribute("user", userList);
		
		
		return "article/articleListByIsView";
	}
	
	//待审核文章列表
	@RequestMapping(value="/articleListNotIsView",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult goArticleListByIsView(Integer page,Integer limit,isViewSearch search){
		System.out.println(search.getArtitle()+"............文章标题");
		System.out.println(search.getArcontent()+"............文章内容");
		System.out.println(search.getIsView()+"............文章审核");
		System.out.println(search.getUid()+"............用户id");
		System.out.println(search.getArtypeid()+"............文章类型编号");
		System.out.println(search.getSimpledes()+"............文章简介");
		LayuiResult selArticleList = artService.selArticleListByNotIsView(page, limit, search);
		
		return selArticleList;
		
		
	}
	
	//审核
	@RequestMapping(value="/clickisViewByIsView",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult clickisViewByIsView(String arid){
		try {
			LayuiResult updArticleByIsView  = artService.updArticleByIsView(arid);
			return  updArticleByIsView;
		} catch (Exception e) {
			// TODO: handle exception
			return new LayuiResult(500, "审核失败");
		}
		 
		
		
		
		
	}
	
	//审核单个删除
	@RequestMapping(value="/delisViewByArtStrByOne",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult delisViewByArtStrByOne(String arid){
		try {
			LayuiResult delArticleByIsView = artService.delArticleByIsView(arid);
			return  delArticleByIsView;
		} catch (Exception e) {
			// TODO: handle exception
			return new LayuiResult(501, "删除失败");
		}
		 
		
		
		
		
	}
	
	//审核批量删除
	@RequestMapping(value="/delisViewByArtStrByAlittle/{articleStr}",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult delisViewByArtStrByAlittle(@PathVariable("articleStr") String  articleStr){
		try {
		
		Integer n=	artService.delArticleByIsViewByAll(articleStr);
		if(n!=0){
			return  LayuiResult.ok();
		}else{
			return new LayuiResult(500, "批量删除失败，其中有审核过的文章");
		}
			
		} catch (Exception e) {
			// TODO: handle exception
			return new LayuiResult(501, "批量删除失败"+e);
		}
		 
		
		
		
		
	}
	
	//已审核列表
	@RequestMapping(value="/articleListIsView",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult IsViewList(Integer page,Integer limit,ViewSearch search){
		System.out.println(search.getArtitle()+"............文章标题");
		System.out.println(search.getArcontent()+"............文章内容");
		System.out.println(search.getIsView()+"............文章审核");
		System.out.println(search.getUid()+"............用户id");
		System.out.println(search.getArtypeid()+"............文章类型编号");
		System.out.println(search.getSimpledes()+"............文章简介");
		LayuiResult selArticleList = artService.selArticleListByIsView(page, limit, search);
		
		return selArticleList;
		
		
	}
	
	
	//审核单个删除
		@RequestMapping(value="/delisViewOne",method={RequestMethod.POST,RequestMethod.GET})
		@ResponseBody
		public LayuiResult delisViewOne(String arid){
			try {
				LayuiResult delArticleByIsView = artService.delArticleByIsView(arid);
				return  delArticleByIsView;
			} catch (Exception e) {
				// TODO: handle exception
				return new LayuiResult(501, "删除失败");
			}
			 
			
			
			
			
		}
		
		
		//驳回
		@RequestMapping(value="/clickByIsView",method={RequestMethod.POST,RequestMethod.GET})
		@ResponseBody
		public LayuiResult clickByIsView(String arid){
			try {
				LayuiResult updArticleByIsView  = artService.updArticleByNotIsView(arid);
				return  updArticleByIsView;
			} catch (Exception e) {
				// TODO: handle exception
				return new LayuiResult(500, "审核失败");
			}
			 
			
			
			
			
		}
		@RequestMapping(value="/delisViewByAll/{articleStr}",method={RequestMethod.POST,RequestMethod.GET})
		@ResponseBody
		public LayuiResult delisViewByAll(@PathVariable("articleStr") String  articleStr){
			try {
			
			Integer n=	artService.delArticleByIsViewByAll(articleStr);
			if(n!=0){
				return  LayuiResult.ok();
			}else{
				return new LayuiResult(500, "批量删除失败，其中有审核过的文章");
			}
				
			} catch (Exception e) {
				// TODO: handle exception
				return new LayuiResult(501, "批量删除失败"+e);
			}
			 
			
			
			
			
		}

}
