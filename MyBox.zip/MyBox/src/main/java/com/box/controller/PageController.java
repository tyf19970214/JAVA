package com.box.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.box.entity.DbAdmin;
import com.box.entity.DbLink;
import com.box.entity.DbWeb;
import com.box.mapper.DbWebMapper;
import com.box.service.AdminService;
import com.box.service.LinkService;
import com.box.service.WebService;

@Controller
public class PageController {

	@Autowired
	private AdminService adminService;
	
	@Autowired
	private WebService webService;
	
	
	@Autowired
	private LinkService linkService;
	/**
	 * 打开首页
	 */
	@RequestMapping("/")
	public String showIndex() {
	
		return "index";
	}
	/**
	 * 展示其他页面
	 * <p>Title: showpage</p>
	 * <p>Description: </p>
	 * @param page
	 * @return
	 */
	@RequestMapping("/{page}")
	public String showpage(@PathVariable String page,Model model) {
		DbWeb web = webService.selWebByOne(2);
		System.out.println(web);
		model.addAttribute("web", web);
		List<DbLink> link = linkService.selLinks();
		model.addAttribute("link", link);
		System.out.println(page+"前端页面");
		return page;
	}
	
	@RequestMapping("/email/{page}")
	public String showEmailPage(@PathVariable String page) {
		System.out.println(page+"前端页面");
		return "email/"+page;
	}
	
	
	@RequestMapping("/druid/index")
	public String showDruidPage(Model model,HttpServletRequest request){
		System.out.println("前端页面");
		return "druid/index";
	}
	
	@RequestMapping("/page/treeGrid")
	public String getTree(Model model,HttpServletRequest request){
		System.out.println("menuList页面");
		return "menu/menuList";
	}
	

	
	@RequestMapping("/shiro/login")
	public String showBackLoginPage(Model model,HttpServletRequest request){
		System.out.println("login页面");
		DbWeb back = webService.selWebByOne(3);
		model.addAttribute("web", back);
		return "login";
	}
	
	
	@RequestMapping("/roles/page/rolesList")
	public String showRolesPage(Model model,HttpServletRequest request){
		
		return "roles/roleList";
	}
	
	
	
	
	

	
	

	
	@RequestMapping("/login")
	public String showLogin() {

		return "login";
	}
}
