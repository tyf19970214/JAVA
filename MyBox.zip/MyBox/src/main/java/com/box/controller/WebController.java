package com.box.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.box.entity.DbAdmin;
import com.box.entity.DbWeb;
import com.box.service.AdminService;
import com.box.service.WebService;
import com.box.utils.LayuiResult;

@Controller
@RequestMapping("/web")
public class WebController {
	
	@Autowired
	private WebService webService;
	
	@Autowired
	private AdminService adminService;
	
	/**
	 * 
	 * 
	 * 
	 * ---------------------------------------------业务逻辑controller
	 * @param web
	 * @return
	 */
	@RequestMapping(value="/addWeb",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult addWebInfo(DbWeb web){
		LayuiResult updateWeb = webService.updateWeb(web);
		return updateWeb ;
	}
	
	@RequestMapping(value="/editWeb",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult editWebWebInfo(DbWeb web){
		LayuiResult updateWeb = webService.upsetWeb(web);
		return updateWeb ;
	}
	
	@RequestMapping(value="/webList",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult webList(Integer page,Integer limit){
		LayuiResult selDbweb  = webService.selDbWebList(page, limit);
		return selDbweb;
	}
	
	@RequestMapping(value="/delWebByWid",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult delWebByWid(String wid){
		LayuiResult del = webService.delWebByWid(wid);
		return del ;
	}
	
	@RequestMapping(value="/delWebAll/{webStr}",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult delWebAll(@PathVariable("webStr ") String webStr ){
		LayuiResult all = webService.delWebAllWid(webStr);
		return all ;
	}
	
	/**
	 * 
	 * 
	 * 
	 * ---------------------------------------------------------------页面跳转controller
	 * @param request
	 * @param model
	 * @return
	 */
	
	@RequestMapping(value="/page/setWeb",method={RequestMethod.POST,RequestMethod.GET})
	public String showaddPage(Model model){
		DbAdmin admin = adminService.getDbAdminItems();
		model.addAttribute("admin", admin);
		return "web/setWeb" ;
	}
	
	@RequestMapping(value="/page/editWeb/{wid}",method={RequestMethod.POST,RequestMethod.GET})
	public String showeditWeb(@PathVariable("wid") String id,Model model){
		DbWeb web = webService.selDbWeb(id);
		
		model.addAttribute("web", web);	
		
		DbAdmin admin = adminService.getDbAdminItems();
		model.addAttribute("admin", admin);
		return "web/editWeb" ;
	}
	
	@RequestMapping(value="/page/webList",method={RequestMethod.POST,RequestMethod.GET})
	public String showWebList(Model model){
						
		DbAdmin admin = adminService.getDbAdminItems();
		model.addAttribute("admin", admin);
		return "web/webList" ;
	}


}
