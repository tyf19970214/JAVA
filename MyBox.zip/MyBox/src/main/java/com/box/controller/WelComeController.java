package com.box.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.box.entity.DbUsers;
import com.box.service.MainService;


@Controller
@RequestMapping("/welcome")
public class WelComeController {
	
	@Autowired
	private MainService mainService;
	
	@RequestMapping("getUserTotal")
	@ResponseBody
	public List<DbUsers> getUserTotal(){
		return mainService.selUserList();
	}
	
	
	@RequestMapping("/getUsersToday")
	@ResponseBody
	public List<DbUsers> getUsersToday(){
		return mainService.selUsersToday();
	}
	@RequestMapping("/getUsersYestoday")
	@ResponseBody
	public List<DbUsers> getUsersYestoday(){
		return mainService.selUsersYesterday();
		
	}
	@RequestMapping("/getUsersYearWeek")
	@ResponseBody
	public List<DbUsers> getUsersYearWeek(){
		return mainService.selUsersYearWeek();
	}
	
	@RequestMapping("/getUsersMonth")
	@ResponseBody
	public List<DbUsers> getUsersMonth(){
		return mainService.selUsersMonth();
	}
	
	/**
	 * json{
	 * "categories":"categories",
	 * "values":["value":value,"name":name],
	 * }
	 * 
	 * 
	 * @return
	 */
	@RequestMapping(value="/dataAccessGender",method={RequestMethod.GET,RequestMethod.POST})
	@ResponseBody
	public Map<String, Object> dataAccessGender() {
		//创建map
	    Map<String, Object> j=new HashMap<String, Object>();
	   // 创建性别字符串数组
	    String[] categories = {"女", "男", "保密"};
	    //放入map中
	    j.put("categories", categories);
	    //创建jsonmap
	    Map<String, Object> json=null;
	    //把map放入list中
	    List<Map<String, Object>> list=new ArrayList<Map<String, Object>>();
	    for(int i=0;i<categories.length;i++){
	    	//循环取出数据库sex数值进行循环写入到json中华传到前端
	    	json = new HashMap<String, Object>();
		    json.put("value", mainService.selUsersCountBySex(i));
		    json.put("name",categories[i]);
		    list.add(json);
	    }
	    j.put("values", list);
	    return j;
	}

}
