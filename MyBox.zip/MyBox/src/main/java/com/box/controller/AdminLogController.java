package com.box.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.box.entity.DbAdmin;
import com.box.service.AdminLogService;
import com.box.service.AdminService;
import com.box.utils.LayuiResult;

/**
 * @author 日志控制器
 *
 */
@Controller
@RequestMapping("/adminlog")
public class AdminLogController {
	
	@Autowired
	private AdminLogService logService;
	
	@Autowired
	private AdminService adminService;
	/**
	 * 
	 * 业务逻辑
	 * 
	 * 
	 */
	//日志列表
	@RequestMapping(value="/getadminlogList",method={RequestMethod.GET,RequestMethod.POST})
	@ResponseBody
	public  LayuiResult getAdminLogList(Integer page,Integer limit){
		
		LayuiResult result = logService.getAdminLogList(page, limit);
		return result ;
	}
	
	//单个删除
	@RequestMapping(value="/delLogByid",method={RequestMethod.GET,RequestMethod.POST})
	@ResponseBody
	public  LayuiResult delLogByid(String id){
		
		LayuiResult result = logService.delLogByid(id);
		return result ;
	}
	
	//批量删除
	@RequestMapping(value="/deladminlogAll/{adminlogStr}",method={RequestMethod.GET,RequestMethod.POST})
	@ResponseBody
	public  LayuiResult deladminlogAll(@PathVariable("adminlogStr") String adminlogStr){
		
		LayuiResult result = logService.deladminlogAll(adminlogStr);
		return result ;
	}
	/**
	 * 
	 * 页面跳转
	 * 
	 * 
	 */
	@RequestMapping(value="/page/adminlog",method={RequestMethod.GET,RequestMethod.POST})	
	public  String  showAdminLogPage(Model model){
		DbAdmin dbAdminItems = adminService.getDbAdminItems();
		model.addAttribute("admin", dbAdminItems );
		
		return "adminlog/adminlog" ;
	}
}
