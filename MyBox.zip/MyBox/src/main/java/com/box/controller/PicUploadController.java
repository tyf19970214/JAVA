package com.box.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.box.service.PicUploadService;
import com.box.utils.JsonUtils;
import com.box.utils.PictureUtils;



@Controller
@RequestMapping("/upload")
public class PicUploadController {
	
	@Autowired
	private PicUploadService upload;
	
	@RequestMapping(value="/pic",method={RequestMethod.GET,RequestMethod.POST})
	@ResponseBody                                                                    //responsebody实际上是直接响应给客户端，调用的是response.write()这个方法
	public String uploadfile(MultipartFile pic) throws Exception{
		 PictureUtils uploadPic = upload.uploadPic(pic);
		//需要把java转换成json
		String json = JsonUtils.objectToJson(uploadPic);
		
			return json;
	}

}
