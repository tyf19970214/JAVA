package com.box.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;


import com.box.service.LogService;
import com.box.utils.LayuiResult;


@Controller
@RequestMapping("/log")
public class LogController {

	@Autowired
	private LogService logService;
	
	@RequestMapping("/page/logList")	
	public String logList(){
		return "page/log/logList";
	}
	
	@RequestMapping("/getLogList")	
	@ResponseBody
	public LayuiResult getLogList(Integer page, Integer limit){
		return  logService.selLogList(page,limit);
	}
}
