package com.box.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.box.service.RolesService;
import com.box.utils.LayuiResult;

@Controller
@RequestMapping("/roles")
public class RolesController {

	
	@Autowired
	private RolesService roleService;
	
	@RequestMapping(value="/getRoleList",method={RequestMethod.GET,RequestMethod.POST})
	@ResponseBody
	public LayuiResult selRoles(Integer page,Integer limit){
	return 	roleService.selRoles(page, limit);
	}
	
	@RequestMapping(value="/delRole/{roleId}",method={RequestMethod.GET,RequestMethod.POST})
	@ResponseBody
	public LayuiResult delRoles(@PathVariable("roleId") String roleId){
		System.out.println("<<<<<<<<<<<<我进到单个删除啦>>>>>>>>>>>");
	return 	roleService.delRolesById(Long.parseLong(roleId));
	}
	
	@RequestMapping(value="/delRolesAll/{roleStr}",method={RequestMethod.GET,RequestMethod.POST})
	@ResponseBody
	public LayuiResult delRolesByAll(@PathVariable("roleStr") String roleStr){
	return 	roleService.delRolesByAll(roleStr);
	}
}
