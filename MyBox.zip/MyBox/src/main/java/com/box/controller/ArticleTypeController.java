package com.box.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.box.entity.DbAdmin;
import com.box.entity.DbArticletype;
import com.box.service.AdminService;
import com.box.service.ArticleTypeService;
import com.box.utils.LayuiResult;

/**
 * @author 文章类型
 *
 */
@Controller
@RequestMapping("/articletype")
public class ArticleTypeController {
	
	@Autowired
	private ArticleTypeService artpeService;
	
	@Autowired
	private AdminService adminService;

	//列表页面
	@RequestMapping(value="/articletypeList",method={RequestMethod.POST,RequestMethod.GET})
	public String getListPage(Model model){
		
		DbAdmin admin = adminService.getDbAdminItems();
		model.addAttribute("admin", admin);
		
		
		return "articletype/articletypeList";
	}
	//文章类型添加页面
	@RequestMapping(value="/addArticletype",method={RequestMethod.POST,RequestMethod.GET})
	public String addArticletype(Model model){
		
		DbAdmin admin = adminService.getDbAdminItems();
		model.addAttribute("admin", admin);
		
		
		return "articletype/addArticletype";
	}
	//去文章类型修改页面
	@RequestMapping(value="/editArticletype/{id}",method={RequestMethod.POST,RequestMethod.GET})
	public String updArticleType(@PathVariable("id") String id,Model model){
		
		DbAdmin admin = adminService.getDbAdminItems();
		model.addAttribute("admin", admin);
		DbArticletype articletype= artpeService.selArticleById(Integer.parseInt(id));
		model.addAttribute("articletype", articletype);
		
		
		return "articletype/editArticletype";
	}

	
	
	
	//获取列表
	@RequestMapping(value="/getarticletypeList",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult getTypeList(Integer page,Integer limit){
		
		LayuiResult selArticleTypeList = artpeService.selArticleTypeList(page, limit);
		
		return selArticleTypeList;
	}
	
	//添加
	@RequestMapping(value="/insertArticletype",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult insertArticletype(DbArticletype type){
		
		LayuiResult result= artpeService.insertArticleType(type);
		
		return result;
	}
	//单个删除
	@RequestMapping(value="/delTypeByUid",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult delTypeByUid(String id){
		
		LayuiResult result= artpeService.delTypeById(Integer.parseInt(id));
		
		return result;
	}
	
	//批量删除分类类型
	@RequestMapping(value="/delArticletypeAll",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult delArticletypeAll(@PathVariable("articletypeStr") String articletypeStr){
		try {
			Integer n = artpeService.delArticletypeAll(articletypeStr);
System.out.println("成功批量删除了"+n+"记录");
return new LayuiResult(0,"成功批量删除记录");
		} catch (Exception e) {
			// TODO: handle exception
			return new LayuiResult(500, "批量删除失败");
		}
		
	
	}
	
	//更新文章类型
	@RequestMapping(value="/updArticleType",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult updArticleType(DbArticletype type){
		
	
		LayuiResult result= artpeService.updeArticleType(type);
		
		return result;
	}
	

}
