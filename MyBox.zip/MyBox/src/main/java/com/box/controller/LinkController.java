package com.box.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.box.entity.DbAdmin;
import com.box.entity.DbLink;
import com.box.service.AdminService;
import com.box.service.LinkService;
import com.box.utils.LayuiResult;

/**
*<p>Title:LinkController.java</p>
*<p>Description:友情链接控制器</p>
*<p>Company:www.99weixinxcx.cn</p>
*@author 陕西电子科技学院:滕一帆
*@date	2019年5月17日上午3:12:48
*@version 1.0
*
*
*
 */
@Controller
@RequestMapping("/link")
public class LinkController {
	
	@Autowired
	private AdminService adminService;
	
	@Autowired
	private LinkService linkService;
	
	@RequestMapping(value="/getLinkList",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult getLlinkList(Integer page,Integer limit){
		System.out.println("...................我进来到link业务逻辑了");
		LayuiResult linkList = linkService.getLinkList(page, limit);
		return linkList ;
		
	}
	
	
	@RequestMapping(value="/delLinkById",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult delLinkById(String id){
		LayuiResult linkList = linkService.delLinkById(id);
		return linkList ;
		
	}
	
	@RequestMapping(value="/delLinkStr/{LinkStr}",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult delLinkStr(@PathVariable("LinkStr") String LinkStr){
		LayuiResult linkList = linkService.delLinkByAll(LinkStr);
		return linkList ;
		
	}
	
	@RequestMapping(value="/updLink",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult updLink(DbLink link){
		LayuiResult linkList = linkService.updLinkByLink(link);
		
		return linkList ;
		
	}
	
	@RequestMapping(value="/AddLink",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult AddLink(DbLink link){
		LayuiResult linkList = linkService.AddLink(link);
		
		return linkList ;
		
	}
	
	
	
	
	/**
	 * 
	 * 
	 * 
	 * --------------------------------------------------------页面跳转逻辑----------------------------------
	 * 
	 * @param request
	 * @param model
	 * @return
	 */
	
	
	@RequestMapping(value="/page/seeLink",method={RequestMethod.POST,RequestMethod.GET})
	public String showLinkPage(Model model) {
		System.out.println(".....................我可以跳转页面啦！..................");
		DbAdmin admin = adminService.getDbAdminItems();
		model.addAttribute("admin", admin);
		return "link/LinkList";
	}
	
	@RequestMapping("/page/editLink/{id}")
	public String editLinkPage(@PathVariable("id") String id,Model model) {
		DbAdmin admin = adminService.getDbAdminItems();
		model.addAttribute("admin", admin);
		DbLink link = linkService.selLinkByOne(id);
		model.addAttribute("link", link);
		return "link/editLink";
	}
	
	@RequestMapping("/page/addLink")
	public String addLinkPage(Model model) {
		DbAdmin admin = adminService.getDbAdminItems();
		model.addAttribute("admin", admin);
		
	
		return "link/addLink";
	}
	
	

}
