package com.box.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.box.entity.DbAdmin;
import com.box.entity.DbUsers;
import com.box.service.AdminService;

import com.box.service.UserService;
import com.box.utils.LayuiResult;

/**
*<p>Title:UsersController.java</p>
*<p>Description:用户管理控制器</p>
*<p>Company:www.99weixinxcx.cn</p>
*@author 陕西电子科技学院:滕一帆
*@date	2019年4月28日下午8:24:38
*@version 1.0
*
*
*
 */
@Controller
@RequestMapping("/user")
public class UsersController {
	
	@Autowired
	private AdminService adminService;
	
	@Autowired
	private UserService userService;
	
	
	
	@RequestMapping(value="/checkUserByNickname",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult checkUserByNickName(String nickname,Long uid){
		DbUsers users;
		try {
			nickname=new String(nickname.getBytes("ISO-8859-1"),"UTF-8"); 
			users = userService.checkUserByNickname(nickname, uid);
			if(users!=null){
				return new LayuiResult(501,"昵称已存在，请重新填写");
				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
		return new LayuiResult(0);
	}
	
	@RequestMapping(value="/checkUserByUserName",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult checkUserByUserName(String username,Long uid){
		DbUsers users;
		try {
			username=new String(username.getBytes("ISO-8859-1"),"UTF-8"); 
			users = userService.checkUserByUserName(username, uid);
			if(users!=null){
				return new LayuiResult(502,"用户名已存在，请重新填写");
				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
		return new LayuiResult(0);
	}
	
	@RequestMapping(value="/checkUserByEmail",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult checkUserByUsername(String email,Long uid){
		System.out.println(email+"............邮箱");
		DbUsers users;
		try {
			users = userService.checkUserByEmail(email, uid);
			if(users!=null){
				return new LayuiResult(503,"邮箱已存在，请重新填写");
				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		
		return new LayuiResult(0);
	}
	
	@RequestMapping(value="/insertUser",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult insertUser(DbUsers users) throws Exception{
		System.out.println(users.getAlt()+"............获取的值");
		System.out.println(users.getUsername()+"..............用户名");
		System.out.println(users.getEmail()+"...............邮箱");
		//防止浏览器提交
		DbUsers u1 = userService.checkUserByUserName(users.getUsername(), null);
		DbUsers u2 = userService.checkUserByNickname(users.getNickname(), null);
		DbUsers u3 = userService.checkUserByEmail(users.getEmail(), null);
		if(u1!=null){
			return new LayuiResult(502, "用户名，请重新填写");
			
		}
		if(u2!=null){
			return new LayuiResult(501, "昵称已存在，请重新填写");
			
		}
		if(u3!=null){
			return new LayuiResult(500, "邮箱已存在，请从新填写");
		}
		try {
		Integer n = userService.insertUserBySerliaze(users);
		System.out.println(n+"................成功添加数据到数据库:"+n+"条记录");
			return LayuiResult.ok();
		} catch (Exception e) {
			// TODO: handle exception
			return new LayuiResult(500, "邮件发送错误，重新发送");
		}
		
		
	}
	
	@RequestMapping(value="/delUserByUid",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult delUserById(String uid){
		Integer n= userService.delUserById(uid);
		System.out.println("成功删除了"+n+"条记录");
		return LayuiResult.ok();
		
	}
	
	@RequestMapping(value="/editUser/{uid}",method={RequestMethod.POST,RequestMethod.GET})
	public String showEditUserPageById(@PathVariable("uid") String uid,Model model){
		//获取cookie中的管理员信息参数，之后会修改成session，便于开发先用cookie。
		System.out.println(uid+"...................uid");
		DbAdmin admin = adminService.getDbAdminItems();
		model.addAttribute("admin",admin);
		
		DbUsers users = userService.selUserById(Long.parseLong(uid));
		model.addAttribute("user",users );

		
		return "user/editUser";
	}
	
	@RequestMapping(value="/updUser",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult updateUserByItems(DbUsers users){
		System.out.println(users.getAddress()+"....................表单的地址.......");
		
		Integer updUserService = userService.updUserService(users);
		
		if(updUserService>0){
			return LayuiResult.ok();
		}
		return  new LayuiResult(501,"修改出错");
		
		
	}
	
	
	@RequestMapping(value="/delUsers/{userStr}",method={RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public LayuiResult delUsers(@PathVariable("userStr") String userStr){
		try {
			System.out.println(userStr+".........................json的批量删除的uid");
			 userService.delUsersService(userStr);
			return LayuiResult.ok();
		} catch (Exception e) {
			// TODO: handle exception
			return new LayuiResult(501,"批量删除失败");
		}
		
		
	}
	
	

}
