package com.box.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/sys")
public class SysController {

	
	
	@RequestMapping("/404")
	public String go404(){
		
		return "error/404";
	}
	
	@RequestMapping("/refuse")
	public String goRefuse(){
		
		return "error/404";
	}
}
