package com.box.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.box.service.KindeditorPicService;
import com.box.utils.JsonUtils;
import com.box.utils.PictureResult;


/**
*<p>Title:KindeditorController.java</p>
*<p>Description:Kindeditor</p>
*<p>Company:www.99weixinxcx.cn</p>
*@author 陕西电子科技学院:滕一帆
*@date	2019年4月22日上午12:32:04
*@version 1.0
*
*
*
 */
@Controller
public class KindeditorController {
	
	@Autowired
	private KindeditorPicService picService;
	
	
	@RequestMapping(value="/pic/upload",method={RequestMethod.GET,RequestMethod.POST})
	@ResponseBody                                                                    //responsebody实际上是直接响应给客户端，调用的是response.write()这个方法
	public String uploadfile(MultipartFile uploadFile) throws Exception{
		System.out.println(uploadFile+"...................上传的文件名");
		PictureResult picResult = picService.uploadPic(uploadFile);
		//需要把java转换成json
		String json = JsonUtils.objectToJson(picResult);
		
			return json;
	}

}
