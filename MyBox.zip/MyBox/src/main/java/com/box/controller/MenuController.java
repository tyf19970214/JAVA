package com.box.controller;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.box.annotation.SysLog;
import com.box.entity.DbMenus;
import com.box.service.MenuService;
import com.box.utils.LayuiResult;






@Controller
@RequestMapping("/menu")
public class MenuController {
	
	@Autowired
	private MenuService menuService;
	
	@RequestMapping(value="/menuData",method={RequestMethod.GET,RequestMethod.POST})
	@RequiresPermissions("sys:menu:list")
	@ResponseBody
	public LayuiResult menuData(){
		List<DbMenus> selMenusByParentId = menuService.selMenusByParentId();
		return LayuiResult.ok(selMenusByParentId);
	}
	

	/**
	 * @author 页面跳转
	 *
	 */
	
	@RequestMapping("/toSaveMenu/{menuId}")
	@RequiresPermissions("sys:menu:save")
	public String toSaveMenu(@PathVariable("menuId") Long menuId,Model model){
		if(menuId!=null&&menuId!=1){
			DbMenus menus=new DbMenus();
			menus.setMenuId(menuId);
			model.addAttribute("menu",menus);
			model.addAttribute("flag","1");
			return "menu/menuForm";
		}else{
			model.addAttribute("msg","不允许操作！");
			return "error/active";
		}
	}
	
	
	@RequestMapping("/toEditMenu/{menuId}")
	@RequiresPermissions("sys:menu:update")
	public String toEditMenu(@PathVariable("menuId") Long menuId,Model model){
		if(menuId!=null&&menuId!=1){
			DbMenus menus=menuService.selMenuById(menuId);
			model.addAttribute("menu",menus);
			return "menu/menuForm";
		}else if(menuId==1){
			model.addAttribute("msg","不允许操作此菜单！");
			return "error/active";
		}else{
			model.addAttribute("msg","不允许操作！");
			return "error/active";
		}
	}
	
	
	@RequestMapping("/menuForm")
	@RequiresPermissions(value={"sys:menu:save","sys:menu:update"})
	@ResponseBody
	public LayuiResult menuForm(DbMenus menus,String flag){
		if(StringUtils.isBlank(flag)){
			menus.setSpread("false");
			menuService.updMenu(menus);
			return LayuiResult.ok("修改成功！");
		}else if(menus.getMenuId()!=1){
			menus.setParentId(menus.getMenuId());
			
			//规定只能3级菜单
			DbMenus m=menuService.selMenusById(menus.getMenuId());
			if(m!=null&&m.getParentId()!=0){
				DbMenus m1=menuService.selMenusById(m.getParentId());
				if(m1!=null&&m1.getParentId()!=0){
					return LayuiResult.error("此菜单不允许添加子菜单！");
				}
			}
			
			menus.setMenuId(null);
			menus.setSpread("false");
			menuService.insMenu(menus);
			return LayuiResult.ok("添加成功！");
		}else{
			return LayuiResult.error("此菜单不允许操作！");
		}
	}
	
	
	//delMenuById
		@SysLog(value="删除菜单信息")
		@RequestMapping("/delMenuById/{menuId}")
		@RequiresPermissions("sys:menu:delete")
		@ResponseBody
		public LayuiResult delMenuById(@PathVariable("menuId")Long menuId) {
			try {
				if(menuId==1){
					return LayuiResult.error("此菜单不允许删除！");
				}
				//查询是否有子菜单，不允许删除
				List<DbMenus> data=menuService.selMenusById1(menuId);
				if(data!=null&&data.size()>0){
					return LayuiResult.error("包含子菜单，不允许删除！");
				}
				menuService.delMenuById(menuId);
				return  LayuiResult.ok("删除成功");
			} catch (Exception e) {
				e.printStackTrace();
				return  LayuiResult.error("系统错误！");
			}
		}
	
}
